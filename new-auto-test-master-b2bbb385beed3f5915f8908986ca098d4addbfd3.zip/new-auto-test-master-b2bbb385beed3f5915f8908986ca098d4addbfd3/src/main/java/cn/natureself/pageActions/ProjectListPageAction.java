package cn.natureself.pageActions;

import org.openqa.selenium.WebDriver;

import cn.natureself.pageObjects.ProjectListPage;

/**
 * 项目列表页面操作类
 * 
 * @author Andy
 */

public class ProjectListPageAction {
    
    /**
     * 进入项目主页操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param name - 项目名称
     * @throws InterruptedException
     */
    public static void enterProject(WebDriver driver, String name) 
            throws InterruptedException {
        ProjectListPage listPage = new ProjectListPage(driver);
        listPage.getProjectBtn(name).click();
        Thread.sleep(2000);
    }
}