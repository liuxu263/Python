package cn.natureself.pageActions;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import cn.natureself.pageObjects.LoginPage;

/**
 * 登录和注册页面操作类
 * 
 * @author Andy
 */

public class LoginPageAction {

    /**
     * 登录操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param username - 用户名
     * @param password - 密码
     * @throws InterruptedException
     */
    public static void Login(WebDriver driver, String username, String password)
            throws InterruptedException {
        LoginPage loginPage = new LoginPage(driver);

        // do login
        loginPage.userNameInput().sendKeys(username);
        loginPage.passwordInput().sendKeys(password);
        loginPage.loginBtn().click();
        Thread.sleep(2000);
    }

    /**
     * 注册新用户操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param email - 邮箱
     * @param password - 密码
     * @param name - 名字
     * @param phone - 手机
     * @param department - 科室
     * @param title - 职称
     * @param site - 工作单位
     * @param address - 工作地址
     * @throws InterruptedException
     */
    public static void signUp(WebDriver driver, String email, String password, String name, String phone,
            String department, String title, String site, String address) throws InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        
        // input registry info
        loginPage.signUpEmailInput().sendKeys(email);
        loginPage.signUpPwdInput().sendKeys(password);
        loginPage.signUpRePwdInput().sendKeys(password);
        loginPage.signUpNameInput().sendKeys(name);
        loginPage.signUpPhoneInput().sendKeys(phone);
        loginPage.signUpDeptInput().sendKeys(department);
        loginPage.signUpTitleInput().sendKeys(title);
        loginPage.signUpSiteInput().sendKeys(site);
        loginPage.signUpAddrInput().sendKeys(address);
        Thread.sleep(2000);
        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView()", loginPage.signUpBtn());
        if (loginPage.signUpBtn().getAttribute("disabled") == null) {
            loginPage.signUpBtn().click();
        }
        Thread.sleep(2000);
    }

    /**
     * 忘记密码操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param email - 邮箱
     * @throws InterruptedException
     */
    public static void forgetPwd(WebDriver driver, String email)
            throws InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        
        // input email and click confirm button
        loginPage.emailInput().sendKeys(email);
        loginPage.confirmBtn().click();
        Thread.sleep(2000);
    }
    
}