package cn.natureself.pageActions;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cn.natureself.componentObjects.RoleInfo;
import cn.natureself.pageObjects.RoleManagePage;

/**
 * 人员设置页面操作类
 * 
 * @author Andy
 */

public class RoleManagePageAction {
    
    /**
     * 添加人员操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param email - 邮箱
     * @param right - 权限
     * @throws InterruptedException
     */
    public static void addRole(WebDriver driver, String email, String right)
            throws InterruptedException {
        RoleManagePage rolePage = new RoleManagePage(driver);

        // add role
        rolePage.addRoleBtn().click();
        Thread.sleep(1000);
        rolePage.roleEmailInput().sendKeys(email);
        rolePage.selectRoleCtrl().selectByVisibleText(right);
        if (right.equals("监查员")) {
            List<WebElement> list = rolePage.checkboxForAuditor();
            for (WebElement item:list) {
                item.click();
            }
        } else if (right.equals("中心管理员") || right.equals("录入员")) {
            rolePage.selectSiteCtrl().selectByIndex(1);
        }
        rolePage.AddRoleConfirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 添加人员操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param roleInfo - 人员信息
     * @throws InterruptedException
     */
    public static void addRole(WebDriver driver, RoleInfo roleInfo)
            throws InterruptedException {
        RoleManagePage rolePage = new RoleManagePage(driver);

        // add role
        rolePage.addRoleBtn().click();
        Thread.sleep(1000);
        rolePage.roleEmailInput().sendKeys(roleInfo.getEmail());
        rolePage.selectRoleCtrl().selectByVisibleText(roleInfo.getRight());
        List<WebElement> info = rolePage.getInfoInAddRoleDialog();
        roleInfo.setName(info.get(1).getAttribute("value"));
        roleInfo.setSite(info.get(2).getAttribute("value"));
        if (roleInfo.getRight().equals("监查员")) {
            List<WebElement> list = rolePage.checkboxForAuditor();
            if (roleInfo.getCenter().isEmpty()) {
                for (WebElement item:list) {
                    item.click();
                    roleInfo.addCenter(item.getText());
                }
            } else {
            	for (String name:roleInfo.getCenter()) {
            		for (WebElement item:list) {
            			if (item.getText().equals(name)) {
            				item.click();
            				break;
            			}
            		}
            	}
            }
        } else if (roleInfo.getRight().equals("中心管理员") || roleInfo.getRight().equals("录入员")) {
        	if (roleInfo.getCenter().isEmpty()) {
                rolePage.selectSiteCtrl().selectByIndex(1);
                String center = rolePage.selectSiteCtrl().getFirstSelectedOption().getText();
                roleInfo.addCenter(center);
        	} else {
        		String name = roleInfo.getCenter().get(0);
        		rolePage.selectSiteCtrl().selectByVisibleText(name);
        	}
        }
        rolePage.AddRoleConfirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 删除人员操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param email - 邮箱
     * @throws InterruptedException
     */
    public static void deleteRole(WebDriver driver, String email)
            throws InterruptedException {
        RoleManagePage rolePage = new RoleManagePage(driver);

        // delete role
        rolePage.deleteRoleBtn(email).click();
        Thread.sleep(2000);
        rolePage.DeleteRoleConfirmBtn().click();
        Thread.sleep(2000);
    }
}