package cn.natureself.pageActions;


import org.openqa.selenium.WebDriver;
import java.io.IOException;

import cn.natureself.pageObjects.FormManagePage;
import cn.natureself.utils.freeSSHdUpload;

/**
 * 表单管理页面操作类
 * 
 * @author Andy
 */

public class FormManagePageAction {
    
    /**
     * 上传表单操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param hostname - hostname
     * @param autoit - autoit exe
     * @throws IOException
     * @throws InterruptedException
     */
    public static void uploadForm(WebDriver driver, String hostname, String autoit)
            throws IOException, InterruptedException {
        FormManagePage formPage = new FormManagePage(driver);

        // upload form using autoit
        formPage.uploadFormBtn().click();
        Thread.sleep(2000);
        freeSSHdUpload.upload_form(hostname, autoit);
        Thread.sleep(2000);

        // check if overwrite dialog appears
        if (formPage.getOverwriteMsg()) {
            formPage.confirmBtn().click();
        }
        Thread.sleep(5000);
    }
    
    /**
     * 编辑表单操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param uid - Form uid
     * @param label - the label to be changed to
     * @param line_uid - the uid of the new line
     * @throws InterruptedException
     */
    public static void editForm(WebDriver driver, String uid, String label, String line_uid)
            throws InterruptedException {
        FormManagePage formPage = new FormManagePage(driver);
        
        // click edit button
        formPage.editFormBtn(uid).click();
        Thread.sleep(1000);
        // active form section
        formPage.sectionBtnList().get(0).click();
        Thread.sleep(1000);
        // edit the last line
        formPage.inputListInLine(formPage.lineListInSection().size() - 1).get(1).sendKeys(label);
        Thread.sleep(1000);
        // add a new line and input uid and label
        formPage.addLineBtn().click();
        Thread.sleep(1000);
        formPage.inputListInLine(formPage.lineListInSection().size() - 1).get(0).sendKeys(line_uid);
        formPage.inputListInLine(formPage.lineListInSection().size() - 1).get(1).sendKeys(label);
        Thread.sleep(1000);
        // click add section button
        formPage.addSectionBtn().click();
        Thread.sleep(1000);
        // click save button
        formPage.saveBtn().click();
        Thread.sleep(1000);
        // close dialog
        formPage.closeBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 删除表单操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param uid - Form uid
     * @throws InterruptedException
     */
    public static void deleteForm(WebDriver driver, String uid)
            throws InterruptedException {
        FormManagePage formPage = new FormManagePage(driver);
        
        // get the form name from form uid
        String name = formPage.getFormName(uid);
        
        // click delete button
        formPage.deleteFormBtn(uid).click();
        Thread.sleep(1000);

        // input form name
        if (formPage.formNameInput() != null) {
            formPage.formNameInput().sendKeys(name);
        }
        //click confirm button
        formPage.confirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 下载表单操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param uid - Form uid
     * @throws IOException
     * @throws InterruptedException
     */
    public static void downloadForm(WebDriver driver, String uid)
            throws IOException, InterruptedException {
        FormManagePage formPage = new FormManagePage(driver);
        
        // click download button
        formPage.downloadFormBtn(uid).click();
        Thread.sleep(2000);
    }
    
}