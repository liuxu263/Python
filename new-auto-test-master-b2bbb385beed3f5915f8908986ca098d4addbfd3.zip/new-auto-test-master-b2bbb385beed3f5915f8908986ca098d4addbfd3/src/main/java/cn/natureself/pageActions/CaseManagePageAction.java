package cn.natureself.pageActions;

import org.openqa.selenium.WebDriver;
import cn.natureself.pageObjects.CaseManagePage;
import cn.natureself.utils.commonUtils;
import cn.natureself.componentObjects.CaseInfo;

/**
 * 病例管理页面操作类
 * 
 * @author lx
 */

public class CaseManagePageAction {
	/**
	 * 添加病例
	 * @param driver-WebDriver
	 * @param studynumber-研究对象编号
	 * @param name-姓名
	 * @param idtype-证件类型--(身份证，护照，军人证)
	 * @param idnumber-证件号码
	 * @param centername-中心名称
	 * @param groupname-分组名
	 * @throws InterruptedException
	 */
	public static void AddCase(WebDriver driver, String studynumber, String name, 
	        String idtype, String idnumber, String centername, String groupname) 
	                throws InterruptedException {
		CaseManagePage caseManagePage = new CaseManagePage(driver);
		
		//click add case btn
		caseManagePage.AddCaseBtn().click();
		Thread.sleep(1000);
		
		//add case
		caseManagePage.StudyObjectNumberInput().sendKeys(studynumber);
		caseManagePage.NameInput().sendKeys(name);
		caseManagePage.IDTypeSelect().selectByVisibleText(idtype);
		caseManagePage.IDNumberInput().sendKeys(idnumber);
		caseManagePage.CenterSelect().selectByVisibleText(centername);
		caseManagePage.GroupSelect().selectByVisibleText(groupname);
		caseManagePage.AddEditCaseConfirmBtn().click();
		Thread.sleep(2000);
	}
	
	/**
	 * 随机化分组添加病例
     * @param driver-WebDriver
     * @param studynumber-研究对象编号
     * @param name-姓名
     * @param idtype-证件类型--(身份证，护照，军人证)
     * @param idnumber-证件号码
     * @param centername-中心名称
     * @throws InterruptedException
     */
    public static void RandomAddCase(WebDriver driver, String studynumber, String name, 
            String idtype, String idnumber, String centername) 
                    throws InterruptedException {
        CaseManagePage caseManagePage = new CaseManagePage(driver);
        
        //click add case btn
        caseManagePage.AddCaseBtn().click();
        Thread.sleep(1000);
        
        //add case
        caseManagePage.StudyObjectNumberInput().sendKeys(studynumber);
        caseManagePage.NameInput().sendKeys(name);
        caseManagePage.IDTypeSelect().selectByVisibleText(idtype);
        caseManagePage.IDNumberInput().sendKeys(idnumber);
        caseManagePage.CenterSelect().selectByVisibleText(centername);
        caseManagePage.AddEditCaseConfirmBtn().click();
        Thread.sleep(2000);
    }
	
	/**
     * 添加随机生成研究编号姓名证件号码的病例
     * @param driver-WebDriver
     * @param idtype-证件类型--(身份证，护照，军人证)
     * @param center - 机构名
     * @param group - 分组名
     * @throws InterruptedException
     */
    public static void AddCase(WebDriver driver, String idtype, String center, String group) 
            throws InterruptedException {
        CaseManagePage caseManagePage = new CaseManagePage(driver);
        String id_type = "";
        String idnumber = "";
        
        //click add case btn
        caseManagePage.AddCaseBtn().click();
        Thread.sleep(1000);
        
        //add case
        String studynumber = commonUtils.getNumber(8);
        String name = "病例" + studynumber;
        if (idtype.equals("id18")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(18);
        } else if (idtype.equals("id15")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(15);
        } else if (idtype.equals("id17x")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(17) + "x";
        } else if (idtype.equals("passport")) {
            id_type = "护照";
            idnumber = "E" + commonUtils.getNumber(8);
        } else if (idtype.equals("army")) {
            id_type = "军人证";
            idnumber = "北字第" + commonUtils.getNumber(8) + "号";
        } else {
            throw new InterruptedException("Wrong ID type: " + idtype);
        }
        
        caseManagePage.StudyObjectNumberInput().sendKeys(studynumber);
        caseManagePage.NameInput().sendKeys(name);
        caseManagePage.IDTypeSelect().selectByVisibleText(id_type);
        caseManagePage.IDNumberInput().sendKeys(idnumber);
        caseManagePage.CenterSelect().selectByVisibleText(center);
        caseManagePage.GroupSelect().selectByVisibleText(group);
        caseManagePage.AddEditCaseConfirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 添加随机生成研究编号姓名证件号码的病例 - 随机化分组
     * @param driver-WebDriver
     * @param center - 中心名
     * @param idtype-证件类型--(身份证，护照，军人证)
     * @throws InterruptedException
     */
    public static void RandomAddCase(WebDriver driver, String idtype, String center) 
            throws InterruptedException {
        CaseManagePage caseManagePage = new CaseManagePage(driver);
        String id_type = "";
        String idnumber = "";
        
        //click add case btn
        caseManagePage.AddCaseBtn().click();
        Thread.sleep(1000);
        
        //add case
        String studynumber = commonUtils.getNumber(8);
        String name = "病例" + studynumber;
        if (idtype.equals("id18")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(18);
        } else if (idtype.equals("id15")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(15);
        } else if (idtype.equals("id17x")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(17) + "x";
        } else if (idtype.equals("passport")) {
            id_type = "护照";
            idnumber = "E" + commonUtils.getNumber(8);
        } else if (idtype.equals("army")) {
            id_type = "军人证";
            idnumber = "北字第" + commonUtils.getNumber(8) + "号";
        } else {
            throw new InterruptedException("Wrong ID type: " + idtype);
        }
        
        caseManagePage.StudyObjectNumberInput().sendKeys(studynumber);
        caseManagePage.NameInput().sendKeys(name);
        caseManagePage.IDTypeSelect().selectByVisibleText(id_type);
        caseManagePage.IDNumberInput().sendKeys(idnumber);
        caseManagePage.CenterSelect().selectByVisibleText(center);
        caseManagePage.AddEditCaseConfirmBtn().click();
        Thread.sleep(2000);
    }
	
	/**
	 * 添加病例
     * @param driver-WebDriver
     * @param caseInfo - Case Object
     * @throws InterruptedException
     */
    public static void AddCase(WebDriver driver, CaseInfo caseInfo) throws InterruptedException {
        CaseManagePage caseManagePage = new CaseManagePage(driver);
        
        //click add case btn
        caseManagePage.AddCaseBtn().click();
        Thread.sleep(1000);
        
        //add case
        caseManagePage.StudyObjectNumberInput().sendKeys(caseInfo.getStudyNumber());
        caseManagePage.NameInput().sendKeys(caseInfo.getName());
        caseManagePage.IDTypeSelect().selectByVisibleText(caseInfo.getIDType());
        caseManagePage.IDNumberInput().sendKeys(caseInfo.getIDNumber());
        caseManagePage.CenterSelect().selectByVisibleText(caseInfo.getCenterName());
        if (!caseInfo.getGroupName().isEmpty()) {
            caseManagePage.GroupSelect().selectByVisibleText(caseInfo.getGroupName());
        }
        caseManagePage.AddEditCaseConfirmBtn().click();
        Thread.sleep(2000);
    }
	
	/**
	 * 添加随机生成研究编号姓名证件号码的病例 - 随机化和非随机化
     * @param driver-WebDriver
     * @param caseInfo - Case Object
     * @param idtype-证件类型--(身份证，护照，军人证)
     * @throws InterruptedException
     */
    public static void AddCase(WebDriver driver, CaseInfo caseInfo, String idtype) 
            throws InterruptedException {
        CaseManagePage caseManagePage = new CaseManagePage(driver);
        String id_type = "";
        String idnumber = "";
        
        //click add case btn
        caseManagePage.AddCaseBtn().click();
        Thread.sleep(1000);
        
        //add case
        String studynumber = commonUtils.getNumber(8);
        String name = "病例" + studynumber;
        if (idtype.equals("id18")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(18);
        } else if (idtype.equals("id15")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(15);
        } else if (idtype.equals("id17x")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(17) + "x";
        } else if (idtype.equals("passport")) {
            id_type = "护照";
            idnumber = "E" + commonUtils.getNumber(8);
        } else if (idtype.equals("army")) {
            id_type = "军人证";
            idnumber = "北字第" + commonUtils.getNumber(8) + "号";
        } else {
            throw new InterruptedException("Wrong ID type: " + idtype);
        }
        
        caseInfo.setStudyNumber(studynumber);
        caseInfo.setName(name);
        caseInfo.setIDType(id_type);
        caseInfo.setIDNumber(idnumber);
        
        caseManagePage.StudyObjectNumberInput().sendKeys(studynumber);
        caseManagePage.NameInput().sendKeys(name);
        caseManagePage.IDTypeSelect().selectByVisibleText(id_type);
        caseManagePage.IDNumberInput().sendKeys(idnumber);
        caseManagePage.CenterSelect().selectByVisibleText(caseInfo.getCenterName());
        if (caseManagePage.GroupSelect() != null) {
            caseManagePage.GroupSelect().selectByVisibleText(caseInfo.getGroupName());
        }
        
        String date = caseManagePage.getDateInputInCaseDialog().getAttribute("value");
        String time = caseManagePage.getTimeInputInCaseDialog().getAttribute("value");
        caseInfo.setEnterTime(date + " " + time);
        Thread.sleep(1000);
        
        caseManagePage.AddEditCaseConfirmBtn().click();
        Thread.sleep(2000);
        if (caseManagePage.RandomAddCaseConfirmBtn() != null) {
            caseManagePage.RandomAddCaseConfirmBtn().click();
            Thread.sleep(2000);
        }
    }
	
	/**
	 * 编辑病例
	 * @param driver-WebDriver
	 * @param studynumber-研究对象编号
	 * @param name-姓名
	 * @param idtype-证件类型
	 * @param idnumber-证件号码
	 * @throws InterruptedException
	 */
	public static void EditCase(WebDriver driver, String studynumber, 
	        String name, String idtype, String idnumber) throws InterruptedException {
		CaseManagePage caseManagePage = new CaseManagePage(driver);
		
		//click change case button
		caseManagePage.ChangeCaseBtn(studynumber).click();
		Thread.sleep(1000);
		
		// edit case
        caseManagePage.StudyObjectNumberInput().clear();
        caseManagePage.NameInput().clear();
        caseManagePage.IDNumberInput().clear();
        caseManagePage.StudyObjectNumberInput().sendKeys(studynumber);
        caseManagePage.NameInput().sendKeys(name);
        caseManagePage.IDTypeSelect().selectByVisibleText(idtype);
        caseManagePage.IDNumberInput().sendKeys(idnumber);
        caseManagePage.AddEditCaseConfirmBtn().click();
        Thread.sleep(2000);
		
	}
	
	/**
	 * 编辑病例
	 * @param driver - WebDriver
	 * @param caseInfo - case object
	 * @param idtype - ID type
	 * @throws InterruptedException
	 */
    public static void EditCase(WebDriver driver, CaseInfo caseInfo, String idtype) 
            throws InterruptedException {
        CaseManagePage caseManagePage = new CaseManagePage(driver);
        String id_type = "";
        String idnumber = "";
        
        // generate data
        String studynumber = commonUtils.getNumber(8);
        String name = "病例" + studynumber;
        if (idtype.equals("id18")) {
            id_type = "身份证号码";
            idnumber = commonUtils.getNumber(18);
        } else if (idtype.equals("passport")) {
            id_type = "护照";
            idnumber = "E" + commonUtils.getNumber(8);
        } else if (idtype.equals("army")) {
            id_type = "军人证";
            idnumber = "北字第" + commonUtils.getNumber(8) + "号";
        } else {
            throw new InterruptedException("Wrong ID type: " + idtype);
        }
        
        //click change case button
        caseManagePage.ChangeCaseBtn(caseInfo.getStudyNumber()).click();
        Thread.sleep(1000);
        
        // edit case
        caseManagePage.StudyObjectNumberInput().clear();
        caseManagePage.NameInput().clear();
        caseManagePage.IDNumberInput().clear();
        caseManagePage.StudyObjectNumberInput().sendKeys(studynumber);
        caseManagePage.NameInput().sendKeys(name);
        caseManagePage.IDTypeSelect().selectByVisibleText(id_type);
        caseManagePage.IDNumberInput().clear();
        caseManagePage.IDNumberInput().sendKeys(idnumber);
        
        // update data
        caseInfo.setStudyNumber(studynumber);
        caseInfo.setName(name);
        caseInfo.setIDType(id_type);
        caseInfo.setIDNumber(idnumber);
        
        caseManagePage.AddEditCaseConfirmBtn().click();
        Thread.sleep(2000);
        
    }
    
    /**
     * 搜索病例
     * @param driver--WebDriver
     * @param name--姓名
     * @param id--编号
     * @param status--状态
     * @throws InterruptedException
     */
    public static void SearchCase(WebDriver driver, String name, String id, String status) 
            throws InterruptedException {
        CaseManagePage caseManagePage=new CaseManagePage(driver);
        
        //click search case button
        caseManagePage.SerachBtn().click();
        Thread.sleep(1000);
        
        //search case
        caseManagePage.SearchCaseNameInput().sendKeys(name);
        caseManagePage.SearchCaseNumberInput().sendKeys(id);
        caseManagePage.SearchCaseStatusSelect().selectByVisibleText(status);
        caseManagePage.SearchConfirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 搜索病例
     * @param driver--WebDriver
     * @param type--搜索的类型
     * @param value--填入的值
     * @throws InterruptedException
     */
    public static void SearchCase(WebDriver driver, String type, String value) 
            throws InterruptedException {
        CaseManagePage caseManagePage=new CaseManagePage(driver);
        
        //click search case button
        caseManagePage.SerachBtn().click();
        Thread.sleep(1000);
        
        //search case
        if (type.equals("name")) {
            caseManagePage.SearchCaseNameInput().sendKeys(value);
        } else if (type.equals("id")) {
            caseManagePage.SearchCaseNumberInput().sendKeys(value);
        } else if (type.equals("status")) {
            caseManagePage.SearchCaseStatusSelect().selectByVisibleText(value);
        } else {
            throw new InterruptedException("Wrong search type: " + type);
        }
        caseManagePage.SearchConfirmBtn().click();
        Thread.sleep(2000);
    }
	
	/**
	 * 删除病例
	 * @param driver--WebDriver
	 * @param studynumber--研究对象编号
	 * @param reason--删除原因
	 * @throws InterruptedException
	 */
	public static void DeleteCase(WebDriver driver, String studynumber, String reason) 
	        throws InterruptedException {
		CaseManagePage caseManagePage=new CaseManagePage(driver);
		
		//click delete case btn
		caseManagePage.DeleteCaseBtn(studynumber).click();
		Thread.sleep(1000);
		
		// delete case
		if (reason.equals("inputerror")) {
		    caseManagePage.DeleteCaseReasonInputErrorCheckbox().click();
		} else {
		    caseManagePage.DeleteCaseReasonOtherCheckbox().click();
		    caseManagePage.DeleteCaseReasonOtherInput().sendKeys(reason);
		}
		caseManagePage.ConfirmBtn().click();
		Thread.sleep(2000);
	}
}