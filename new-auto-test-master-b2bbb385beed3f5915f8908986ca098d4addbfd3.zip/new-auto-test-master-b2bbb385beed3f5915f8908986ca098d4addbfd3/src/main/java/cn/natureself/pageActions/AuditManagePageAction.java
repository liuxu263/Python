package cn.natureself.pageActions;

import org.openqa.selenium.WebDriver;

import cn.natureself.componentObjects.AuditInfo;
import cn.natureself.pageObjects.AuditManagePage;

/**
 * 质疑管理页面的操作类
 * 
 * @author lx
 */

public class AuditManagePageAction {
	
    /**
     * 添加质疑记录操作 - 表单页面
     * @param driver--WebDriver
     * @param text--质疑的记录文本
     * @param type - 点击哪个button (添加质疑/关闭质疑/回复)
     * @param close - 是否关闭质疑记录对话框
     * @throws InterruptedException
     */
    public static void AddAuditRecordAction(WebDriver driver, String text, String type, boolean close) throws InterruptedException {
        AuditManagePage auditManagePage = new AuditManagePage(driver);
        // audit record
        auditManagePage.AuditDialogTextArea().sendKeys(text);
        if (type.equals("add")) {
            auditManagePage.AuditDialogAddAuditBtn().click();
        } else if (type.equals("reply")) {
        	auditManagePage.AuditDialogReplyAuditBtn().click();
        } else {
        	auditManagePage.AuditDialogCloseAuditBtn().click();
        }
        if(close) {
            auditManagePage.AuditDialogCloseBtn().click();
        }
        Thread.sleep(1000);
    }
    
    /**
     * 添加质疑记录操作 - 质疑管理页面
     * @param driver--WebDriver
     * @param auditInfo - 质疑信息
     * @param text--质疑的记录文本
     * @param type - 点击哪个button (添加质疑/关闭质疑/回复)
     * @param close - 是否关闭质疑记录对话框
     * @throws InterruptedException
     */
    public static void AddAuditRecordAction(WebDriver driver, AuditInfo auditInfo, String text, String type, boolean close) throws InterruptedException {
        AuditManagePage auditManagePage = new AuditManagePage(driver);
        
        auditManagePage.getOperationBtn(auditInfo).click();
		Thread.sleep(1000);
		
        // audit record
        auditManagePage.AuditDialogTextArea().sendKeys(text);
        if (type.equals("add")) {
            auditManagePage.AuditDialogAddAuditBtn().click();
        } else if (type.equals("reply")) {
        	auditManagePage.AuditDialogReplyAuditBtn().click();
        } else {
        	auditManagePage.AuditDialogCloseAuditBtn().click();
        }
        if(close) {
            auditManagePage.AuditDialogCloseBtn().click();
        }
        Thread.sleep(1000);
    }
}