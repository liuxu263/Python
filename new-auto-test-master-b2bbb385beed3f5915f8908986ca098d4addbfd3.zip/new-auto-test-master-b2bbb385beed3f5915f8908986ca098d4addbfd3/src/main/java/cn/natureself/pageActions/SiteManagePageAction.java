package cn.natureself.pageActions;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cn.natureself.componentObjects.SiteInfo;
import cn.natureself.pageObjects.SiteManagePage;
import cn.natureself.utils.freeSSHdUpload;

/**
 * 机构设置页面操作类
 * 
 * @author Andy
 */

public class SiteManagePageAction {
    
    /**
     * 添加机构操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param sitename - 机构名称
     * @param sitecode - 机构编号
     * @param casenumber - 目标病例数
     * @throws InterruptedException
     */
    public static void addSite(WebDriver driver, String sitename, String sitecode, String casenumber)
            throws InterruptedException {
        SiteManagePage sitePage = new SiteManagePage(driver);

        // add site
        sitePage.addSiteBtn().click();
        Thread.sleep(1000);
        sitePage.siteNameInput().sendKeys(sitename);
        sitePage.siteCodeInput().sendKeys(sitecode);
        sitePage.siteCaseInput().sendKeys(casenumber);
        sitePage.confirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 添加机构操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param siteInfo - 机构信息
     * @throws InterruptedException
     */
    public static void addSite(WebDriver driver, SiteInfo siteInfo)
            throws InterruptedException {
        SiteManagePage sitePage = new SiteManagePage(driver);

        // add site
        sitePage.addSiteBtn().click();
        Thread.sleep(1000);
        sitePage.siteNameInput().sendKeys(siteInfo.getName());
        List<WebElement> info = sitePage.getInfoInAddSiteDialog();
        String province = info.get(0).getText();
        String type = info.get(1).getText();
        siteInfo.setProvince(province);
        siteInfo.setType(type);
        sitePage.siteCodeInput().sendKeys(siteInfo.getID());
        sitePage.siteCaseInput().sendKeys(siteInfo.getCaseNumber());
        sitePage.confirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 编辑中心操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param sitecode - 中心编号
     * @param casenumber - 病例数
     * @throws InterruptedException
     */
    public static void editSite(WebDriver driver, String sitecode, String casenumber)
            throws InterruptedException {
        SiteManagePage sitePage = new SiteManagePage(driver);

        // edit site
        sitePage.siteCodeInput().clear();
        sitePage.siteCaseInput().clear();
        sitePage.siteCodeInput().sendKeys(sitecode);
        sitePage.siteCaseInput().sendKeys(casenumber);
        sitePage.confirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 删除机构操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param sitename - 机构名称
     * @throws InterruptedException
     */
    public static void deleteSite(WebDriver driver, String sitename)
            throws InterruptedException {
        SiteManagePage sitePage = new SiteManagePage(driver);

        // delete site
        sitePage.deleteSiteBtn(sitename).click();
        // input site name
        if (sitePage.siteNameInputInDeleteDialog() != null) {
            sitePage.siteNameInputInDeleteDialog().sendKeys(sitename);
        }
        sitePage.confirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 上传随机表操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @param hostname - hostname
     * @param sitename - 机构名称
     * @throws IOException
     * @throws InterruptedException
     */
    public static void uploadRandomForm(WebDriver driver, String hostname, String sitename)
            throws IOException, InterruptedException {
        SiteManagePage sitePage = new SiteManagePage(driver);
        
        // upload form using autoit
        sitePage.uploadRandomFormBtn(sitename).click();
        Thread.sleep(2000);
        freeSSHdUpload.upload_random_form(hostname);
        Thread.sleep(5000);
    }
    
}