package cn.natureself.pageActions;

import org.openqa.selenium.WebDriver;

import cn.natureself.pageObjects.ProjectPage;

/**
 * 项目主页操作类
 * 
 * @author Andy
 */

public class ProjectPageAction {
    
}