package cn.natureself.pageActions;

import org.openqa.selenium.WebDriver;

import cn.natureself.pageObjects.GroupManagePage;

/**
 * 分组和阶段管理页面操作类
 * 
 * @author lx
 */

public class GroupManagePageAction {
	/**
	 * 添加阶段
	 * @param driver--WebDriver
	 * @param groupname - 分组名
	 * @param stagename--阶段名称
	 * @param stageuid--阶段uid
	 * @throws InterruptedException
	 */
	public static void AddStage(WebDriver driver,String groupname, String stagename, String stageuid) 
	        throws InterruptedException {
		GroupManagePage groupManagePage = new GroupManagePage(driver);
		
		// active the group
		groupManagePage.ActiveGroupBtn(groupname).click();
		Thread.sleep(1000);
		
		// add stage
		groupManagePage.SetStageBtn().click();
		Thread.sleep(1000);
		groupManagePage.StageNameInput().sendKeys(stagename);
		groupManagePage.StageNumberInput().sendKeys(stageuid);
		Thread.sleep(1000);
		groupManagePage.AddStageBtn().click();
		Thread.sleep(1000);
		groupManagePage.AddStageConfirmBtn().click();
		Thread.sleep(2000);
		
	}
	
	/**
	 * 添加分组
	 * @param driver--WebDriver
	 * @param groupname--分组名
	 * @param groupuid--分组UID
	 * @throws InterruptedException
	 */
	public static void AddGroup(WebDriver driver, String groupname, String groupuid) 
	        throws InterruptedException {
		GroupManagePage groupManagePage = new GroupManagePage(driver);
		groupManagePage.AddGroupBtn().click();
		Thread.sleep(1000);
		groupManagePage.GroupNameInput().sendKeys(groupname);
		groupManagePage.GroupUIDInput().sendKeys(groupuid);
		Thread.sleep(1000);
		if (groupManagePage.ConfirmBtn().getAttribute("disabled") == null) {
		    groupManagePage.ConfirmBtn().click();
		}
		Thread.sleep(2000);
	}
	
	/**
	 * 删除阶段
     * @param driver--WebDriver
     * @param groupname--分组名
     * @param stagename--阶段名
     * @throws InterruptedException
     */
    public static void deleteStage(WebDriver driver, String groupname, String stagename) 
            throws InterruptedException {
        GroupManagePage groupManagePage = new GroupManagePage(driver);
        
        groupManagePage.ActiveGroupBtn(groupname).click();
        Thread.sleep(1000);
        groupManagePage.SetStageBtn().click();
        Thread.sleep(1000);
        groupManagePage.DeleteStageBtn(stagename).click();
        Thread.sleep(1000);
        if (groupManagePage.inputInDeleteDialog() != null) {
            groupManagePage.inputInDeleteDialog().sendKeys(stagename);
        }
        Thread.sleep(1000);
        groupManagePage.ConfirmBtn().click();
        Thread.sleep(1000);
        groupManagePage.AddStageConfirmBtn().click();
        Thread.sleep(2000);
    }
    
    /**
     * 删除分组
     * @param driver--WebDriver
     * @param groupname--分组名
     * @throws InterruptedException
     */
    public static void deleteGroup(WebDriver driver, String groupname) 
            throws InterruptedException {
        GroupManagePage groupManagePage = new GroupManagePage(driver);
        
        groupManagePage.ActiveGroupBtn(groupname).click();
        Thread.sleep(1000);
        groupManagePage.DeleteGroupBtn(groupname).click();
        Thread.sleep(1000);
        if (groupManagePage.inputInDeleteDialog() != null) {
            groupManagePage.inputInDeleteDialog().sendKeys(groupname);
        }
        Thread.sleep(1000);
        groupManagePage.ConfirmBtn().click();
        
        Thread.sleep(2000);
    }
}