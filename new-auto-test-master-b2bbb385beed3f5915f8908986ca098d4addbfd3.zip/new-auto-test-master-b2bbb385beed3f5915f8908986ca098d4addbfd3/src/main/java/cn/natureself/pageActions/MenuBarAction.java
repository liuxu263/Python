package cn.natureself.pageActions;

import org.openqa.selenium.WebDriver;

import cn.natureself.pageObjects.MenuBar;

/**
 * 导航菜单操作类
 * 
 * @author Andy
 */

public class MenuBarAction {
    /**
     * 进入个人主页操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @throws InterruptedException
     */
    public static void enterPersonalInfoPage(WebDriver driver) 
            throws InterruptedException {
        MenuBar menuBar = new MenuBar(driver);
        menuBar.personalInfoLink().click();
        Thread.sleep(2000);
    }
    
    /**
     * 登出操作
     * 
     * @author Andy
     * @param driver - WebDriver
     * @throws InterruptedException
     */
    public static void logout(WebDriver driver) 
            throws InterruptedException {
        MenuBar menuBar = new MenuBar(driver);
        menuBar.logoutLink().click();
        Thread.sleep(2000);
    }
}