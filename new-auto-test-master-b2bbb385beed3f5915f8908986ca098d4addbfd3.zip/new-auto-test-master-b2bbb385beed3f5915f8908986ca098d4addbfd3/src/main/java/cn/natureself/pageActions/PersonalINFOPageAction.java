package cn.natureself.pageActions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;

import cn.natureself.pageObjects.PersonalInfoPage;

/**
 * 个人信息页面操作类
 * 
 * @author lx
 */
public class PersonalInfoPageAction {
    /**
     * 修改密码
     * 
     * @param driver--WebDriver
     * @param oldPWD--旧密码
     * @param newPWD--新密码
     * @param renewPWD--新密码
     * @throws InterruptedException
     */
    public static void ChangePwdAction(WebDriver driver, String oldPWD, String newPWD, String renewPWD) 
    		throws InterruptedException {
        PersonalInfoPage personalInfoPage = new PersonalInfoPage(driver);

        personalInfoPage.ChangePwdOldPwdInput().clear();
        personalInfoPage.ChangePwdOldPwdInput().sendKeys(oldPWD);
        personalInfoPage.ChangePwdNewPwdInput().clear();
        personalInfoPage.ChangePwdNewPwdInput().sendKeys(newPWD);
        personalInfoPage.ChangePwdNewPwdAgainInput().clear();
        personalInfoPage.ChangePwdNewPwdAgainInput().sendKeys(renewPWD);
        if (personalInfoPage.ChangePwdConfirmBtn().getAttribute("disabled") == null) {
            personalInfoPage.ChangePwdConfirmBtn().click();
        }
        Thread.sleep(1000);
    }

    /**
     * 编辑个人信息页面的个人信息
     * 
     * @param driver--WebDriver
     * @param name--姓名
     * @param department--科室
     * @param title--职称
     * @param company--工作单位
     * @param address--地址
     * @param phone--手机
     * @throws InterruptedException
     */
    public static void EditBasicInfoAction(WebDriver driver, String name, String department, String title, String company,
            String address, String phone) throws InterruptedException {
        PersonalInfoPage personalInfoPage = new PersonalInfoPage(driver);
        personalInfoPage.EditPersonalInfoBtn().click();
        Thread.sleep(1000);
        personalInfoPage.EditPersonalInfoNameInput().clear();
        personalInfoPage.EditPersonalInfoDepartmentInput().clear();
        personalInfoPage.EditPersonalInfoTitleInput().clear();
        personalInfoPage.EditPersonalInfoCompanyInput().clear();
        personalInfoPage.EditPersonalInfoCompanyLocationInput().clear();
        personalInfoPage.EditPersonalInfoPhoneInput().clear();
        
        personalInfoPage.EditPersonalInfoNameInput().sendKeys(name);
        personalInfoPage.EditPersonalInfoDepartmentInput().sendKeys(department);
        personalInfoPage.EditPersonalInfoTitleInput().sendKeys(title);
        personalInfoPage.EditPersonalInfoCompanyInput().sendKeys(company);
        personalInfoPage.EditPersonalInfoCompanyLocationInput().sendKeys(address);
        personalInfoPage.EditPersonalInfoPhoneInput().sendKeys(phone);
        personalInfoPage.EditPersonalInfoConfirmBtn().click();
        Thread.sleep(1000);
    }

    /**
     * 编辑个人信息页面的个人专注领域
     * 
     * @param driver--WebDriver
     * @param n--指定选定的标签的编号
     * @return name - 标签的名字
     * @throws InterruptedException
     */
    public static String EditPersionalFocusAction(WebDriver driver, int n) 
    		throws InterruptedException {
        PersonalInfoPage personalInfoPage = new PersonalInfoPage(driver);
        personalInfoPage.EditPersonalFocusBtn().click();
        Thread.sleep(1000);
        personalInfoPage.EditPersonalFocusCheckbox().get(n-1).click();
        String name = personalInfoPage.EditPersonalFocusCheckbox().get(n-1).getText();
        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView()", personalInfoPage.EditPersonalFocusSaveBtn());
        personalInfoPage.EditPersonalFocusSaveBtn().click();
        Thread.sleep(1000);
        
        return name;
    }

    /**
     * 编辑个人信息页面的科研成果
     * 
     * @param driver--WebDriver
     * @param type--指定选择的类型
     * @param title--标题
     * @param details--内容
     * @param link--链接
     * @throws InterruptedException
     */
    public static void AddPersonalWorkAction(WebDriver driver, String type, String title, String details, String link)
            throws InterruptedException {
        PersonalInfoPage personalInfoPage = new PersonalInfoPage(driver);
        personalInfoPage.AddPersonalWorkBtn().click();
        Thread.sleep(1000);
        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView()", personalInfoPage.PersonalWorkSaveBtn());
        personalInfoPage.PersonalWorkTypeSelect().selectByVisibleText(type);
        personalInfoPage.PersonalWorkTitleInput().sendKeys(title);
        personalInfoPage.PersonalWorkDetailsInput().sendKeys(details);
        personalInfoPage.PersonalWorkLinkInput().sendKeys(link);
        personalInfoPage.PersonalWorkSaveBtn().click();
        Thread.sleep(1000);
    }
    
    /**
     * 编辑科研成果
     * 
     * @param driver--WebDriver
     * @param name--原标题
     * @param type--类型
     * @param title--标题
     * @param details--内容
     * @param link--链接
     * @throws InterruptedException
     */
    public static void EditPersonalWorkAction(WebDriver driver, String name, String type, String title, String details, String link)
            throws InterruptedException {
        PersonalInfoPage personalInfoPage = new PersonalInfoPage(driver);
        personalInfoPage.getPersonalWorkEditBtn(name).click();
        Thread.sleep(1000);

        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView()", personalInfoPage.EditPersonalWorkSaveBtn());
        personalInfoPage.PersonalWorkTypeSelect().selectByVisibleText(type);
        personalInfoPage.PersonalWorkTitleInput().clear();
        personalInfoPage.PersonalWorkTitleInput().sendKeys(title);
        personalInfoPage.PersonalWorkDetailsInput().clear();
        personalInfoPage.PersonalWorkDetailsInput().sendKeys(details);
        personalInfoPage.PersonalWorkLinkInput().clear();
        personalInfoPage.PersonalWorkLinkInput().sendKeys(link);
        personalInfoPage.EditPersonalWorkSaveBtn().click();
        Thread.sleep(1000);
    }
    
    /**
     * 删除科研成果
     * 
     * @param driver--WebDriver
     * @param title--标题
     * @throws InterruptedException
     */
    public static void DeletePersonalWorkAction(WebDriver driver, String title)
            throws InterruptedException {
        PersonalInfoPage personalInfoPage = new PersonalInfoPage(driver);
        personalInfoPage.getPersonalWorkEditBtn(title).click();
        Thread.sleep(1000);
        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView()", personalInfoPage.PersonalWorkDeleteBtn());
        personalInfoPage.PersonalWorkDeleteBtn().click();
        Thread.sleep(1000);
        personalInfoPage.ConfirmBtn().click();
        Thread.sleep(1000);
    }
}
