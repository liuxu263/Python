package cn.natureself.pageActions;

import org.openqa.selenium.WebDriver;

import cn.natureself.pageObjects.DictionaryPage;

/**
 * 术语字典页面操作类
 * 
 * @author Andy
 */

public class DictionaryPageAction {
    
}