package cn.natureself.pageActions;

import org.openqa.selenium.WebDriver;

import cn.natureself.pageObjects.FormTaskPage;

/**
 * 表单任务页面操作类
 * 
 * @author lx
 */

public class FormTaskPageAction {

    /**
     * 接管表单任务
     * @param driver--Webdriver
     * @param caseID - 研究对象编号
     * @param stageName - 阶段名
     * @throws InterruptedException
     */
    public void UndertakeAction(WebDriver driver, String caseID, String stageName) 
            throws InterruptedException {
        FormTaskPage formTaskPage = new FormTaskPage(driver);
        
        formTaskPage.getUndertakeBtn(caseID, stageName).click();
        formTaskPage.ConfirmBtn().click();
        Thread.sleep(500);

    }

    /**
     * 搜索表单任务
     * @param driver--Webdriver
     * @param name--搜索框输入的名字
     * @param number--搜索框输入的编号
     * @throws InterruptedException
     */
    public void SearchAction(WebDriver driver, String name, String number) 
            throws InterruptedException {
        FormTaskPage formTaskPage = new FormTaskPage(driver);
        
        formTaskPage.SearchBtn().click();
        formTaskPage.SearchNameInput().sendKeys(name);
        formTaskPage.SearchNumberInput().sendKeys(number);
        formTaskPage.ConfirmBtn().click();
        Thread.sleep(500);
    }
    
    /**
     * 自定义搜索表单任务
     * @param driver--Webdriver
     * @param type--搜索的类型
     * @param value--填入的值
     * @throws InterruptedException
     */
    public void CustomSearchAction(WebDriver driver, String type, String value) 
            throws InterruptedException {
        FormTaskPage formTaskPage = new FormTaskPage(driver);
        
        formTaskPage.SearchBtn().click();
        if (type.equals("name")) {
            formTaskPage.SearchNameInput().sendKeys(value);
        } else {
            formTaskPage.SearchNumberInput().sendKeys(value);
        }
        formTaskPage.ConfirmBtn().click();
        Thread.sleep(500);
    }

}