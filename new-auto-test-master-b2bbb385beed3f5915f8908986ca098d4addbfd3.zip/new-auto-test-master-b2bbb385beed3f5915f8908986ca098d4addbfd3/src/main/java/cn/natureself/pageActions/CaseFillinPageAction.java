package cn.natureself.pageActions;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cn.natureself.pageObjects.CaseFillinPage;

/**
 * 填写病例表单页面操作类
 * 
 * @author Andy
 */
public class CaseFillinPageAction {
	
    /**
     * 填写表单中的text文本框
     * @param driver - WebDriver
     * @param text - input text
     */
    public static void fillinTextInputCtrl(WebDriver driver, String text) {
    	CaseFillinPage fillinPage = new CaseFillinPage(driver);
    	
    	List<WebElement> inputs = fillinPage.getTextInputCtrlInForm();
    	for (WebElement input:inputs) {
    		input.clear();
    		input.sendKeys(text);
    	}
    }
    
    /**
     * 填写表单中的text文本框
     * @param driver - WebDriver
     * @param index - index of input
     * @param text - input text
     */
    public static void fillinTextInputCtrl(WebDriver driver, int index, String text) {
    	CaseFillinPage fillinPage = new CaseFillinPage(driver);
    	
    	List<WebElement> inputs = fillinPage.getTextInputCtrlInForm();
    	inputs.get(index).clear();
    	inputs.get(index).sendKeys(text);
    }
    
    /**
     * 填写表单中的number框
     * @param driver - WebDriver
     * @param number - input number
     */
    public static void fillinNumberCtrl(WebDriver driver, String number) {
    	CaseFillinPage fillinPage = new CaseFillinPage(driver);
    	
    	List<WebElement> inputs = fillinPage.getNumberCtrlInForm();
    	for (WebElement input:inputs) {
    		input.clear();
    		input.sendKeys(number);
    	}
    }
    
    /**
     * 填写表单中的number框
     * @param driver - WebDriver
     * @param index - index of input
     * @param number - input number
     */
    public static void fillinNumberCtrl(WebDriver driver, int index, String number) {
    	CaseFillinPage fillinPage = new CaseFillinPage(driver);
    	
    	List<WebElement> inputs = fillinPage.getNumberCtrlInForm();
    	inputs.get(index).clear();
    	inputs.get(index).sendKeys(number);
    }
    
    /**
     * 终止病例填写
     * @param driver - WebDriver
     * @param stage - 阶段
     * @throws InterruptedException 
     */
    public static void abortCaseFillin(WebDriver driver, String stage) throws InterruptedException {
    	CaseFillinPage fillinPage = new CaseFillinPage(driver);
    	
        fillinPage.getAbortCaseBtn().click();
        Thread.sleep(1000);
        fillinPage.getDatePickerInAbortCaseDialog().click();
        Thread.sleep(1000);
        fillinPage.getTodayBtnInDatePicker().click();
        Thread.sleep(1000);
        fillinPage.getSelectInAbortCaseDialog().selectByVisibleText(stage);
        Thread.sleep(1000);
        fillinPage.getCheckboxInAbortCaseDialog().get(0).click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
    }
}