package cn.natureself.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;



/**
 * 分组和阶段管理页面对象类
 * 
 * @author lx
 */
public class GroupManagePage {
	private WebDriver driver;
	
	/**
	 * 传递driver
	 * @param driver--WebDriver
	 * 
	 */
	public GroupManagePage(WebDriver driver ) {
		this.driver=driver;
	}

	/**
	 * 获得阶段设置按钮
	 * 
	 * @return WebElement
	 */
	public WebElement SetStageBtn() {
		WebElement element = driver.findElement(By.xpath(".//a[contains(@ng-click, 'editEventsPopup')]"));
		return element;

	}
	
	/**
     * 获得保存设置按钮
     * 
     * @return WebElement
     */
    public WebElement SaveStageBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[contains(@ng-click, 'saveEventCrfs')]"));
        return element;

    }
	
	/**
	 * 获得删除分组按钮
	 * @param name - 分组名
	 * @return WebElement
	 */
	public WebElement DeleteGroupBtn(String name) {
		WebElement element = null;
        WebElement ul = driver.findElement(By.xpath(".//ul[@class='tab-btns list-unstyled']"));
        List<WebElement> groups = ul.findElements(By.xpath(".//a[contains(@ui-sref, 'm.study.groupevents')]"));
        for (WebElement group:groups) {
            if (group.getText().contains(name)) {
                element = group.findElement(By.tagName("button"));
                break;
            }
        }
        
		return element;
	}
	
    /**
     * 获得分组按钮
     * @param name - 分组名
     * @return WebElement
     */
    public WebElement ActiveGroupBtn(String name) {
    	WebElement element = null;
        WebElement ul = driver.findElement(By.xpath(".//ul[@class='tab-btns list-unstyled']"));
        List<WebElement> groups = ul.findElements(By.xpath(".//a[contains(@ui-sref, 'm.study.groupevents')]"));
        for (WebElement group:groups) {
            if (group.getText().contains(name)) {
                element = group;
                break;
            }
        }
        
        return element;
    }
	
	/**
     * 获得所有分组按钮
     * 
     * @return WebElement list 
     */
    public List<WebElement> getGroups() {
        WebElement ul = driver.findElement(By.xpath(".//ul[@class='tab-btns list-unstyled']"));
        List<WebElement> groups = ul.findElements(By.xpath(".//a[contains(@ui-sref, 'm.study.groupevents')]"));
        
        return groups;
    }
	
	/**
	 * 获得添加分组按钮
	 * 
	 * @return WebElement
	 */
	public WebElement AddGroupBtn() {
		WebElement element = driver.findElement(By.xpath(".//button[contains(@ng-click, 'addGroupPopup')]"));
		return element;

	}
	
	/**
	 * 获得列表中的分配表单给阶段的checkbox
	 * 
	 * @return WebElement list
	 */
	public List<WebElement> AssignFormCheckbox() {
	    WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
	    List<WebElement> elements = table.findElements(By.xpath(".//label[@class='wrapper checkbox-box']"));
		return elements;

	}
	
	/**
     * 获得列表中的分配表单给阶段的checkbox的input元素，用于确认是否选中
     * 
     * @return WebElement list
     */
    public List<WebElement> AssignFormCheckboxInput() {
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> elements = table.findElements(By.xpath(".//input[@type='checkbox']"));
        return elements;

    }
	
	/**
     * 获得列表的表头
     * 
     * @return WebElement list
     */
    public List<WebElement> getHeadsFromTable() {
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> elements = table.findElements(By.tagName("th"));
        return elements;

    }
	
	/**
	 * 获得添加阶段对话框中的阶段名称输入框
	 * 
	 * @return WebElement
	 */
	public WebElement StageNameInput() {
		WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.newName']"));
		return element;

	}
	
	/**
	 * 获得添加阶段对话框中的阶段UID输入框
	 * 
	 * @return WebElement
	 */
	public WebElement StageNumberInput() {
		WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.newUid']"));
		return element;

	}
	/**
	 * 获得添加阶段按钮
	 * 
	 * @return WebElement
	 */
	public WebElement AddStageBtn() {
		WebElement element = driver.findElement(By.xpath(".//button[@ng-click='vm.addEvent()']"));
		return element;

	}
	
	/**
	 * 获得删除阶段按钮
	 * @param stagename - 阶段名
	 * @return WebElement
	 */
	public WebElement DeleteStageBtn(String stagename) {
		WebElement element = null;
        WebElement div = driver.findElement(By.xpath(".//div[@class='modal-container sm-modal ng-scope']"));
        WebElement table = div.findElement(By.xpath(".//table[@class='table']/tbody"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            WebElement input = cols.get(0).findElement(By.tagName("input"));
            if (input.getAttribute("value").equals(stagename)) {
                element = cols.get(2).findElement(By.xpath(".//a[contains(@ng-click, 'deleteEvent')]"));
                break;
            }
        }
        
        return element;
	}
	
	/**
     * 获得删除分组/阶段对话框中的输入框
     * 
     * @return WebElement
     */
    public WebElement inputInDeleteDialog() {
    	WebElement element = null;
        try {
            element = driver.findElement(By.xpath(".//input[contains(@ng-blur, 'vm.deleteValidation')]"));
        } catch (NoSuchElementException e) {
            element = null;
        }
        return element;
    }
	
	/**
	 * 获得添加分组对话框中的名称输入框
	 * 
	 * @return WebElement
	 */
	public WebElement GroupNameInput() {
		WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.newGroup.name']"));
		return element;

	}
	
	/**
	 * 获得添加分组对话框中的uid输入框
	 * 
	 * @return WebElement
	 */
	public WebElement GroupUIDInput() {
		WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.newGroup.uid']"));
		return element;

	}
	
	/**
	 * 获得对话框中的确认按钮
	 * 
	 * @return WebElement
	 */
	public WebElement ConfirmBtn() {
		WebElement element = driver.findElement(By.xpath(".//button[@class='modal-confirm-btn']"));
		return element;

	}
	
	/**
     * 获得添加阶段对话框中的确认按钮
     * 
     * @return WebElement
     */
    public WebElement AddStageConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-confirm-btn']"));
        return element;

    }
	
	/**
	 * 获得对话框中的取消按钮
	 * 
	 * @return WebElement
	 */
	public WebElement CancelBtn() {
		WebElement element = driver.findElement(By.xpath(".//button[@class='modal-cancel-btn']"));
		return element;

	}
	
}
