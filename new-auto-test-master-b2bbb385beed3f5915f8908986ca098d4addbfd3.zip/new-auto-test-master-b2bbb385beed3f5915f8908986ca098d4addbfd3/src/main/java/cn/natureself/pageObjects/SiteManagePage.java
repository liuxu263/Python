package cn.natureself.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;
import java.util.List;

/**
 * 机构设置页面对象类
 * 
 * @author Andy
 */
public class SiteManagePage {
    private WebDriver driver;

    public SiteManagePage(WebDriver driver) {
        this.driver = driver;
    }
   
    /**
     * 获得添加机构按钮
     * @return WebElement
     */
    public WebElement addSiteBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ng-click='vm.addsitePopup()']"));
        return element;
    }
    
    /**
     * 获得机构列表中的所有行
     * @return WebElement list
     */
    public List<WebElement> getLinesOfSiteTable() {
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']/tbody"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        
        return rows;
    }
    
    /**
     * 获得机构列表中的相应机构行的编辑按钮
     * @param sitename - 列表里的机构名称
     * @return WebElement
     */
    public WebElement editSiteBtn(String sitename) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(0).getText().equals(sitename)) {
                element = cols.get(5).findElement(By.xpath(".//a[@ng-click='vm.editsitePopup(site)']"));
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得机构列表中的相应机构的行
     * @param sitename - 列表里的机构名称
     * @return WebElement
     */
    public WebElement getLineOfSite(String sitename) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(0).getText().equals(sitename)) {
                element = row;
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得编辑机构对话框里自动生成的信息
     * @return WebElement list
     */
    public List<WebElement> getInfoInEditSiteDialog() {
        WebElement form = driver.findElement(By.xpath(".//ng-form[@name='editSiteForm']"));
        List<WebElement> list = form.findElements(By.xpath(".//i[@class='site-detail ng-binding']"));
        return list;
    }
    
    /**
     * 获得添加机构对话框里自动生成的信息
     * @return WebElement list
     */
    public List<WebElement> getInfoInAddSiteDialog() {
        WebElement form = driver.findElement(By.xpath(".//ng-form[@name='addSiteForm']"));
        List<WebElement> list = form.findElements(By.xpath(".//i[@class='site-detail ng-binding']"));
        return list;
    }
    
    /**
     * 获得机构列表中的相应机构行的删除按钮
     * @param sitename - 列表里的机构名称
     * @return WebElement
     */
    public WebElement deleteSiteBtn(String sitename) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(0).getText().equals(sitename)) {
                element = cols.get(5).findElement(By.xpath(".//a[@ng-click='vm.deleteSite(site)']"));
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得机构列表中的相应机构行的上传随机表按钮
     * @param sitename - 列表里的机构名称
     * @return WebElement
     */
    public WebElement uploadRandomFormBtn(String sitename) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(0).getText().equals(sitename)) {
                element = cols.get(6).findElement(By.xpath(".//a[contains(@ngf-select, 'vm.uploadRandFile')]"));
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得添加机构对话框里的名称输入框
     * @return WebElement
     */
    public WebElement siteNameInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@class='site_name_inputter']"));
        return element;
    }
    
    /**
     * 获得添加/编辑机构对话框里的机构编号输入框
     * @return WebElement
     */
    public WebElement siteCodeInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='siteCode']"));
        return element;
    }
    
    /**
     * 获得添加/编辑机构对话框里的病例数输入框
     * @return WebElement
     */
    public WebElement siteCaseInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='siteCase']"));
        return element;
    }
    
    /**
     * 获得删除机构对话框里的输入框
     * @return WebElement
     */
    public WebElement siteNameInputInDeleteDialog() {
    	WebElement element = null;
        try {
            element = driver.findElement(By.xpath(".//input[contains(@ng-blur, 'vm.deleteValidation')]"));
        } catch (NoSuchElementException e) {
            element = null;
        }
        return element;
    }
    
    /**
     * 获得对话框里的取消按钮
     * @return WebElement
     */
    public WebElement cancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-cancel-btn']"));
        return element;
    }
    
    /**
     * 获得对话框里的确定按钮
     * @return WebElement
     */
    public WebElement confirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-confirm-btn']"));
        return element;
    }
}
