package cn.natureself.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cn.natureself.utils.UIStrings;

import org.openqa.selenium.NoSuchElementException;

/**
 * 项目主页的对象类
 * 
 * @author Andy
 */
public class ProjectPage {
	private WebDriver driver;

	public ProjectPage(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * 获得今日提醒模块里的按钮
	 * 
	 * @param name
	 *            - 按钮名
	 * @return WebElement
	 */
	public WebElement getItemInRemindBlock(String name) {
		WebElement element = null;
		// Get study detail info block
		WebElement info = getBlock(UIStrings.PROJECT_REMIND_BLOCK);

		try {
			if (name.equals(UIStrings.MENU_SITE_MANAGE)) {
				element = info.findElement(By.xpath(".//a[@ui-sref='m.study.sites']"));
			} else if (name.equals(UIStrings.MENU_ROLE_MANAGE)) {
				element = info.findElement(By.xpath(".//a[@ui-sref='m.study.roles']"));
			} else if (name.equals(UIStrings.MENU_FORM_MANAGE)) {
				element = info.findElement(By.xpath(".//a[@ui-sref='m.study.crfs']"));
			} else if (name.equals(UIStrings.MENU_GROUP_MANAGE)) {
				element = info.findElement(By.xpath(".//a[@ui-sref='m.study.groupevents']"));
			} else if (name.equals(UIStrings.MENU_CASE_MANAGE)) {
				element = info.findElement(By.xpath(".//a[@ui-sref='m.study.cases']"));
			} else if (name.equals(UIStrings.MENU_FORM_TASK)) {
				element = info.findElement(By.xpath(".//a[@ui-sref='m.study.caseEvents']"));
			} else if (name.equals(UIStrings.MENU_ADD_CASE)) {
				element = info.findElement(
						By.xpath(".//a[contains(@ui-sref, 'm.study.cases') and contains(@ui-sref, 'study_detail')]"));
			} else if (name.equals(UIStrings.MENU_WEATHER)) {
				element = info.findElement(By.xpath(".//a[href='http://106.37.208.228:8082/']"));
			} else {
				System.out.println("Cannot find element: " + name);
			}
		} catch (NoSuchElementException e) {
			return null;
		}

		return element;
	}

	/**
	 * 获得项目主页中的模块
	 * 
	 * @param name
	 *            - 模块名
	 * @return WebElement
	 */
	public WebElement getBlock(String name) {
		WebElement element = null;

		try {
			if (name.equals(UIStrings.PROJECT_REMIND_BLOCK)) {
				element = driver.findElement(By.xpath(".//div[contains(@class, 'info panel')]"));
			} else if (name.equals(UIStrings.PROJECT_INFO_BLOCK)) {
				element = driver.findElement(By.xpath(".//div[contains(@class, 'status panel')]"));
			} else if (name.equals(UIStrings.PROJECT_PROGRESS_BLOCK)) {
				element = driver.findElement(By.xpath(".//div[contains(@class, 'iprogress panel')]"));
			} else if (name.equals(UIStrings.PROJECT_FILE_BLOCK)) {
				element = driver.findElement(By.xpath(".//div[contains(@class, 'file panel')]"));
			} else {
				System.out.println("Cannot find block element: " + name);
			}
		} catch (NoSuchElementException e) {
			return null;
		}

		return element;
	}

	/**
	 * 获得查看项目列表link
	 * 
	 * @return WebElement
	 */
	public WebElement projectListLink() {
		WebElement element = driver.findElement(By.xpath(".//a[@ui-sref='m.studies']"));
		return element;
	}

	/**
	 * 获得项目名称
	 * 
	 * @return WebElement
	 */
	public WebElement projectNameLink() {
		WebElement element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.detail']"));
		return element;
	}

	/**
	 * 获得项目状况中的信息
	 * 
	 * @param name
	 *            - 信息名
	 * @return String
	 */
	public String getItemInStatusBlock(String name) {
		String value = "";
		// Get project status block
		WebElement block = getBlock(UIStrings.PROJECT_INFO_BLOCK);
		List<WebElement> info = block.findElements(By.tagName("strong"));
		
		if (name.equals("name")) {
			value = info.get(0).getText();
		} else if (name.equals("date")) {
			value = info.get(1).getText();
		} else if (name.equals("status")) {
			value = info.get(2).getText();
		} else if (name.equals("caseNumber")) {
			value = info.get(3).getText();
		} else if (name.equals("type")) {
			value = info.get(4).getText();
		} else if (name.equals("center")) {
			value = block.findElement(By.xpath(".//div[contains(text(), '所在机构:')]")).getText().replace("所在机构:", "");
		} else if (name.equals("cenCaseNum")) {
			value = block.findElement(By.xpath(".//div[contains(text(), '目标病例数:')]")).getText().replace("目标病例数:", "");
		} else {
			System.out.println("Wrong param");
		}

		return value;
	}
	
	/**
	 * 获得今日提醒中的信息
	 * @return String
	 */
	public List<WebElement> getInfoInRemindBlock() {
		WebElement block = getBlock(UIStrings.PROJECT_REMIND_BLOCK);
		WebElement div = block.findElement(By.xpath(".//div[@class='detail-info-title']"));
		
		List<WebElement> info = div.findElements(By.tagName("strong"));
		
		return info;
	}

	/**
	 * 获得项目进度模块里的radio button
	 * 
	 * @param name
	 *            - 选项名称
	 * @return WebElement
	 */
	public WebElement getItemInProgressBlock(String name) {
		WebElement element = null;
		// Get project progress block
		WebElement progress = getBlock(UIStrings.PROJECT_PROGRESS_BLOCK);

		try {
			if (name.equals(UIStrings.PROJECT_PROGRESS_CASE)) {
				element = progress.findElement(By.xpath(".//input[@type='radio' and @value='sites_caseStates']"));
			} else if (name.equals(UIStrings.PROJECT_PROGRESS_GROUP)) {
				element = progress.findElement(By.xpath(".//input[@type='radio' and @value='sites_groups']"));
			} else if (name.equals(UIStrings.PROJECT_PROGRESS_STAGE)) {
				element = progress.findElement(By.xpath(".//input[@type='radio' and @value='sites_events']"));
			} else {
				System.out.println("Cannot find element: " + name);
			}
		} catch (NoSuchElementException e) {
			return null;
		}
		return element;
	}

	/**
	 * 获得文件管理模块中的按钮
	 * 
	 * @param name
	 *            - 按钮名称
	 * @return WebElement
	 */
	public WebElement getItemInFileBlock(String name) {
		WebElement element = null;
		// Get project file block
		WebElement file = getBlock("临床试验文件管理");

		try {
			if (name.equals("批量操作")) {
				element = file.findElement(By.xpath(".//button[contains(@class, 'study-detail-file-batch-select')]"));
			} else if (name.equals("下载")) {
				element = file.findElement(By.xpath(".//button[contains(@class, 'file-btn-downloadFile')]"));
			} else if (name.equals("上传")) {
				element = file.findElement(By.xpath(".//button[contains(@class, 'file-btn-uploadInDir')]"));
			} else if (name.equals("删除")) {
				element = file.findElement(By.xpath(".//button[contains(@class, 'file-btn-deleteFile')]"));
			} else if (name.equals("重命名")) {
				element = file.findElement(By.xpath(".//button[contains(@class, 'file-btn-renameFile')]"));
			} else if (name.equals("新建文件夹")) {
				element = file.findElement(By.xpath(".//button[contains(@class, 'ffile-btn-createFolder')]"));
			} else {
				System.out.println("Cannot find element: " + name);
			}
		} catch (NoSuchElementException e) {
			return null;
		}

		return element;
	}
}