package cn.natureself.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import cn.natureself.componentObjects.AuditInfo;

/**
 * 质疑管理页面对象类
 * 
 * @author lx
 */
public class AuditManagePage {
    private WebDriver driver;

    /**
     * 传递driver
     * 
     * @param driver - WebDriver
     */
    public AuditManagePage(WebDriver driver) {
        this.driver = driver;
    }

    /**
     * 获得质疑的状态的分组的按钮
     * @return WebElement list
     */
    public List<WebElement> getStatusGroups() {
        WebElement ul = driver.findElement(By.xpath(".//ul[@class='list-unstyled tab-btns']"));
        List<WebElement> groups = ul.findElements(By.xpath(".//a[contains(@ui-sref, 'm.study.audits')]"));
        return groups;

    }
    
    /**
     * 获得某个状态的分组的按钮
     * @param status - 状态
     * @return WebElement
     */
    public WebElement getStatusGroupBtn(String status) {
        WebElement ul = driver.findElement(By.xpath(".//ul[@class='list-unstyled tab-btns']"));
        String path = ".//a[contains(@ui-sref, 'm.study.audits') and contains(text(), '" + status + "')]";
        WebElement element = ul.findElement(By.xpath(path));
        return element;
    }


    /**
     * 获得搜索按钮
     * 
     * @return WebElement
     */
    public WebElement SearchBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[contains(@ng-click, 'searchAuditPopup')]"));
        return element;

    }

    /**
     * 获得质疑列表中的所有行
     * 
     * @return WebElement list
     */
    public List<WebElement> getLinesOfTable() {
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']/tbody"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));

        return rows;
    }
    
    /**
     * 获得列表中的一行
     * @param question - 问题
     * @param caseID - 研究对象编号
     * @param stage - 阶段
     * @param form - 表单
     * @param section - 分页
     * @return WebElement
     */
    public WebElement getLineOfAudit(String caseID, String stage, String form, String section, String question) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row : rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(1).getText().equals(question) && 
            		cols.get(3).getText().equals(caseID) && 
            		cols.get(6).getText().equals(stage) &&
            		cols.get(7).getText().equals(form) &&
            		cols.get(8).getText().equals(section)) {
                element = row;
                break;
            }
        }

        return element;
    }
    
    /**
     * 获得列表中的一行
     * @param auditInfo - AuditInfo Object
     * @return WebElement
     */
    public WebElement getLineOfAudit(AuditInfo auditInfo) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row : rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && 
            	cols.get(1).getText().equals(auditInfo.getQuestion()) && 
            	cols.get(3).getText().equals(auditInfo.getStudyNumber()) && 
            	cols.get(6).getText().equals(auditInfo.getStage()) &&
            	cols.get(7).getText().equals(auditInfo.getForm()) &&
            	cols.get(8).getText().equals(auditInfo.getSection())) {
                element = row;
                break;
            }
        }

        return element;
    }
    
    /**
     * 获得列表中的某个质疑出现的次数(for bug verify)
     * @param auditInfo - AuditInfo Object
     * @return int
     */
    public int getCountOfAudit(AuditInfo auditInfo) {
        int count = 0;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row : rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && 
            	cols.get(1).getText().equals(auditInfo.getQuestion()) && 
            	cols.get(3).getText().equals(auditInfo.getStudyNumber()) && 
            	cols.get(6).getText().equals(auditInfo.getStage()) &&
            	cols.get(7).getText().equals(auditInfo.getForm()) &&
            	cols.get(8).getText().equals(auditInfo.getSection())) {
                count = count + 1;
            }
        }

        return count;
    }

    /**
     * 获得质疑操作按钮
     * @return WebElement list
     */
    public List<WebElement> OperationBtn() {
    	List<WebElement> elements = driver.findElements(By.xpath(".//a[contains(@ng-click, 'vm.auditPopup')]"));
        return elements;

    }
    
    /**
     * 获得问题链接
     * 
     * @return WebElement list
     */
    public List<WebElement> QuestionBtn() {
    	List<WebElement> elements = driver.findElements(By.xpath(".//a[contains(@ui-sref, 'm.study.datasheet')]"));
        return elements;

    }
    
    /**
     * 获得某一行的质疑操作按钮
     * @param question - 问题
     * @param caseID - 研究对象编号
     * @param stage - 阶段
     * @param form - 表单
     * @param section - 分页
     * @return WebElement
     */
    public WebElement getOperationBtn(String caseID, String stage, String form, String section, String question) {
    	WebElement row = getLineOfAudit(caseID, stage, form, section, question);
    	WebElement element = row.findElement(By.xpath(".//a[contains(@ng-click, 'vm.auditPopup')]"));
        return element;
    }
    
    /**
     * 获得某一行的问题链接
     * @param question - 问题
     * @param caseID - 研究对象编号
     * @param stage - 阶段
     * @param form - 表单
     * @param section - 分页
     * @return WebElement list
     */
    public WebElement getQuestionLink(String caseID, String stage, String form, String section, String question) {
    	WebElement row = getLineOfAudit(caseID, stage, form, section, question);
    	WebElement element = row.findElement(By.xpath(".//a[contains(@ui-sref, 'm.study.datasheet')]"));
        return element;
    }
    
    /**
     * 获得某一行的质疑操作按钮
     * @param auditInfo - AuditInfo Object
     * @return WebElement
     */
    public WebElement getOperationBtn(AuditInfo auditInfo) {
    	WebElement row = getLineOfAudit(auditInfo);
    	WebElement element = row.findElement(By.xpath(".//a[contains(@ng-click, 'vm.auditPopup')]"));
        return element;
    }
    
    /**
     * 获得某一行的问题链接
     * @param auditInfo - AuditInfo Object
     * @return WebElement
     */
    public WebElement getQuestionLink(AuditInfo auditInfo) {
    	WebElement row = getLineOfAudit(auditInfo);
    	WebElement element = row.findElement(By.xpath(".//a[contains(@ui-sref, 'm.study.datasheet')]"));
        return element;
    }

    /**
     * 获得搜索对话框中的中心下拉列表
     * 
     * @return Select
     */
    public Select SearchCenterSelect() {
        Select element = new Select(driver.findElement(By.xpath(".//select[@ng-model='vm.searchAudit.site_id']")));
        return element;

    }

    /**
     * 获得搜索对话框中的分组下拉列表
     * 
     * @return Select
     */
    public Select SearchGroupSelect() {
        Select element = new Select(driver.findElement(By.xpath(".//select[@ng-model='vm.searchAudit.group_id']")));
        return element;

    }

    /**
     * 获得搜索对话框中的研究对象编号输入框
     * 
     * @return WebElement
     */
    public WebElement SearchStudyNumberInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.searchAudit.case_uid']"));
        return element;

    }

    /**
     * 获得搜索对话框中的搜索按钮
     * 
     * @return WebElement
     */
    public WebElement ConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-confirm-btn']"));
        return element;

    }

    /**
     * 获得搜索对话框中的取消按钮
     * 
     * @return WebElement
     */
    public WebElement CancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-cancel-btn']"));
        return element;

    }
    
    /**
     * 获得质疑记录对话框里的信息
     * @return String
     */
    public String getInfoInAuditDialog() {
    	WebElement form = driver.findElement(By.xpath(".//ng-form[@name='auditForm']"));
    	WebElement ul = form.findElement(By.xpath(".//ul[@class='list-unstyled box']"));
    	List<WebElement> lis = ul.findElements(By.tagName("li"));
    	String question = lis.get(0).findElement(By.xpath(".//strong[@class='ng-binding']")).getText();
    	String answer = lis.get(1).findElement(By.xpath(".//strong[@class='ng-binding']")).getText();
    	return question + " " + answer;
    }

    /**
     * 获得质疑记录对话框中的文本框
     * 
     * @return WebElement
     */
    public WebElement AuditDialogTextArea() {
    	WebElement element = driver.findElement(By.xpath(".//textarea[@ng-model='vm.message']"));
        return element;

    }

    /**
     * 获得质疑记录对话框中的添加质疑按钮
     * 
     * @return WebElement
     */
    public WebElement AuditDialogAddAuditBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[contains(@ng-click, 'vm.query')]"));
        return element;

    }

    /**
     * 获得质疑记录对话框中的关闭质疑按钮
     * 
     * @return WebElement
     */
    public WebElement AuditDialogCloseAuditBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[contains(@ng-click, 'vm.close')]"));
        return element;

    }
    
    /**
     * 获得质疑记录对话框中的回复按钮
     * 
     * @return WebElement
     */
    public WebElement AuditDialogReplyAuditBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[contains(@ng-click, 'vm.note')]"));
        return element;

    }

    /**
     * 获得质疑记录对话框中的关闭对话框按钮
     * 
     * @return WebElement
     */
    public WebElement AuditDialogCloseBtn() {
    	WebElement element = driver.findElement(By.xpath(".//span[contains(@ng-click, 'vm.confirm')]"));
        return element;

    }

    /**
     * 获得质疑记录对话框里的记录
     * @return WebElement list
     */
    public List<WebElement> getRecordsInAuditDialog() {
    	WebElement table = driver.findElement(By.xpath(".//table[@class='table audit']/tbody"));
    	List<WebElement> rows = table.findElements(By.tagName("tr"));
    	return rows;
    }
    
    /**
     * 获得我的质疑radio button
     * 
     * @return WebElement
     */
    public WebElement MyAuditRadioBtn() {
        WebElement div = driver.findElement(By.xpath(".//div[@class='radio-box pull-left ng-scope']"));
        WebElement element = div.findElements(By.xpath(".//span[@class='replace-radio replace']")).get(0);
        return element;
    }
    
    /**
     * 获得所有质疑radio button
     * 
     * @return WebElement
     */
    public WebElement AllAuditRadioBtn() {
        WebElement div = driver.findElement(By.xpath(".//div[@class='radio-box pull-left ng-scope']"));
        WebElement element = div.findElements(By.xpath(".//span[@class='replace-radio replace']")).get(1);
        return element;
    }
}
