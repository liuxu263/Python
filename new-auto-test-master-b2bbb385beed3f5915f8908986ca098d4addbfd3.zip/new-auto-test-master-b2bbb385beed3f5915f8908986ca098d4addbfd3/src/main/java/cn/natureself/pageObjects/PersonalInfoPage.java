package cn.natureself.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/**
 * 个人信息页面对象类
 * 
 * @author lx
 */
public class PersonalInfoPage {
    private WebDriver driver;

    public PersonalInfoPage(WebDriver driver) {
        this.driver = driver;

    }
    
    /**
     * 获得基本信息
     * @param driver--WebDriver
     * @return WebElement List
     * 
     */
    public List<WebElement> getBasicInfo(WebDriver driver) {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='profile box']"));
    	List<WebElement> elements = div.findElements(By.xpath(".//span[contains(@class, 'ng-binding')]"));
    	return elements;
    }

    /**
     * 获得修改密码按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement ChangePwdBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ng-click='vm.editPassword()']"));
        return element;
    }

    /**
     * 获得原密码输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement ChangePwdOldPwdInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='password']"));
        return element;
    }

    /**
     * 获得新密码输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement ChangePwdNewPwdInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='newPassword']"));
        return element;
    }

    /**
     * 获得再次输入新密码输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement ChangePwdNewPwdAgainInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='renewPassword']"));
        return element;
    }

    /**
     * 获得修改密码保存按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement ChangePwdConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@ng-click='vm.changePassword()']"));
        return element;
    }

    /**
     * 获得修改密码取消按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement ChangePwdCancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@ng-click='vm.cancel()']"));
        return element;
    }

    /**
     * 获得编辑个人信息按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalInfoBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ng-click='vm.editProfile()']"));
        return element;
    }

    /**
     * 获得编辑个人信息姓名输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalInfoNameInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.newUserProfileName']"));
        return element;
    }

    /**
     * 获得编辑个人信息科室输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalInfoDepartmentInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='department']"));
        return element;
    }

    /**
     * 获得编辑个人信息职称输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalInfoTitleInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='title']"));
        return element;
    }

    /**
     * 获得编辑个人信息工作单位输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalInfoCompanyInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='site']"));
        return element;
    }

    /**
     * 获得编辑个人信息地址输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalInfoCompanyLocationInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.userProfile.address']"));
        return element;
    }

    /**
     * 获得编辑个人信息手机输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalInfoPhoneInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.userProfile.phone']"));
        return element;
    }

    /**
     * 获得编辑个人信息保存按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalInfoConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='webapp-btn save']"));
        return element;
    }

    /**
     * 获得编辑个人信息取消按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalInfoCancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='webapp-btn cancel']"));
        return element;
    }

    /**
     * 获得编辑专注领域按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalFocusBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ng-click='vm.editTags()']"));
        return element;

    }

    /**
     * 获得已选择的专注领域的所有checkbox
     * 
     * @return WebElement list
     * 
     */
    public List<WebElement> SelectedPersonalFocusCheckbox() {
    	WebElement div = driver.findElement(By.xpath(".//div[@ng-show='!vm.isEditTags']"));
    	List<WebElement> elements = div.findElements(By.xpath(".//span[@class='tag ng-binding ng-scope']"));
        return elements;

    }
    
    /**
     * 获得专注领域的所有checkbox
     * 
     * @return WebElement list
     * 
     */
    public List<WebElement> EditPersonalFocusCheckbox() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='focus-field-box']"));
    	List<WebElement> elements = div.findElements(By.xpath(".//span[@ng-click='vm.clickTag(tag)']"));
        return elements;

    }

    /**
     * 获得专注领域保存按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalFocusSaveBtn() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='focus-field-box']"));
    	WebElement element = div.findElement(By.xpath(".//button[@ng-click='vm.saveTags()']"));
        return element;

    }

    /**
     * 获得专注领域取消按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalFocusCancelBtn() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='focus-field-box']"));
    	WebElement element = div.findElement(By.xpath(".//button[@ng-click='vm.cancel()']"));
        return element;

    }

    /**
     * 获得科研成果添加按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement AddPersonalWorkBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ng-click='vm.addWork()']"));
        return element;

    }

    /**
     * 获得科研成果类型下拉列表
     * 
     * @return Select
     * 
     */
    public Select PersonalWorkTypeSelect() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='edit-box']"));
        Select element = new Select(div.findElement(By.xpath(".//select[@ng-model='vm.newWork.type' or @ng-model='work.type']")));
        return element;

    }

    /**
     * 获得科研成果标题输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement PersonalWorkTitleInput() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='edit-box']"));
    	WebElement element = div.findElement(By.xpath(".//input[@ng-model='vm.newWork.title' or @ng-model='work.title']"));
        return element;

    }

    /**
     * 获得科研成果简介输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement PersonalWorkDetailsInput() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='edit-box']"));
    	WebElement element = div.findElement(By.xpath(".//textarea[@ng-model='vm.newWork.summary' or @ng-model='work.summary']"));
        return element;

    }

    /**
     * 获得科研成果链接输入框
     * 
     * @return WebElement
     * 
     */
    public WebElement PersonalWorkLinkInput() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='edit-box']"));
    	WebElement element = div.findElement(By.xpath(".//input[@ng-model='vm.newWork.link' or @ng-model='work.link']"));
        return element;

    }

    /**
     * 获得科研成果保存按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement PersonalWorkSaveBtn() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='edit-box']"));
    	WebElement element = div.findElement(By.xpath(".//button[@ng-click='vm.saveNewWork()']"));
        return element;

    }
    
    /**
     * 获得编辑科研成果保存按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement EditPersonalWorkSaveBtn() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='edit-box']"));
    	WebElement element = div.findElement(By.xpath(".//button[@ng-click='vm.saveEditWork()']"));
        return element;

    }

    /**
     *  获得科研成果取消按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement PersonalWorkCancelBtn() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='edit-box']"));
    	WebElement element = div.findElement(By.xpath(".//button[@ng-click='vm.cancel()']"));
        return element;

    }
    
    /**
     *  获得科研成果删除按钮
     * 
     * @return WebElement
     * 
     */
    public WebElement PersonalWorkDeleteBtn() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='edit-box']"));
    	WebElement element = div.findElement(By.xpath(".//button[contains(@ng-click, 'vm.deleteWork')]"));
        return element;

    }
    
    /**
     *  获得科研成果数
     * @return int
     * 
     */
    public int getPersonalWorkCount() {
        List<WebElement> list = driver.findElements(By.xpath(".//div[@class='show-box']"));
        return list.size();

    }
    
    /**
     *  获得科研成果的信息
     * @param name - 标题
     * @param type - 获得信息类型
     * @return String
     * 
     */
    public String getPersonalWorkInfo(String name, String type) {
    	String title = "";
    	String info = "";
        List<WebElement> list = driver.findElements(By.xpath(".//div[@class='show-box']"));
        for (WebElement item:list) {
        	title = item.findElement(By.xpath(".//div[@class='title']/h4")).getText();
        	if (title.equals(name)) {
        		if (type.equals("title")) {
        			info = item.findElement(By.xpath(".//div[@class='title']/h4")).getText();
        		} else if (type.equals("type")) {
        			info = item.findElement(By.xpath(".//div[@class='type ng-binding']")).getText();
        		} else if (type.equals("desc")) {
        			info = item.findElement(By.xpath(".//div[@class='work'][1]/div")).getText();
        		} else {
        			info = item.findElement(By.xpath(".//div[@class='work'][2]/a")).getText();
        		}
        		break;
        	}
        }
        return info;

    }
    
    /**
     *  获得科研成果的编辑按钮
     * @param name - 标题
     * @return WebElement
     * 
     */
    public WebElement getPersonalWorkEditBtn(String name) {
    	String title = "";
    	WebElement element = null;
        List<WebElement> list = driver.findElements(By.xpath(".//div[@class='show-box']"));
        for (WebElement item:list) {
        	title = item.findElement(By.xpath(".//div[@class='title']/h4")).getText();
        	if (title.equals(name)) {
        		element = item.findElement(By.xpath(".//a[contains(@ng-click, 'vm.editWork')]"));
        	    break;
        	}
        }
        return element;

    }
    
    /**
     * 获得确定按钮
     * 
     * @return WebElement
     */
    public WebElement ConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-confirm-btn']"));
        return element;

    }

    /**
     * 获得取消按钮
     * 
     * @return WebElement
     */
    public WebElement CancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-cancel-btn']"));
        return element;

    }
    
}
