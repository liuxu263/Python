package cn.natureself.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * 项目列表页面对象类
 * 
 * @author Andy
 */
public class ProjectListPage {

    private WebDriver driver;

    public ProjectListPage(WebDriver driver) {
        this.driver = driver;
    }
    
    /**
     * 获得一个项目按钮
     * @param name - 项目名称
     * @return WebElement
     */
    public WebElement getProjectBtn(String name) {
        String xpathString = ".//span[contains(text()," + "'" + name + "'" + ")]";
        WebElement element = driver.findElement(By.xpath(xpathString));
        
        return element;
    }
    
    /**
     * 获得一个项目在列表中出现的次数
     * @param name - 项目名称
     * @return count
     */
    public int getProjectCount(String name) {
        String xpathString = ".//span[contains(text()," + "'" + name + "'" + ")]";
        List<WebElement> elements = driver.findElements(By.xpath(xpathString));
        int count = elements.size();
        
        return count;
    }
}