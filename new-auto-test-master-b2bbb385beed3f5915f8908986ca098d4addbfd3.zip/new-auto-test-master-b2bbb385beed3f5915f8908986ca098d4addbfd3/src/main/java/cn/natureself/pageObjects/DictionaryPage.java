package cn.natureself.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;

/**
 * 术语字典页面对象类
 * 
 * @author Andy
 */
public class DictionaryPage {
    
}
