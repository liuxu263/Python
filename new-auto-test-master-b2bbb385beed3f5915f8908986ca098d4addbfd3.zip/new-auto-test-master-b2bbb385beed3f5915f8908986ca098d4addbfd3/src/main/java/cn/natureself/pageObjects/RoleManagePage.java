package cn.natureself.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/**
 * 人员设置页面对象类
 * 
 * @author Andy
 */
public class RoleManagePage {
    private WebDriver driver;

    public RoleManagePage(WebDriver driver) {
        this.driver = driver;
    }
   
    /**
     * 获得添加人员按钮
     * @return WebElement
     */
    public WebElement addRoleBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ng-click='vm.addRolePopup()']"));
        return element;
    }
    
    /**
     * 获得删除人员按钮
     * @param email - 列表里的人员的email
     * @return WebElement
     */
    public WebElement deleteRoleBtn(String email) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(3).getText().equals(email)) {
            	try {
                    element = cols.get(6).findElement(By.xpath(".//a[@ng-click='vm.deleteRolePopup(role)']"));
            	} catch (NoSuchElementException e) {
            		element = null;
            	}
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得人员列表中的一行
     * @param email - 人员列表里的邮箱
     * @return WebElement
     */
    public WebElement getLineOfRole(String email) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(3).getText().equals(email)) {
                element = row;
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得人员列表中的所有行
     * @return WebElement list
     */
    public List<WebElement> getLinesOfRoleTable() {
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']/tbody"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        
        return rows;
    }
    
    /**
     * 获得添加人员对话框里的邮箱输入框
     * @return WebElement
     */
    public WebElement roleEmailInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[contains(@class, 'add-role-email-input')]"));
        return element;
    }
    
    /**
     * 获得添加人员对话框里的权限下拉列表
     * @return Select
     */
    public Select selectRoleCtrl() {
        Select selectList = new Select(driver.findElement(By.xpath(".//select[@name='rights']")));
        return selectList;
    }
    
    /**
     * 获得添加人员对话框里的取消按钮
     * @return WebElement
     */
    public WebElement AddRoleCancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-cancel-btn']"));
        return element;
    }
    
    /**
     * 获得添加人员对话框里的添加按钮
     * @return WebElement
     */
    public WebElement AddRoleConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-confirm-btn']"));
        return element;
    }
    
    /**
     * 获得删除人员对话框里的取消按钮
     * @return WebElement
     */
    public WebElement DeleteRoleCancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-cancel-btn']"));
        return element;
    }
    
    /**
     * 获得删除人员对话框里的确定按钮
     * @return WebElement
     */
    public WebElement DeleteRoleConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-confirm-btn']"));
        return element;
    }
    
    /**
     * 获得添加人员对话框里的选择中心checkbox
     * @return WebElement list
     */
    public List<WebElement> checkboxForAuditor() {
        List<WebElement> checkboxes = driver.findElements(By.xpath(".//li[@ng-repeat='site in vm.sites']"));
        return checkboxes;
    }
    
    /**
     * 获得添加人员对话框里的选择中心下拉列表
     * @return WebElement list
     */
    public Select selectSiteCtrl() {
        Select selectList = new Select(driver.findElement(By.xpath(".//select[@name='site']")));
        return selectList;
    }
    
    /**
     * 获得添加人员对话框里的自动获取的信息
     * @return WebElement list
     */
    public List<WebElement> getInfoInAddRoleDialog() {
        WebElement form = driver.findElement(By.xpath(".//ng-form[@name='addRoleForm']"));
        List<WebElement> list = form.findElements(By.tagName("input"));
        return list;
    }
    
}