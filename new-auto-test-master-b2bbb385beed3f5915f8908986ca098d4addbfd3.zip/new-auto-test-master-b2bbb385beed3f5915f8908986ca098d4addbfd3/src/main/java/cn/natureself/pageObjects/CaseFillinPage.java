package cn.natureself.pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/**
 * 填写病例表单页面对象类
 * 
 * @author Andy
 */
public class CaseFillinPage {
	
    private WebDriver driver;

    public CaseFillinPage(WebDriver driver) {
        this.driver = driver;

    }
    
    /**
     * 获得病例表单填写页面的病例信息
     * @return WebElement List
     */
    public List<WebElement> getCaseInfo() {
        WebElement div = driver.findElement(By.xpath(".//div[@class='general-info-box']"));
        List<WebElement> elements = div.findElements(By.xpath(".//span[contains(@class, 'data-detail-item')]"));
        elements.add(div.findElement(By.xpath(".//h4[contains(@class, 'case-subject-name')]")));
        
        return elements;
    }
    
    /**
     * 获得病例表单填写页面的阶段的状态
     * @param stageName - stage name
     * @return String
     */
    public String getStageStatus(String stageName) {
    	String status = "";
    	String path = "";
        List<WebElement> divs = driver.findElements(By.xpath(".//div[contains(@class, 'event-detail-box')]"));
        for (WebElement div:divs) {
        	path = ".//a[contains(@ui-sref, 'm.study.datasheet')]";
        	WebElement a = div.findElement(By.xpath(path));
        	if (a.getText().contains(stageName)) {
        		status = a.findElement(By.xpath(".//span[@class='event-state ng-binding']")).getText();
        		break;
        	}
        }
        
        return status;
    }
    
    /**
     * 获得病例表单填写页面的section的链接
     * @param name - section名
     * @return WebElement
     */
    public WebElement getSectionLink(String name) {
        WebElement li = driver.findElement(By.xpath(".//li[@class='crf-container ng-scope']"));
        String path = ".//a[contains(@ui-sref, 'm.study.datasheet.section') and contains(text(), '" + name + "')]";
        WebElement element = li.findElement(By.xpath(path));
        return element;
    }
    
    /**
     * 获得病例表单填写页面的阶段的链接
     * @param name - 阶段名
     * @return WebElement
     */
    public WebElement getStageLink(String name) {
    	WebElement element = null;
        WebElement div = driver.findElement(By.xpath(".//div[@class='data-nav-container ng-scope']"));
        List<WebElement> elements = div.findElements(By.xpath(".//a[contains(@ui-sref, 'm.study.datasheet(')]"));
        for (WebElement a:elements) {
        	if (a.getText().contains(name)) {
        		element = a;
        		break;
        	}
        }
        return element;
    }
    
    /**
     * 获得病例表单填写页面的表单名
     * @return String
     */
    public String getActiveFormName() {
    	String name = "";
        WebElement div = driver.findElement(By.xpath(".//div[@class='crf-title']"));
        WebElement a = div.findElement(By.xpath(".//a[contains(@ng-click, 'vm.toggleCrf')]"));
        name = a.getText();
        return name;
    }
    
    /**
     * 获得病例表单填写页面的section名
     * @return String
     */
    public String getActiveSectionName() {
    	String name = "";
        WebElement div = driver.findElement(By.xpath(".//div[@class='crf-inner-container']"));
        WebElement h5 = div.findElement(By.xpath(".//h5[contains(@class, 'crf-section-title')]"));
        name = h5.getText();
        return name;
    }
    
    /**
     * 获得表单的input控件
     * @return WebElement List
     */
    public List<WebElement> getTextInputCtrlInForm() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='crf-main-container ng-scope']"));
    	List<WebElement> inputs = div.findElements(By.xpath(".//input[@type='text']"));
    	return inputs;
    }
    
    /**
     * 获得表单的number控件
     * @return WebElement List
     */
    public List<WebElement> getNumberCtrlInForm() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='crf-main-container ng-scope']"));
    	List<WebElement> inputs = div.findElements(By.xpath(".//input[@type='number']"));
    	return inputs;
    }
    
    /**
     * 获得表单的质疑按钮
     * @param status - 质疑状态
     * @return WebElement List
     */
    public List<WebElement> getAuditBtnInForm(String status) {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='crf-main-container ng-scope']"));
    	String path = ".//a[contains(@ng-click, 'vm.auditPopup') " + "and contains(text(), '" + status + "')]";
    	List<WebElement> buttons = div.findElements(By.xpath(path));
    	return buttons;
    }
    
    /**
     * 获得表单的质疑按钮的状态
     * @param index - 质疑按钮的index
     * @return WebElement List
     */
    public String getAuditBtnStatusInForm(int index) {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='crf-main-container ng-scope']"));
    	List<WebElement> buttons = div.findElements(By.xpath(".//a[contains(@ng-click, 'vm.auditPopup')]"));
    	String status = buttons.get(index).getText();
    	return status;
    }
    
    /**
     * 获得表单的保存按钮
     * @return WebElement
     */
    public WebElement getSaveBtn() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='save-box ng-scope']"));
    	WebElement element = div.findElement(By.xpath(".//button[contains(@class, 'webapp-btn save')]"));
    	return element;
    }
    
    /**
     * 获得表单的保存并到下一个表单按钮
     * @return WebElement
     */
    public WebElement getSaveToNextBtn() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='save-box ng-scope']"));
    	WebElement element = div.findElement(By.xpath(".//button[contains(@class, 'webapp-btn next')]"));
    	return element;
    }
    
    /**
     * 获得继续保存按钮
     * @return WebElement
     */
    public WebElement getForceSaveBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-confirm-btn ng-scope' and contains(text(), '继续保存')]"));
    	return element;
    }
    
    /**
     * 获得取消保存按钮
     * @return WebElement
     */
    public WebElement getCancelSaveBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-cancel-btn' and contains(text(), '取消保存')]"));
    	return element;
    }
    
    /**
     * 获得阶段的提交按钮
     * @return WebElement
     */
    public WebElement getSubmitBtn() {
    	WebElement element;
    	try {
    		element = driver.findElement(By.xpath(".//a[@class='submit webapp-btn ng-scope']"));
    	} catch (NoSuchElementException e) {
    		element = null;
    	}
    	return element;
    }
    
    /**
     * 获得阶段的撤回按钮
     * @return WebElement
     */
    public WebElement getWithdrawBtn() {
    	WebElement element;
    	try {
    		element = driver.findElement(By.xpath(".//a[@class='withdraw webapp-btn ng-scope']"));
    	} catch (NoSuchElementException e) {
    		element = null;
    	}
    	return element;
    }
    
    /**
     * 获得阶段的通过按钮
     * @return WebElement
     */
    public WebElement getPassBtn() {
    	WebElement element;
    	try {
    		element = driver.findElement(By.xpath(".//a[@class='signoff webapp-btn ng-scope']"));
    	} catch (NoSuchElementException e) {
    		element = null;
    	}
    	return element;
    }
    
    /**
     * 获得确定按钮
     * @return WebElement
     */
    public WebElement getConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-confirm-btn']"));
    	return element;
    }
    
    /**
     * 获得取消按钮
     * @return WebElement
     */
    public WebElement getCancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-cancel-btn']"));
    	return element;
    }
    
    /**
     * 获得撤回对话框里的信息
     * @return String
     */
    public String getInfoInWithdrawDialog() {
    	WebElement form = driver.findElement(By.xpath(".//ng-form[@name='withdrawForm']"));
    	WebElement div = form.findElement(By.xpath(".//div[@class='modal-body']/div[1]"));
    	String info = div.findElement(By.xpath(".//span[@class='ng-binding']")).getText();
    	return info;
    }
    
    /**
     * 获得撤回对话框里的radio button
     * @param type - 选择的按钮类型
     * @return WebElement
     */
    public WebElement getRadioInWithdrawDialog(String type) {
    	WebElement element;
    	WebElement form = driver.findElement(By.xpath(".//ng-form[@name='withdrawForm']"));
    	if (type.equals("error")) {
    	    element = form.findElement(By.xpath(".//input[@type='radio' and @value='1']"));
    	} else {
    		element = form.findElement(By.xpath(".//input[@type='radio' and @value='2']"));
    	}
    	return element;
    }
    
    /**
     * 获得修改原因对话框里的所有行
     * @return WebElement list
     */
    public List<WebElement> getLinesInModifyReasonDialog() {
    	WebElement table = driver.findElement(By.xpath(".//table[@class='table change']/tbody"));
    	List<WebElement> list = table.findElements(By.tagName("tr"));
    	return list;
    }
    
    /**
     * 获得修改原因对话框里的某一行的信息
     * @param question - 问题
     * @return String
     */
    public String getInfoFromLineOfModify(String question) {
    	String ques = "";
    	String mod = "";
    	List<WebElement> rows = getLinesInModifyReasonDialog();
    	for (WebElement row:rows) {
    		List<WebElement> cols = row.findElements(By.tagName("td"));
    		if(cols.get(0).findElement(By.tagName("span")).getText().equals(question)) {
    			ques = cols.get(0).findElement(By.tagName("span")).getText();
    			mod = cols.get(1).findElement(By.tagName("span")).getText();
    		}
    	}
    	return ques + "#" + mod;
    }
    
    /**
     * 获得修改原因对话框里的某一行的原因输入框
     * @param question - 问题
     * @return WebElement
     */
    public WebElement getInputFromLineOfModify(String question) {
    	WebElement element = null;
    	List<WebElement> rows = getLinesInModifyReasonDialog();
    	for (WebElement row:rows) {
    		List<WebElement> cols = row.findElements(By.tagName("td"));
    		if(cols.get(0).findElement(By.tagName("span")).getText().equals(question)) {
    			element = cols.get(2).findElement(By.tagName("input"));
    		}
    	}
    	return element;
    }
    
    /**
     * 获得终止病例填写按钮
     * @return WebElement
     */
    public WebElement getAbortCaseBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ng-click='vm.endCasePopup()']"));
    	return element;
    }
    
    /**
     * 获得终止病例填写对话框的日期选择框
     * @return WebElement
     */
    public WebElement getDatePickerInAbortCaseDialog() {
    	WebElement element = driver.findElement(By.xpath(".//input[@id='end-case-datepicker']"));
    	return element;
    }
    
    /**
     * 获得终止病例填写对话框的日期选择框的今天按钮
     * @return WebElement
     */
    public WebElement getTodayBtnInDatePicker() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='picker__button--today']"));
    	return element;
    }
    
    /**
     * 获得终止病例填写对话框的阶段选择select
     * @return Select
     */
    public Select getSelectInAbortCaseDialog() {
    	WebElement form = driver.findElement(By.xpath(".//ng-form[@name='endCaseForm']"));
    	Select select = new Select(form.findElement(By.xpath(".//select[@ng-change='changeSelect()']")));
    	return select;
    }
    
    /**
     * 获得终止病例填写对话框的推出原因checkbox
     * @return WebElement list
     */
    public List<WebElement> getCheckboxInAbortCaseDialog() {
    	WebElement form = driver.findElement(By.xpath(".//ng-form[@name='endCaseForm']"));
    	List<WebElement> elements = form.findElements(By.xpath(".//input[@type='checkbox']"));
    	return elements;
    }
    
    /**
     * 获得保存表单校验对话框里的所有行
     * @return WebElement list
     */
    public List<WebElement> getLinesInCheckFormDialog() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='error-container']"));
    	WebElement table = div.findElement(By.xpath(".//table[@class='table']/tbody"));
    	List<WebElement> list = table.findElements(By.tagName("tr"));
    	return list;
    }
    
    /**
     * 获得保存表单校验对话框里的某一问题的提示信息
     * @param question - 问题
     * @return String
     */
    public String getHintInLineOfCheckFormDialog(String question) {
    	String hint = "";
    	List<WebElement> rows = getLinesInCheckFormDialog();
    	for (WebElement row:rows) {
    		List<WebElement> cols = row.findElements(By.tagName("td"));
    		if(cols.get(0).findElement(By.tagName("span")).getText().equals(question)) {
    			hint = cols.get(2).findElement(By.tagName("span")).getText();
    			break;
    		}
    	}
    	return hint;
    }
    
    /**
     * 获得保存表单校验对话框里的所有提示信息
     * @return String list
     */
    public List<String> getHintsInCheckFormDialog() {
    	List<String> hints = new ArrayList<String>();
    	String hint = "";
    	WebElement div = driver.findElement(By.xpath(".//div[@class='error-container']"));
    	WebElement table = div.findElement(By.xpath(".//table[@class='table']/tbody"));
    	List<WebElement> list = table.findElements(By.xpath(".//td[@class='error-message']"));
    	for (WebElement item:list) {
    		hint = item.findElement(By.tagName("span")).getText();
    		hints.add(hint);
    	}
    	return hints;
    }
    
    /**
     * 获得保存表单校验对话框里的某一问题的修改链接
     * @param question - 问题
     * @return WebElement
     */
    public WebElement getLinkInLineOfCheckFormDialog(String question) {
    	WebElement element = null;
    	List<WebElement> rows = getLinesInCheckFormDialog();
    	for (WebElement row:rows) {
    		List<WebElement> cols = row.findElements(By.tagName("td"));
    		if(cols.get(0).findElement(By.tagName("span")).getText().equals(question)) {
    			element = cols.get(3).findElement(By.tagName("a"));
    			break;
    		}
    	}
    	return element;
    }
    
    /**
     * 获得提交表单校验对话框里的所有行
     * @return WebElement list
     */
    public List<WebElement> getLinesInSubmitCheckDialog() {
    	WebElement div = driver.findElement(By.xpath(".//div[@class='error-list-container ng-scope']"));
    	WebElement table = div.findElement(By.xpath(".//table[@class='table']/tbody"));
    	List<WebElement> list = table.findElements(By.tagName("tr"));
    	return list;
    }
    
    /**
     * 获得提交表单校验对话框里的某一问题的提示信息
     * @param section - 分页
     * @param question - 问题
     * @return String
     */
    public String getHintInLineOfSubmitCheckDialog(String section, String question) {
    	String hint = "";
    	List<WebElement> rows = getLinesInSubmitCheckDialog();
    	for (WebElement row:rows) {
    		List<WebElement> cols = row.findElements(By.tagName("td"));
    		if(cols.get(1).findElement(By.tagName("span")).getText().equals(section) && 
    				cols.get(2).findElement(By.tagName("span")).getText().equals(question)) {
    			hint = cols.get(4).findElement(By.tagName("span")).getText();
    			break;
    		}
    	}
    	return hint;
    }
    
    /**
     * 获得提交表单校验对话框里的所有提示信息
     * @return String list
     */
    public List<String> getHintsInSubmitCheckDialog() {
    	List<String> hints = new ArrayList<String>();
    	String hint = "";
    	WebElement div = driver.findElement(By.xpath(".//div[@class='error-list-container ng-scope']"));
    	WebElement table = div.findElement(By.xpath(".//table[@class='table']/tbody"));
    	List<WebElement> list = table.findElements(By.xpath(".//td[@class='error-message']"));
    	for (WebElement item:list) {
    		hint = item.findElement(By.tagName("span")).getText();
    		hints.add(hint);
    	}
    	return hints;
    }
    
    /**
     * 获得提交表单校验对话框里的某一问题的修改链接
     * @param section - 分页
     * @param question - 问题
     * @return WebElement
     */
    public WebElement getLinkInLineOfSubmitCheckDialog(String section, String question) {
    	WebElement element = null;
    	List<WebElement> rows = getLinesInSubmitCheckDialog();
    	for (WebElement row:rows) {
    		List<WebElement> cols = row.findElements(By.tagName("td"));
    		if(cols.get(1).findElement(By.tagName("span")).getText().equals(section) && 
    				cols.get(2).findElement(By.tagName("span")).getText().equals(question)) {
    			element = cols.get(5).findElement(By.tagName("a"));
    			break;
    		}
    	}
    	return element;
    }
    
}
