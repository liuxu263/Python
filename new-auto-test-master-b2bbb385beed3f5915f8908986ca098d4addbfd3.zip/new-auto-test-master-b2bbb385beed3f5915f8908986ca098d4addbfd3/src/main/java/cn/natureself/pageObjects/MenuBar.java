package cn.natureself.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import cn.natureself.utils.UIStrings;

import org.openqa.selenium.NoSuchElementException;

/**
 * 导航菜单对象类
 * 
 * @author Andy
 */
public class MenuBar {
    private WebDriver driver;

    public MenuBar(WebDriver driver) {
        this.driver = driver;
    }
   
    /**
     * 获得菜单项
     * @param name - 菜单项名字
     * @return WebElement
     */
    public WebElement getMenuItem(String name) {
    	WebElement element = null;
    	String path = "";
        // Get dropdown items first
        // List<WebElement> dropdown = driver.findElements(By.xpath(".//ul[@class='nav navbar-nav ng-scope']"));
        // Actions builder = new Actions(driver); 
        
        if (name.equals(UIStrings.MENU_FRONTPAGE)) {
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.detail']"));
        } else if (name.equals(UIStrings.MENU_SITE_MANAGE)) {
            // builder.moveToElement(dropdown.get(1)).perform();
        	path = ".//a[@class='dropdown-toggle ng-binding' and contains(text(), '" + UIStrings.MENU_PROJECT_MANAGE + "')]";
        	driver.findElement(By.xpath(path)).click();
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.sites']"));
        } else if (name.equals(UIStrings.MENU_ROLE_MANAGE)) {
            //builder.moveToElement(dropdown.get(1)).perform();
        	path = ".//a[@class='dropdown-toggle ng-binding' and contains(text(), '" + UIStrings.MENU_PROJECT_MANAGE + "')]";
        	driver.findElement(By.xpath(path)).click();
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.roles']"));
        } else if (name.equals(UIStrings.MENU_FORM_MANAGE)) {
            //builder.moveToElement(dropdown.get(1)).perform();
        	path = ".//a[@class='dropdown-toggle ng-binding' and contains(text(), '" + UIStrings.MENU_PROJECT_MANAGE + "')]";
        	driver.findElement(By.xpath(path)).click();
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.crfs']"));
        } else if (name.equals(UIStrings.MENU_GROUP_MANAGE)) {
            //builder.moveToElement(dropdown.get(1)).perform();
        	path = ".//a[@class='dropdown-toggle ng-binding' and contains(text(), '" + UIStrings.MENU_PROJECT_MANAGE + "')]";
        	driver.findElement(By.xpath(path)).click();
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.groupevents']"));
        } else if (name.equals(UIStrings.MENU_CASE_MANAGE)) {
            //builder.moveToElement(dropdown.get(1)).perform();
        	path = ".//a[@class='dropdown-toggle ng-binding' and contains(text(), '" + UIStrings.MENU_CASE_MANAGE + "')]";
        	driver.findElement(By.xpath(path)).click();
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.cases']"));
        } else if (name.equals(UIStrings.MENU_FORM_TASK)) {
            //builder.moveToElement(dropdown.get(2)).perform();
        	path = ".//a[@class='dropdown-toggle ng-binding' and contains(text(), '" + UIStrings.MENU_TASK_MANAGE + "')]";
        	driver.findElement(By.xpath(path)).click();
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.caseEvents']"));
        } else if (name.equals(UIStrings.MENU_AUDIT_MANAGE)) {
            //builder.moveToElement(dropdown.get(2)).perform();
        	path = ".//a[@class='dropdown-toggle ng-binding' and contains(text(), '" + UIStrings.MENU_TASK_MANAGE + "')]";
        	driver.findElement(By.xpath(path)).click();
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.audits']"));
        } else if (name.equals(UIStrings.MENU_DICTIONARY)) {
            //builder.moveToElement(dropdown.get(3)).perform();
        	path = ".//a[@class='dropdown-toggle ng-binding' and contains(text(), '" + UIStrings.MENU_DICTIONARY + "')]";
        	driver.findElement(By.xpath(path)).click();
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.dictionaries']"));
        } else if (name.equals(UIStrings.MENU_IMPORT_DATA)) {
            //builder.moveToElement(dropdown.get(3)).perform();
        	path = ".//a[@class='dropdown-toggle ng-binding' and contains(text(), '" + UIStrings.MENU_DATA_MANAGE + "')]";
        	driver.findElement(By.xpath(path)).click();
            element = driver.findElement(By.xpath(".//a[@ui-sref='m.study.dictionaries']"));
        } else {
            throw new NoSuchElementException("Cannot find menu item element: " + name);
        }
        
        return element;
    }
    
    /**
     * 获得用户名字
     * @return WebElement
     */
    public String getUserName() {
        WebElement user = driver.findElement(By.xpath(".//div[@class='navbar-right dropdown']"));
        String userName = user.findElement(By.xpath(".//a[@class='dropdown-toggle ng-binding']")).getText();
        
        return userName;
    }
    
    /**
     * 获得个人信息link
     * @return WebElement
     */
    public WebElement personalInfoLink() {
        WebElement user = driver.findElement(By.xpath(".//div[@class='navbar-right dropdown']"));
        Actions builder = new Actions(driver); 
        builder.moveToElement(user).perform();
        WebElement element = user.findElement(By.xpath(".//a[@ui-sref='m.profile']"));
        
        return element;
    }
    
    /**
     * 获得登出link
     * @return WebElement
     */
    public WebElement logoutLink() {
        WebElement user = driver.findElement(By.xpath(".//div[@class='navbar-right dropdown']"));
        Actions builder = new Actions(driver); 
        builder.moveToElement(user).perform();
        WebElement element = user.findElement(By.partialLinkText("登出"));
        
        return element;
    }

}