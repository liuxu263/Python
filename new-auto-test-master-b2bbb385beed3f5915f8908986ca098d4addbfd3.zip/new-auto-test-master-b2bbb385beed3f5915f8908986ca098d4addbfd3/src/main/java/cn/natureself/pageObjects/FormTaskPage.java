package cn.natureself.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * 表单任务页面对象类
 * 
 * @author lx
 */

public class FormTaskPage {
    private WebDriver driver;

    /**
     * 传递dirver
     * 
     * @param driver--WebDriver
     */
    public FormTaskPage(WebDriver driver) {
        this.driver = driver;
    }

    /**
     * 获得我的表单radio button
     * @return WebElement
     * @author lx 
     */
    public WebElement MyFormRadio() {
        WebElement div = driver.findElement(By.xpath(".//div[@class='radio-box pull-left ng-scope']"));
        WebElement element = div.findElements(By.xpath(".//span[@class='replace-radio replace']")).get(0);
        return element;
    }

    /**
     * 获得所有表单radio button
     * @return WebElement
     * @author lx
     */
    public WebElement AllFormRadio() {
        WebElement div = driver.findElement(By.xpath(".//div[@class='radio-box pull-left ng-scope']"));
        WebElement element = div.findElements(By.xpath(".//span[@class='replace-radio replace']")).get(1);
        return element;
    }

    /**
     * 获得搜索按钮
     * @return WebElement
     * @author lx 
     */
    public WebElement SearchBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[contains(@ng-click, 'searchCaseEventPopup')]"));
        return element;
    }

    /**
     * @author lx 
     * 获得所有表单分组按钮
     * @return WebElement list
     */
    public List<WebElement> getStatusGroups() {
        WebElement ul = driver.findElement(By.xpath(".//ul[@class='list-unstyled tab-btns']"));
        List<WebElement> groups = ul.findElements(By.xpath(".//a[contains(@ui-sref, 'm.study.caseEvents')]"));

        return groups;
    }
    
    /**
     * @author lx 
     * 获得表单分组按钮
     * @param name - group name
     * @return WebElement 
     */
    public WebElement getStatusGroupBtn(String name) {
    	WebElement element = null;
        List<WebElement> groups = getStatusGroups();

        for (WebElement group:groups) {
        	if (group.getText().equals(name)) {
        		element = group;
        	}
        }
        
        return element;
    }

    /**
     * 获得列表表头
     * @return WebElement list
     */
    public List<WebElement> getHeadsFromTable() {
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> elements = table.findElements(By.tagName("th"));
        return elements;
    }

    /**
     * 获得列表中的所有行
     * 
     * @return WebElement list
     */
    public List<WebElement> getLinesOfTable() {
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']/tbody"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));

        return rows;
    }

    /**
     * 获得列表中的一行
     * 
     * @param caseID - 研究对象编号
     * @param stageName - 阶段名
     * @return WebElement
     */
    public WebElement getLineOfTask(String caseID, String stageName) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row : rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(0).getText().equals(stageName) && cols.get(3).getText().equals(caseID)) {
                element = row;
                break;
            }
        }

        return element;
    }

    /**
     * 获得列表中某一行的接管表单任务按钮
     * @author lx
     * @param caseID - 研究对象编号
     * @param stageName - 阶段名
     * @return WebElement
     */
    public WebElement getUndertakeBtn(String caseID, String stageName) {
    	WebElement element = null;
        WebElement row = getLineOfTask(caseID, stageName);
        List<WebElement> cols = row.findElements(By.tagName("td"));
        if (cols.size() > 0) {
            element = cols.get(8).findElement(By.xpath(".//a[contains(@ng-click, 'takeoverCaseEvent')]"));
        }
        return element;
    }
    
    /**
     * 获得列表中某一行的阶段链接
     * @author lx
     * @param caseID - 研究对象编号
     * @param stageName - 阶段名
     * @return WebElement
     */
    public WebElement getStageLink(String caseID, String stageName) {
    	WebElement element = null;
        WebElement row = getLineOfTask(caseID, stageName);
        List<WebElement> cols = row.findElements(By.tagName("td"));
        if (cols.size() > 0) {
            element = cols.get(0).findElement(By.tagName("a"));
        }
        return element;
    }

    /**
     * 获得接管表单任务确认按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement ConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-confirm-btn']"));
        return element;
    }

    /**
     * 获得接管表单任务取消按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement CancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-cancel-btn']"));
        return element;
    }

    /**
     * 获得搜索对话框中的姓名输入框
     * @author lx 
     * @return WebElement
     */
    public WebElement SearchNameInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.searchCaseEvent.subject_name']"));
        return element;
    }

    /**
     * 获得搜索对话框中的研究编号输入框
     * @author lx 
     * @return WebElement
     */
    public WebElement SearchNumberInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.searchCaseEvent.uid']"));
        return element;
    }
    
    /**
     * 获得搜索对话框中的搜索按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement SearchConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-confirm-btn']"));
        return element;
    }

    /**
     * 获得搜索对话框中的取消按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement SearchCancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-cancel-btn']"));
        return element;
    }
    
    /**
     * 获得接管任务对话框中的信息
     * @author lx 
     * @return String
     */
    public String getInfoFromTakeTaskDialog() {
        WebElement div = driver.findElement(By.xpath(".//div[@class='modal-container ng-scope']"));
        WebElement p = div.findElement(By.xpath(".//p[@ng-bind-html='vm.message']"));
        String auditor = p.findElement(By.tagName("h5")).getText();
        return auditor;
    }

}
