package cn.natureself.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;

/**
 * 表单管理页面对象类
 * 
 * @author Andy
 */
public class FormManagePage {
    private WebDriver driver;

    public FormManagePage(WebDriver driver) {
        this.driver = driver;
    }
   
    /**
     * 获得上传表单按钮
     * @return WebElement
     */
    public WebElement uploadFormBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[contains(text(), '上传新表单')]"));
        return element;
    }
    
    /**
     * 获得表单列表中的所有行
     * @return - WebElement list
     */
    public List<WebElement> getLinesOfFormTable() {
        
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']/tbody"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        
        return rows;
    }
    
    /**
     * 获得表单列表中的一行
     * @param name - form name
     * @return - WebElement list
     */
    public WebElement getLineOfForm(String name) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']/tbody"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(0).getText().equals(name)) {
                element = row;
                break;
            }
        }
        return element;
    }
    
    /**
     * 获得表单列表中的一行的表单链接
     * @param name - form name
     * @return - WebElement list
     */
    public WebElement getLinkOfForm(String name) {
    	WebElement row = getLineOfForm(name);
    	List<WebElement> cols = row.findElements(By.tagName("td"));
    	WebElement element = cols.get(0).findElement(By.tagName("a"));
        return element;
    }
    
    /**
     * 获得表单名称
     * @param uid - 表单id
     * @return - String
     */
    public String getFormName(String uid) {
        String formName = "";
        
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(1).getText().equals(uid)) {
                formName = cols.get(0).getText();
                break;
            }
        }
        
        return formName;
    }
    
    /**
     * 获得表单的编辑按钮
     * @param uid - 表单uid
     * @return WebElement
     */
    public WebElement editFormBtn(String uid) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(1).getText().equals(uid)) {
                element = cols.get(3).findElement(By.xpath(".//a[contains(@ng-click, 'editCrf')]"));
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得表单的删除按钮
     * @param uid - 表单uid
     * @return WebElement
     */
    public WebElement deleteFormBtn(String uid) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(1).getText().equals(uid)) {
                element = cols.get(3).findElement(By.xpath(".//a[contains(@ng-click, 'deleteCrf')]"));
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得表单的下载按钮
     * @param uid - 表单uid
     * @return WebElement
     */
    public WebElement downloadFormBtn(String uid) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && cols.get(1).getText().equals(uid)) {
                element = cols.get(3).findElement(By.xpath(".//a[contains(@ng-click, 'downloadCrf')]"));
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得删除表单对话框中的输入框
     * @return WebElement
     */
    public WebElement formNameInput() {
    	WebElement element = null;
        try {
            element = driver.findElement(By.xpath(".//input[contains(@ng-blur, 'vm.deleteValidation')]"));
        } catch (NoSuchElementException e) {
            element = null;
        }
        return element;
    }
    
    /**
     * 获得对话框的取消按钮
     * @return WebElement
     */
    public WebElement cancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-cancel-btn']"));
        return element;
    }
    
    /**
     * 获得对话框的确认按钮
     * @return WebElement
     */
    public WebElement confirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-confirm-btn']"));
        return element;
    }
    
    /**
     * 获得是否有覆盖表单提示信息
     * @return boolean
     */
    public boolean getOverwriteMsg() {
        try {
        	driver.findElement(By.xpath(".//p[contains(text(), '是否覆盖')]"));
        } catch (NoSuchElementException e) {
            return false;
        }
        return true;
    }
    
    /**
     * 获得编辑表单对话框中的section按钮
     * @return WebElement list
     */
    public List<WebElement> sectionBtnList() {
        WebElement container = driver.findElement(By.xpath(".//div[@class='edit-container ng-scope']"));
        List<WebElement> sections = container.findElements(By.xpath(".//span[contains(@ng-click, 'vm.activeSection')]"));
        
        return sections;
    }
    
    /**
     * 获得编辑表单对话框中的一个section的所有行
     * @return WebElement list
     */
    public List<WebElement> lineListInSection() {
        WebElement container = driver.findElement(By.xpath(".//div[@class='edit-container ng-scope']"));
        
        // get line list
        WebElement table = container.findElement(By.xpath(".//table[@class='table-bordered']"));
        List<WebElement> lines = table.findElements(By.tagName("tr"));
        
        return lines;
    }
    
    /**
     * 获得编辑表单对话框中的一个section的某一行的所有输入框
     * @param index - 行的index
     * @return WebElement list
     */
    public List<WebElement> inputListInLine(int index) {
        List<WebElement> inputs = lineListInSection().get(index).findElements(By.tagName("input"));
        
        return inputs;
    }
    
    /**
     * 获得编辑表单对话框中的添加一行按钮
     * @return WebElement
     */
    public WebElement addLineBtn() {
        WebElement container = driver.findElement(By.xpath(".//div[@class='edit-container ng-scope']"));
        WebElement element = container.findElement(By.xpath(".//button[contains(@ng-click, 'vm.addOneRow')]"));
        return element;
    }
    
    /**
     * 获得编辑表单对话框中的保存按钮
     * @return WebElement
     */
    public WebElement saveBtn() {
        WebElement container = driver.findElement(By.xpath(".//div[@class='edit-container ng-scope']"));
        WebElement element = container.findElement(By.xpath(".//button[contains(@ng-click, 'vm.updateCrf')]"));
        return element;
    }
    
    /**
     * 获得编辑表单对话框中的添加section按钮
     * @return WebElement
     */
    public WebElement addSectionBtn() {
        WebElement container = driver.findElement(By.xpath(".//div[@class='edit-container ng-scope']"));
        WebElement element = container.findElement(By.xpath(".//span[contains(@ng-click, 'vm.addOneSection')]"));
        return element;
    }
    
    /**
     * 获得编辑表单对话框中的关闭按钮
     * @return WebElement
     */
    public WebElement closeBtn() {
        WebElement container = driver.findElement(By.xpath(".//div[@class='edit-container ng-scope']"));
        WebElement element = container.findElement(By.xpath(".//span[@class='close-icon']"));
        return element;
    }
    
    /**
     * 获得表单页面的表单名
     * @return String
     */
    public String getOpenFormName() {
    	String name = "";
        WebElement div = driver.findElement(By.xpath(".//div[@class='preview-title text-left ng-binding']"));
        name = div.getText();
        return name;
    }
}
