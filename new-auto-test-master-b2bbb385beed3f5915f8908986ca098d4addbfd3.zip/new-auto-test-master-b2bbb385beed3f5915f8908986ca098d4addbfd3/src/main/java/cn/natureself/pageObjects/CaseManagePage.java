package cn.natureself.pageObjects;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/**
 * 病例管理页面对象类
 * 
 * @author lx
 */

public class CaseManagePage {

    private WebDriver driver;

    public CaseManagePage(WebDriver driver) {
        this.driver = driver;

    }

    /**
     * 获得添加病例按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement AddCaseBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[contains(@ng-click, 'addCasePopup')]"));
        return element;
    }

    /**
     * 获得我的病例radio button
     * @author lx 
     * @return WebElement
     */
    public WebElement MyCaseRadio() {
        WebElement div = driver.findElement(By.xpath(".//div[@class='radio-box pull-left']"));
        WebElement element = div.findElements(By.xpath(".//span[@class='replace-radio replace']")).get(0);
        return element;
    }

    /**
     * 获得所有病例radio button
     * @author lx 
     * @return WebElement
     */
    public WebElement AllCaseRadio() {
        WebElement div = driver.findElement(By.xpath(".//div[@class='radio-box pull-left']"));
        WebElement element = div.findElements(By.xpath(".//span[@class='replace-radio replace']")).get(1);
        return element;
    }

    /**
     * 获得搜索按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement SerachBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[contains(@ng-click, 'searchCasePopup')]"));
        return element;

    }

    /**
     * 获得所有分组按钮
     * 
     * @return WebElement list
     */
    public List<WebElement> getGroups() {
        WebElement ul = driver.findElement(By.xpath(".//ul[@class='tab-btns list-unstyled']"));
        List<WebElement> groups = ul.findElements(By.xpath(".//a[contains(@ui-sref, 'm.study.cases')]"));
        
        return groups;
    }
    
    /**
     * 获得指定的分组按钮
     * @param name - 分组名
     * @return WebElement
     */
    public WebElement ActiveGroupBtn(String name) {
    	WebElement element = null;
        List<WebElement> groups = getGroups();
        for (WebElement group:groups) {
            if (group.getText().contains(name)) {
                element = group;
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得病例列表的表头
     * 
     * @return WebElement list
     */
    public List<WebElement> getHeadsFromTable() {
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']/thead"));
        List<WebElement> elements = table.findElements(By.tagName("th"));
        return elements;
    }
    
    /**
     * 获得病例列表的所有行
     * @return WebElement List
     */
    public List<WebElement> getLinesOfCaseTable() {
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']/tbody"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        
        return rows;
    }
    
    /**
     * 获得病例列表的一行
     * @param caseID - 研究对象编号
     * @return WebElement - 病例列表中的相应的行
     */
    public WebElement getLineOfCase(String caseID) {
    	WebElement element = null;
        WebElement table = driver.findElement(By.xpath(".//table[@class='table']"));
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            if (cols.size() > 0 && (cols.get(1).getText().equals(caseID) || cols.get(2).getText().equals(caseID))) {
                element = row;
                break;
            }
        }
        
        return element;
    }
    
    /**
     * 获得一个病例的状态
     * @param caseID - 研究对象编号
     * @return String - 病例的状态
     */
    public String getStatusOfCase(String caseID) {
        WebElement row = getLineOfCase(caseID);
        List<WebElement> cols = row.findElements(By.tagName("td"));
        String status = cols.get(2).getText();
        
        return status;
    }
    
    /**
     * 获得一个病例的一个阶段的状态
     * @param caseID - 研究对象编号
     * @param stageName - 阶段名称
     * @return String - 病例的阶段的状态
     */
    public String getStageStatusOfCase(String caseID, String stageName) {
        List<WebElement> heads = getHeadsFromTable();
        WebElement row = getLineOfCase(caseID);
        int index = 0;
        String status = "";
        
        for (int i=0; i < heads.size(); i++) {
            if (heads.get(i).getText().equals(stageName)) {
                index = i;
                break;
            }
        }
        
        List<WebElement> cols = row.findElements(By.tagName("td"));
        status = cols.get(index).findElement(By.tagName("button")).getText();
        
        return status;
    }
    
    /**
     * 获得一个病例的一个阶段的按钮
     * @param caseID - 研究对象编号
     * @param stageName - 阶段名称
     * @return WebElement
     */
    public WebElement getStageBtnOfCase(String caseID, String stageName) {
        List<WebElement> heads = getHeadsFromTable();
        WebElement row = getLineOfCase(caseID);
        int index = 0;
        
        for (int i=0; i < heads.size(); i++) {
            if (heads.get(i).getText().equals(stageName)) {
                index = i;
                break;
            }
        }
        
        List<WebElement> cols = row.findElements(By.tagName("td"));
        WebElement element = cols.get(index).findElement(By.tagName("button"));
        
        return element;
    }

    /**
     * 获得一个病例的编辑病例按钮
     * @author lx 
     * @param caseID - 研究对象编号
     * @return WebElement
     */
    public WebElement ChangeCaseBtn(String caseID) {
        WebElement row = getLineOfCase(caseID);
        WebElement element = row.findElement(By.xpath(".//a[contains(@ng-click, 'editCasePopup')]"));
        return element;
    }

    /**
     * 获得一个病例的删除病例按钮
     * @author lx 
     * @param caseID - 研究对象编号
     * @return WebElement
     */
    public WebElement DeleteCaseBtn(String caseID) {
        WebElement row = getLineOfCase(caseID);
        WebElement element = row.findElement(By.xpath(".//a[contains(@ng-click, 'deleteCasePopup')]"));
        return element;
    }

    /**
     * 获得添加病例对话框的研究对象编号输入框
     * @author lx 
     * @return WebElement
     */
    public WebElement StudyObjectNumberInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='uid']"));
        return element;
    }

    /**
     * 获得添加病例对话框的姓名输入框
     * @author lx 
     * @return WebElement
     */
    public WebElement NameInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='sname']"));
        return element;
    }

    /**
     * 获得添加病例对话框的证件类型下拉列表
     * @author lx 
     * @return WebElement
     */
    public Select IDTypeSelect() {
        Select element = new Select(driver.findElement(By.xpath(".//select[@name='stype']")));
        return element;
    }

    /**
     * 获得添加病例对话框的证件号码输入框
     * @author lx 
     * @return WebElement
     */
    public WebElement IDNumberInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='sid']"));
        return element;
    }

    /**
     * 获得添加病例对话框的中心下拉列表
     * @author lx 
     * @return Select
     */
    public Select CenterSelect() {
        Select element = new Select(driver.findElement(By.xpath(".//select[@name='siteid']")));
        return element;
    }

    /**
     * 获得添加病例对话框的分组下拉列表
     * @author lx 
     * @return Select
     */
    public Select GroupSelect() {
        Select element;
        try {
            element = new Select(driver.findElement(By.xpath(".//select[@name='groupid']")));
        } catch (NoSuchElementException e) {
            return null;
        }
        return element;
    }

    /**
     * 获得添加病例/编辑病例对话框的添加/保存按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement AddEditCaseConfirmBtn() {
    	WebElement element = null;
        try {
            element = driver.findElement(By.xpath(".//input[@class='modal-confirm-btn']"));
        } catch (NoSuchElementException e) {
            return null;
        }
        return element;
    }

    /**
     * 获得添加病例/编辑病例对话框的取消按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement AddEditCaseCancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//input[@class='modal-cancel-btn']"));
        return element;
    }
    
    /**
     * 获得随机化项目添加病例对话框的添加按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement RandomAddCaseConfirmBtn() {
    	WebElement element = null;
        try {
            element = driver.findElement(By.xpath(".//input[@value='添加']"));
        } catch (NoSuchElementException e) {
            return null;
        }
        return element;
    }
    
    /**
     * 获得对话框的确认按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement ConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-confirm-btn']"));
        return element;
    }

    /**
     * 获得搜索对话框的取消按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement SearchCancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-cancel-btn']"));
        return element;
    }
    
    /**
     * 获得搜索对话框的确认按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement SearchConfirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//a[@class='modal-confirm-btn']"));
        return element;
    }

    /**
     * 获得对话框的取消按钮
     * @author lx 
     * @return WebElement
     */
    public WebElement CancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-cancel-btn']"));
        return element;
    }

    /**
     * 获得添加病例成功的对话框中显示的添加成功消息和姓名
     * @author lx 
     * @return String 
     */
    public String AddCaseSuccessMessage() {
        String msg = "";
        String caseName = "";
        WebElement div = driver.findElement(By.xpath(".//div[@class='modal-container ng-scope']"));
        List<WebElement> messages = div.findElements(By.tagName("h5"));
        if (messages.size() > 0) {
            msg = messages.get(0).getText();
            caseName = messages.get(0).findElement(By.tagName("strong")).getText();
        }
        return caseName + msg;

    }

    /**
     * 获得添加病例成功的对话框中显示的入组成功消息和分组名
     * @author lx 
     * @return String
     */
    public String AddCaseSuccessGroupMessage() {
        String msg = "";
        String groupName = "";
        WebElement div = driver.findElement(By.xpath(".//div[@class='modal-container ng-scope']"));
        List<WebElement> messages = div.findElements(By.tagName("h5"));
        if (messages.size() > 0) {
            msg = messages.get(1).getText();
            groupName = messages.get(1).findElement(By.tagName("strong")).getText();
        }
        return msg + groupName;

    }
    
    /**
     * 获得随机化项目添加病例成功的对话框中显示的分组名
     * @author lx 
     * @return String
     */
    public String RandomAddCaseGroupName() {
        String groupName = "";
        WebElement div = driver.findElement(By.xpath(".//div[@class='modal-container ng-scope']"));
        List<WebElement> texts = div.findElements(By.tagName("h5"));
        if (texts.size() > 0) {
            groupName = texts.get(1).findElement(By.tagName("strong")).getText();
        }
        return groupName;

    }
    
    /**
     * 获得编辑病例成功的对话框中显示的成功消息和姓名
     * @author lx 
     * @return String
     */
    public String EditCaseSuccessMessage() {
        String msg = "";
        String caseName = "";
        WebElement div = driver.findElement(By.xpath(".//div[@class='modal-container ng-scope']"));
        List<WebElement> messages = div.findElements(By.tagName("h5"));
        if (messages.size() > 0) {
            msg = messages.get(0).getText();
            caseName = messages.get(0).findElement(By.tagName("strong")).getText();
        }
        return caseName + msg;

    }

    /**
     * 获得搜索对话框中的姓名输入框
     * @author lx 
     * @return WebElement
     */
    public WebElement SearchCaseNameInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.searchCase.subject_name']"));
        return element;

    }

    /**
     * 获得搜索对话框中的研究编号输入框
     * @author lx 
     * @return WebElement
     */
    public WebElement SearchCaseNumberInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.searchCase.uid']"));
        return element;

    }

    /**
     * 获得搜索对话框中的病例状态下拉列表
     * @author lx 
     * @return Select
     */
    public Select SearchCaseStatusSelect() {
        Select element = new Select(driver.findElement(By.xpath(".//select[@ng-model='vm.searchCase.state']")));
        return element;
    }

    /**
     * 获得删除病例对话框中的病例信息输入错误checkbox
     * 
     * @return WebElement
     */
    public WebElement DeleteCaseReasonInputErrorCheckbox() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-change='vm.changeCheckbox()']"));
        return element;
    }

    /**
     * 获得删除病例对话框中的其它checkbox
     * 
     * @return WebElement
     */
    public WebElement DeleteCaseReasonOtherCheckbox() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.otherChecked']"));
        return element;
    }

    /**
     * 获得删除病例对话框中的其它原因输入框
     * 
     * @return WebElement
     */
    public WebElement DeleteCaseReasonOtherInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.otherValue']"));
        return element;
    }

    /**
     * 获得删除病例对话框中的姓名
     * 
     * @return String
     */
    public String getCaseNameInDeleteCaseDialog() {
        String caseName = "";
        WebElement form = driver.findElement(By.xpath(".//ng-form[@name='deleteCaseForm']"));
        List<WebElement> lines = form.findElements(By.tagName("ul"));
        if (lines.size() > 0) {
            List<WebElement> items = lines.get(0).findElements(By.tagName("li"));
            if (items.size() > 0) {
                caseName = items.get(0).findElement(By.tagName("strong")).getText();
            }
        }
        
        return caseName;
    }
    
    /**
     * 获得添加/编辑/搜索病例对话框中的日期选择控件
     * 
     * @return WebElement
     */
    public WebElement getDateInputInCaseDialog() {
    	WebElement element = driver.findElement(By.xpath(".//input[@id='add-case-datepicker']"));
        return element;
    }
    
    /**
     * 获得添加/编辑/搜索病例对话框中的时间选择控件
     * 
     * @return WebElement
     */
    public WebElement getTimeInputInCaseDialog() {
    	WebElement element = driver.findElement(By.xpath(".//input[@id='add-case-timepicker']"));
        return element;
    }
    
    /**
     * 获得修改病例确认对话框中的返回修改按钮
     * 
     * @return WebElement
     */
    public WebElement BackToEditBtn() {
    	WebElement element = driver.findElement(By.xpath(".//input[@value='返回修改']"));
        return element;
    }
    
    /**
     * 获得修改病例确认对话框中的修改原因输入框
     * 
     * @return WebElement
     */
    public WebElement ChangeReasonTextArea() {
    	WebElement element = driver.findElement(By.xpath(".//textarea[@name='editReason']"));
        return element;
    }

}
