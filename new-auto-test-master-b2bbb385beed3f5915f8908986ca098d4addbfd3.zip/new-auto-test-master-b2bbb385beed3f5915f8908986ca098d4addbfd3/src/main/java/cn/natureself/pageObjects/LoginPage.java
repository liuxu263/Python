package cn.natureself.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * 登录和注册页面对象类
 * 
 * @author Andy
 */
public class LoginPage {

    private WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    /**
     * 获得用户名输入框
     * 
     * @return WebElement
     */
    public WebElement userNameInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='email_phone']"));
        return element;
    }

    /**
     * 获得密码输入框
     * 
     * @return WebElement
     */
    public WebElement passwordInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='password']"));
        return element;
    }

    /**
     * 获得登录按钮
     * 
     * @return WebElement
     */
    public WebElement loginBtn() {
    	WebElement element = driver.findElement(By.xpath(".//input[@value='登录']"));
        return element;
    }

    /**
     * 获得自动登录checkbox
     * 
     * @return WebElement
     */
    public WebElement autoLoginCheckbox() {
    	WebElement element = driver.findElement(By.xpath(".//input[@type='checkbox']"));
        return element;
    }

    /**
     * 获得忘记密码link
     * 
     * @return WebElement
     */
    public WebElement forgetPwdLink() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ui-sref='m.forgetpwd']"));
        return element;
    }

    /**
     * 获得注册link
     * 
     * @return WebElement
     */
    public WebElement signUpLink() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ui-sref='m.signup']"));
        return element;
    }

    /**
     * 获得找回密码页面的邮箱输入框
     * 
     * @return WebElement
     */
    public WebElement emailInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@ng-model='vm.email']"));
        return element;
    }

    /**
     * 获得找回密码页面的确定按钮
     * 
     * @return WebElement
     */
    public WebElement confirmBtn() {
    	WebElement element = driver.findElement(By.xpath(".//input[@value='确定']"));
        return element;
    }

    /**
     * 获得找回密码页面的已经想起密码link
     * 
     * @return WebElement
     */
    public WebElement rememberLink() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ui-sref='m.signin']"));
        return element;
    }

    /**
     * 获得注册页面的邮箱输入框
     * 
     * @return WebElement
     */
    public WebElement signUpEmailInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='email']"));
        return element;
    }

    /**
     * 获得注册页面的密码输入框
     * 
     * @return WebElement
     */
    public WebElement signUpPwdInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='password']"));
        return element;
    }

    /**
     * 获得注册页面的再次输入密码输入框
     * 
     * @return WebElement
     */
    public WebElement signUpRePwdInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='reInputPassword']"));
        return element;
    }

    /**
     * 获得注册页面的姓名输入框
     * 
     * @return WebElement
     */
    public WebElement signUpNameInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='name']"));
        return element;
    }

    /**
     * 获得注册页面的手机号输入框
     * 
     * @return WebElement
     */
    public WebElement signUpPhoneInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='phone']"));
        return element;
    }

    /**
     * 获得注册页面的科室输入框
     * 
     * @return WebElement
     */
    public WebElement signUpDeptInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='department']"));
        return element;
    }

    /**
     * 获得注册页面的职称输入框
     * 
     * @return WebElement
     */
    public WebElement signUpTitleInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='title']"));
        return element;
    }

    /**
     * 获得注册页面的工作单位输入框
     * 
     * @return WebElement
     */
    public WebElement signUpSiteInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='site']"));
        return element;
    }

    /**
     * 获得注册页面的工作地址输入框
     * 
     * @return WebElement
     */
    public WebElement signUpAddrInput() {
    	WebElement element = driver.findElement(By.xpath(".//input[@name='address']"));
        return element;
    }

    /**
     * 获得注册页面的注册按钮
     * 
     * @return WebElement
     */
    public WebElement signUpBtn() {
    	WebElement element = driver.findElement(By.xpath(".//input[@value='注册']"));
        return element;
    }

    /**
     * 获得注册页面的直接登录link
     * 
     * @return WebElement
     */
    public WebElement signInLink() {
    	WebElement element = driver.findElement(By.xpath(".//a[@ui-sref='m.signin']"));
        return element;
    }
    
    /**
     * 获得对话框的取消按钮
     * 
     * @return WebElement
     */
    public WebElement cancelBtn() {
    	WebElement element = driver.findElement(By.xpath(".//button[@class='modal-cancel-btn']"));
        return element;
    }

}