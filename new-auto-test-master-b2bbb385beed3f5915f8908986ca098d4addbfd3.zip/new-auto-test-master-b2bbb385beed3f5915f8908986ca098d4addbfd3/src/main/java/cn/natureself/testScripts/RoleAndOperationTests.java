package cn.natureself.testScripts;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import cn.natureself.componentObjects.*;
import cn.natureself.pageActions.*;
import cn.natureself.pageObjects.*;
import cn.natureself.utils.*;

/**
 * 不同角色的权限和操作测试类
 * 
 * @author Andy
 */
public class RoleAndOperationTests extends BasicTest {
	public WebDriver driver;
	public CaseManagePage casePage;
	public CaseFillinPage fillinPage;
	public FormTaskPage taskPage;
	public AuditManagePage auditPage;
	public SiteManagePage sitePage;
	public RoleManagePage rolePage;
	public GroupManagePage groupPage;
	public PersonalInfoPage personPage;
	public ProjectPage projectPage;
	public ProjectListPage listPage;
	public FormManagePage formPage;
	public MenuBar menuBar;

	// The logger for this test file
	public static Logger Log = LogManager.getLogger(RoleAndOperationTests.class);

	public RoleAndOperationTests() {
		super();
	}

	@Override
	public Logger getLogger() {
		return RoleAndOperationTests.Log;
	}

	// test data
	public String centername1 = "北京大学医院";
	public String centername2 = "北京电力医院";
	public String groupname1 = "分组1";
	public String groupname2 = "分组2";
	public String stage1 = "阶段1";
	public String stage2 = "阶段2";
	public String stage3 = "阶段3";
	public String stage4 = "阶段4";
	public String formName1 = "OperationTest1";
	public String formName2 = "OperationTest2";
	public String section1 = "test1";
	public String section2 = "test2";
	public String[] test1Ctrls = {"text_1", "text_2", "text_3", "number_4", "number_5"};
	public String[] test2Ctrls = {"text_6", "text_7", "text_8", "number_9", "number_10"};

	public CaseInfo centerAdminCase1 = new CaseInfo(centername1, groupname1);
	public CaseInfo centerAdminCase2 = new CaseInfo(centername1, groupname2);
	public CaseInfo inputterCase1 = new CaseInfo(centername1, groupname1);
	public CaseInfo inputterCase2 = new CaseInfo(centername1, groupname2);
	public CaseInfo inputterCase3 = new CaseInfo(centername1, groupname1);
	public CaseInfo inputterCase4 = new CaseInfo(centername1, groupname2);
	public CaseInfo inputterCase5 = new CaseInfo(centername2, groupname1);
	public CaseInfo inputterCase6 = new CaseInfo(centername2, groupname2);
	public FormTaskInfo centerAdminTask1 = new FormTaskInfo();
	public FormTaskInfo centerAdminTask2 = new FormTaskInfo();
	public FormTaskInfo centerAdminTask3 = new FormTaskInfo();
	public FormTaskInfo centerAdminTask4 = new FormTaskInfo();
	public FormTaskInfo inputterTask1 = new FormTaskInfo();
	public FormTaskInfo inputterTask2 = new FormTaskInfo();
	public FormTaskInfo inputterTask3 = new FormTaskInfo();
	public FormTaskInfo inputterTask4 = new FormTaskInfo();
	public FormTaskInfo inputterTask5 = new FormTaskInfo();
	public FormTaskInfo inputterTask6 = new FormTaskInfo();
	public AuditInfo audit1 = new AuditInfo();
	public AuditInfo audit2 = new AuditInfo();
	public ProjectInfo projectInfo = new ProjectInfo();
	public SiteInfo site1 = new SiteInfo(centername1, "site1", "9999");
	public SiteInfo site2 = new SiteInfo(centername2, "site2", "9999");
    public RoleInfo inputter1 = new RoleInfo(JsonConf.LoginInputterName, UIStrings.ROLE_INPUTTER);
    public RoleInfo inputter2 = new RoleInfo(JsonConf.LoginInputterName2, UIStrings.ROLE_INPUTTER);
    public RoleInfo inputter3 = new RoleInfo(JsonConf.LoginInputterName3, UIStrings.ROLE_INPUTTER);
    public RoleInfo centeradmin1 = new RoleInfo(JsonConf.LoginCenterAdminName, UIStrings.ROLE_CENTER_ADMIN);
    public RoleInfo centeradmin2 = new RoleInfo(JsonConf.LoginCenterAdminName2, UIStrings.ROLE_CENTER_ADMIN);
    public RoleInfo auditor1 = new RoleInfo(JsonConf.LoginAuditorName, UIStrings.ROLE_AUDITOR);
    public RoleInfo auditor2 = new RoleInfo(JsonConf.LoginAuditorName2, UIStrings.ROLE_AUDITOR);
    public RoleInfo auditor3 = new RoleInfo(JsonConf.LoginAuditorName3, UIStrings.ROLE_AUDITOR);
    public RoleInfo admin1 = new RoleInfo(JsonConf.LoginAdminName, UIStrings.ROLE_ADMIN);
    public RoleInfo admin2 = new RoleInfo(JsonConf.LoginAdminName2, UIStrings.ROLE_ADMIN);
    public RoleInfo watcher = new RoleInfo(JsonConf.LoginWatcherName, UIStrings.ROLE_WATCHER);

	@BeforeClass
	public void NormalLoginAndChooseProject() throws InterruptedException {
		Log.info("");
		Log.info("****************** 不同角色的权限和操作测试 -- START ******************");
		Log.info("");

		driver = getDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		casePage = new CaseManagePage(driver);
		fillinPage = new CaseFillinPage(driver);
		menuBar = new MenuBar(driver);
		taskPage = new FormTaskPage(driver);
		auditPage = new AuditManagePage(driver);
		sitePage = new SiteManagePage(driver);
		rolePage = new RoleManagePage(driver);
		groupPage = new GroupManagePage(driver);
		personPage = new PersonalInfoPage(driver);
		projectPage = new ProjectPage(driver);
		listPage = new ProjectListPage(driver);
		formPage = new FormManagePage(driver);
		
		projectInfo.setName("角色操作权限测试项目");
		projectInfo.setStatus("配置中");
		projectInfo.setCaseNumber("111111");
		projectInfo.setType("实用性临床试验");
		
		inputter1.addCenter(centername1);
		inputter2.addCenter(centername1);
		inputter3.addCenter(centername2);
		centeradmin1.addCenter(centername1);
		centeradmin2.addCenter(centername2);
		auditor1.addCenter(centername1);
		auditor2.addCenter(centername2);
		auditor3.addCenter(centername1);
		auditor3.addCenter(centername2);
		watcher.addCenter(centername1);
		watcher.addCenter(centername2);

		// 打开主页
		Log.info("打开主页");
		driver.get(JsonConf.LoginSystemURL);
		Thread.sleep(5000);

		// 确认进入主页
		Log.info("Assertion - 确认是否进入主页");
		Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
		Log.info("Assertion - 进入主页 - PASS");
	}

	@AfterClass
	public void NormalQuit() {
		Log.info("");
		Log.info("****************** 不同角色的权限和操作测试 -- END ******************");
		Log.info("");
		driver.quit();
	}

	/**
	 * 登录并进入指定页面
	 * 
	 * @param user - user name
	 * @param pwd - password
	 * @param page - page name
	 * @throws InterruptedException
	 */
	public void LoginAndGotoPage(String user, String pwd, String page) throws InterruptedException {
		// 用户登陆
		Log.info("用户登陆");
		LoginPageAction.Login(driver, user, pwd);

		// 进入项目
		Log.info("选择角色操作权限测试项目");
		ProjectListPageAction.enterProject(driver, projectInfo.getName());
		
		// 进入指定页面
		Log.info("进入指定页面");
		menuBar.getMenuItem(page).click();
		Thread.sleep(2000);
	}
	
	/**
	 * 验证今日提醒里的信息
	 * 
	 * @param roleInfo - RoleInfo Object
	 */
	public void CheckInfoInReminderBlock(RoleInfo roleInfo) {
		List<WebElement> info = projectPage.getInfoInRemindBlock();
		int size = info.size();
		if (size > 2) {
	        Assert.assertEquals(info.get(0).getText(), roleInfo.getName());
	        Assert.assertEquals(info.get(size-1).getText(), roleInfo.getRight());
	        Assert.assertEquals(size-2, roleInfo.getCenter().size());
	        boolean bSame = false;
	        for (int i=1; i<size-1; i++) {
	        	bSame = false;
	        	for (String center:roleInfo.getCenter()) {
	        	    if (info.get(i).getText().equals(center)) {
	        	    	bSame = true;
	        	    }
	        	}
	        }
	        Assert.assertTrue(bSame);
		} else {
	        Assert.assertEquals(info.get(0).getText(), roleInfo.getName());
	        Assert.assertEquals(info.get(1).getText(), roleInfo.getRight());
		}
	}
	
	/**
	 * 验证项目状况里的信息
	 * @param roleInfo - RoleInfo Object
	 */
	public void CheckInfoInStatusBlock(RoleInfo roleInfo) {
	    String name = projectPage.getItemInStatusBlock("name");
	    String status = projectPage.getItemInStatusBlock("status");
	    String caseNumber = projectPage.getItemInStatusBlock("caseNumber");
	    String type = projectPage.getItemInStatusBlock("type");
	    Assert.assertEquals(projectInfo.getName(), name);
	    Assert.assertEquals(projectInfo.getStatus(), status);
	    Assert.assertEquals(projectInfo.getCaseNumber(), caseNumber);
	    Assert.assertEquals(projectInfo.getType(), type);
	    if (roleInfo.getRight().equals(UIStrings.ROLE_CENTER_ADMIN) || 
	    		roleInfo.getRight().equals(UIStrings.ROLE_INPUTTER)) {
	    	String center = projectPage.getItemInStatusBlock("center");
	    	String cenCaseNum = projectPage.getItemInStatusBlock("cenCaseNum");
	    	Assert.assertEquals(roleInfo.getCenter().get(0), center);
	    	Assert.assertEquals(cenCaseNum, "9999");
	    }
	}
	
    /**
     * 项目管理员权限和操作的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void ProjectAdminTest1() throws InterruptedException {
        Log.info("****************** 项目管理员权限和操作的测试 - PART1 -- START ******************");
        
        Log.info("管理员登录进入项目主页");
        LoginAndGotoPage(JsonConf.LoginAdminName, JsonConf.LoginAdminPassWord, UIStrings.MENU_FRONTPAGE);
        admin1.setName(menuBar.getUserName());
        
        Log.info("验证今日提醒里的信息");
        CheckInfoInReminderBlock(admin1);
        Log.info("验证今日提醒里的信息 - PASS");
        
        Log.info("验证项目状况里的信息");
        CheckInfoInStatusBlock(admin1);
        Log.info("验证项目状况里的信息 - PASS");
        
        Log.info("点击今日提醒里的机构设置按钮");
        projectPage.getItemInRemindBlock(UIStrings.MENU_SITE_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认进入机构设置页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("sites"));
        Log.info("确认进入机构设置页面 - PASS");
        
        Log.info("添加机构");
        SiteManagePageAction.addSite(driver, site1);
        SiteManagePageAction.addSite(driver, site2);
        
        Log.info("确认添加成功");
        Assert.assertNotNull(sitePage.getLineOfSite(site1.getName()));
        Assert.assertNotNull(sitePage.getLineOfSite(site2.getName()));
        Log.info("确认添加成功 - PASS");
        
        Log.info("回到首页");
        menuBar.getMenuItem(UIStrings.MENU_FRONTPAGE).click();
        Thread.sleep(2000);
        
        Log.info("点击今日提醒里的人员设置按钮");
        projectPage.getItemInRemindBlock(UIStrings.MENU_ROLE_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认进入人员设置页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("roles"));
        Log.info("确认进入人员设置页面 - PASS");
        
        Log.info("添加人员");
        RoleManagePageAction.addRole(driver, inputter1);
        RoleManagePageAction.addRole(driver, inputter3);
        RoleManagePageAction.addRole(driver, centeradmin1);
        RoleManagePageAction.addRole(driver, centeradmin2);
        RoleManagePageAction.addRole(driver, admin2);
        RoleManagePageAction.addRole(driver, auditor1);
        RoleManagePageAction.addRole(driver, auditor2);
        RoleManagePageAction.addRole(driver, auditor3);
        RoleManagePageAction.addRole(driver, watcher);
        
        Log.info("确认添加成功");
        Assert.assertNotNull(rolePage.getLineOfRole(inputter1.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(inputter3.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(centeradmin1.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(centeradmin2.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(admin2.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(auditor1.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(auditor2.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(auditor3.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(watcher.getEmail()));
        Log.info("确认添加成功 - PASS");
        
        Log.info("回到首页");
        menuBar.getMenuItem(UIStrings.MENU_FRONTPAGE).click();
        Thread.sleep(2000);
        
        Log.info("点击今日提醒里的分组和阶段管理按钮");
        projectPage.getItemInRemindBlock(UIStrings.MENU_GROUP_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认进入分组和阶段管理页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("groupevents"));
        Log.info("确认进入分组和阶段管理页面 - PASS");
        
        Log.info("添加分组和阶段");
        GroupManagePageAction.AddGroup(driver, groupname1, "g1");
        GroupManagePageAction.AddGroup(driver, groupname2, "g2");
        GroupManagePageAction.AddStage(driver, groupname1, stage1, "s1");
        GroupManagePageAction.AddStage(driver, groupname1, stage2, "s2");
        GroupManagePageAction.AddStage(driver, groupname2, stage3, "s3");
        GroupManagePageAction.AddStage(driver, groupname2, stage4, "s4");
        
        Log.info("分配表单");
        groupPage.ActiveGroupBtn(groupname1).click();
        Thread.sleep(1000);
        List<WebElement> checkboxList = groupPage.AssignFormCheckbox();
        checkboxList.get(0).click();
        Thread.sleep(1000);
        checkboxList.get(3).click();
        Thread.sleep(1000);
        groupPage.SaveStageBtn().click();
        Thread.sleep(1000);
        groupPage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(1000);
        checkboxList = groupPage.AssignFormCheckbox();
        checkboxList.get(0).click();
        Thread.sleep(1000);
        checkboxList.get(3).click();
        Thread.sleep(1000);
        groupPage.SaveStageBtn().click();
        Thread.sleep(1000);
        
        Log.info("管理员登出");
        MenuBarAction.logout(driver);
        
        Log.info("****************** 项目管理员权限和操作的测试 - PART1 -- END ******************");
    }
    
    /**
     * 中心管理员权限和操作的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void CenterAdminTest1() throws InterruptedException {
        Log.info("****************** 中心管理员权限和操作的测试 - PART1 -- START ******************");
        
        Log.info("中心管理员登录进入项目主页");
        LoginAndGotoPage(JsonConf.LoginCenterAdminName, JsonConf.LoginCenterAdminPassWord, UIStrings.MENU_FRONTPAGE);
        
        Log.info("验证今日提醒里的信息");
        CheckInfoInReminderBlock(centeradmin1);
        Log.info("验证今日提醒里的信息 - PASS");
        
        Log.info("验证项目状况里的信息");
        CheckInfoInStatusBlock(centeradmin1);
        Log.info("验证项目状况里的信息 - PASS");
        
        Log.info("点击今日提醒里的人员设置按钮");
        projectPage.getItemInRemindBlock(UIStrings.MENU_ROLE_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认进入人员设置页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("roles"));
        Log.info("确认进入人员设置页面 - PASS");
        
        Log.info("确认只能看见同中心的人员信息");
        Assert.assertNotNull(rolePage.getLineOfRole(inputter1.getEmail()));
        Assert.assertNull(rolePage.getLineOfRole(inputter3.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(centeradmin1.getEmail()));
        Assert.assertNull(rolePage.getLineOfRole(centeradmin2.getEmail()));
        Assert.assertNull(rolePage.getLineOfRole(admin1.getEmail()));
        Assert.assertNull(rolePage.getLineOfRole(admin2.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(auditor1.getEmail()));
        Assert.assertNull(rolePage.getLineOfRole(auditor2.getEmail()));
        Assert.assertNotNull(rolePage.getLineOfRole(auditor3.getEmail()));
        Assert.assertNull(rolePage.getLineOfRole(watcher.getEmail()));
        Log.info("确认只能看见同中心的人员信息 - PASS");
        
        Log.info("确认可以删除录入员，不能删除监查员");
        Assert.assertNotNull(rolePage.deleteRoleBtn(inputter1.getEmail()));
        Assert.assertNull(rolePage.deleteRoleBtn(auditor1.getEmail()));
        Assert.assertNull(rolePage.deleteRoleBtn(auditor3.getEmail()));
        Log.info("确认可以删除录入员，不能删除监查员 - PASS");
        
        Log.info("添加人员");
        rolePage.addRoleBtn().click();
        Thread.sleep(1000);
        rolePage.roleEmailInput().sendKeys(inputter2.getEmail());
        rolePage.selectRoleCtrl().selectByVisibleText(inputter2.getRight());
        List<WebElement> info = rolePage.getInfoInAddRoleDialog();
        inputter2.setName(info.get(1).getAttribute("value"));
        inputter2.setSite(info.get(2).getAttribute("value"));
        
        Log.info("确认中心管理员只能添加中心管理员和录入员");
        Select roleSelect = rolePage.selectRoleCtrl();
        Assert.assertEquals(roleSelect.getOptions().size(), 2);
        Assert.assertEquals(roleSelect.getOptions().get(0).getText(), UIStrings.ROLE_CENTER_ADMIN);
        Assert.assertEquals(roleSelect.getOptions().get(1).getText(), UIStrings.ROLE_INPUTTER);
        Log.info("确认中心管理员只能添加中心管理员和录入员 - PASS");
        
        roleSelect.selectByVisibleText(UIStrings.ROLE_INPUTTER);
        rolePage.AddRoleConfirmBtn().click();
        Thread.sleep(2000);
        
        Log.info("确认添加成功");
        Assert.assertNotNull(rolePage.getLineOfRole(inputter2.getEmail()));
        WebElement row = rolePage.getLineOfRole(inputter2.getEmail());
        List<WebElement> cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(1).getText(), centeradmin1.getCenter().get(0));
        inputter2.addCenter(centeradmin1.getCenter().get(0));
        Log.info("确认添加成功 - PASS");
        
        Log.info("回到首页");
        menuBar.getMenuItem(UIStrings.MENU_FRONTPAGE).click();
        Thread.sleep(2000);
        
        Log.info("点击今日提醒里的病例管理按钮");
        projectPage.getItemInRemindBlock(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认进入病例管理页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("cases"));
        Log.info("确认进入病例管理页面 - PASS");
        
        Log.info("添加病例");
        CaseManagePageAction.AddCase(driver, centerAdminCase1, "id18");
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        CaseManagePageAction.AddCase(driver, centerAdminCase2, "id18");
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("确认添加成功");
        casePage.ActiveGroupBtn(groupname1).click();
        Thread.sleep(2000);
        Assert.assertNotNull(casePage.getLineOfCase(centerAdminCase1.getStudyNumber()));
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(2000);
        Assert.assertNotNull(casePage.getLineOfCase(centerAdminCase2.getStudyNumber()));
        centerAdminCase1.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        centerAdminCase1.setInputter(menuBar.getUserName());
        centerAdminCase1.addStageStatus(stage1, UIStrings.STAGE_STATUS_NEW);
        centerAdminCase1.addStageStatus(stage2, UIStrings.STAGE_STATUS_NEW);
        centerAdminCase2.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        centerAdminCase2.setInputter(menuBar.getUserName());
        centerAdminCase2.addStageStatus(stage3, UIStrings.STAGE_STATUS_NEW);
        centerAdminCase2.addStageStatus(stage4, UIStrings.STAGE_STATUS_NEW);
        Log.info("确认添加成功 - PASS");
        
        Log.info("填写提交表单");
        casePage.ActiveGroupBtn(groupname1).click();
        Thread.sleep(1000);
        casePage.getStageBtnOfCase(centerAdminCase1.getStudyNumber(), stage1).click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        fillinPage.getStageLink(stage2).click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        
        Log.info("到病例管理页面，确认阶段病例状态");
        menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        casePage.ActiveGroupBtn(groupname1).click();
        Thread.sleep(1000);
        Assert.assertEquals(casePage.getStageStatusOfCase(centerAdminCase1.getStudyNumber(), stage1), UIStrings.STAGE_STATUS_SUBMIT);
        Assert.assertEquals(casePage.getStageStatusOfCase(centerAdminCase1.getStudyNumber(), stage2), UIStrings.STAGE_STATUS_INPROGRESS);
        Assert.assertEquals(casePage.getStatusOfCase(centerAdminCase1.getStudyNumber()), UIStrings.CASE_STATUS_INPROGRESS);
        centerAdminCase1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_SUBMIT);
        centerAdminCase1.setStatusOfStage(stage2, UIStrings.STAGE_STATUS_INPROGRESS);
        centerAdminCase1.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        Log.info("到病例管理页面，确认阶段病例状态 - PASS");
        
        Log.info("到表单任务页面，确认任务");
        centerAdminTask1.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        centerAdminTask1.setStage(stage1);
        centerAdminTask1.setName(centerAdminCase1.getName());
        centerAdminTask1.setCaseStatus(centerAdminCase1.getStatus());
        centerAdminTask1.setStudyNumber(centerAdminCase1.getStudyNumber());
        centerAdminTask1.setGroup(centerAdminCase1.getGroupName());
        centerAdminTask1.setCenter(centerAdminCase1.getCenterName());
        centerAdminTask1.setInputter(centerAdminCase1.getInputter());
        centerAdminTask1.setAuditor("-");
        centerAdminTask2.setStatus(UIStrings.STAGE_STATUS_INPROGRESS);
        centerAdminTask2.setStage(stage2);
        centerAdminTask2.setName(centerAdminCase1.getName());
        centerAdminTask2.setCaseStatus(centerAdminCase1.getStatus());
        centerAdminTask2.setStudyNumber(centerAdminCase1.getStudyNumber());
        centerAdminTask2.setGroup(centerAdminCase1.getGroupName());
        centerAdminTask2.setCenter(centerAdminCase1.getCenterName());
        centerAdminTask2.setInputter(centerAdminCase1.getInputter());
        centerAdminTask2.setAuditor("-");
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_INPROGRESS).click();
        Thread.sleep(2000);
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask1.getStudyNumber(), centerAdminTask1.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask2.getStudyNumber(), centerAdminTask2.getStage()));
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT).click();
        Thread.sleep(2000);
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask2.getStudyNumber(), centerAdminTask2.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask1.getStudyNumber(), centerAdminTask1.getStage()));
        Log.info("到表单任务页面，确认任务 - PASS");
        
        Log.info("不同中心的管理员登录");
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginCenterAdminName2, JsonConf.LoginCenterAdminPassWord2, UIStrings.MENU_CASE_MANAGE);
        
        Log.info("确认看不到别的中心的病例");
        casePage.AllCaseRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(casePage.getLineOfCase(centerAdminCase1.getStudyNumber()));
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(2000);
        casePage.AllCaseRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(casePage.getLineOfCase(centerAdminCase2.getStudyNumber()));
        Log.info("确认看不到别的中心的病例 - PASS");
        
        Log.info("确认看不到别的中心的表单任务");
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_INPROGRESS).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask2.getStudyNumber(), centerAdminTask2.getStage()));
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask1.getStudyNumber(), centerAdminTask1.getStage()));
        Log.info("确认看不到别的中心的表单任务 - PASS");
        
        Log.info("中心管理员登出");
        MenuBarAction.logout(driver);
        
        Log.info("****************** 中心管理员权限和操作的测试 - PART1 -- END ******************");
    }
    
    /**
     * 录入员权限和操作的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void InputterTest1() throws InterruptedException {
        Log.info("****************** 录入员权限和操作的测试 - PART1 -- START ******************");
        
        Log.info("录入员登录进入项目主页");
        LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord, UIStrings.MENU_FRONTPAGE);
        
        Log.info("验证今日提醒里的信息");
        CheckInfoInReminderBlock(inputter1);
        Log.info("验证今日提醒里的信息 - PASS");
        
        Log.info("验证项目状况里的信息");
        CheckInfoInStatusBlock(inputter1);
        Log.info("验证项目状况里的信息 - PASS");
        
        Log.info("点击今日提醒里的病例管理按钮");
        projectPage.getItemInRemindBlock(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认进入病例管理页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("cases"));
        Log.info("确认进入病例管理页面 - PASS");
        
        Log.info("点击所有病例，确认能看见同中心的病例");
        casePage.AllCaseRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(casePage.getLineOfCase(centerAdminCase1.getStudyNumber()));
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(2000);
        casePage.AllCaseRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(casePage.getLineOfCase(centerAdminCase2.getStudyNumber()));
        Log.info("点击所有病例，确认能看见同中心的病例 - PASS");
        
        Log.info("确认可以操作同中心的病例的表单");
        casePage.getStageBtnOfCase(centerAdminCase2.getStudyNumber(), stage3).click();
        Thread.sleep(2000);
        Log.info("填写提交表单");
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        fillinPage.getStageLink(stage4).click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        Log.info("确认可以操作同中心的病例的表单 - PASS");
        
        Log.info("到病例管理页面，确认阶段病例状态");
        menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(2000);
        casePage.AllCaseRadio().click();
        Thread.sleep(2000);
        Assert.assertEquals(casePage.getStageStatusOfCase(centerAdminCase2.getStudyNumber(), stage3), UIStrings.STAGE_STATUS_SUBMIT);
        Assert.assertEquals(casePage.getStageStatusOfCase(centerAdminCase2.getStudyNumber(), stage4), UIStrings.STAGE_STATUS_INPROGRESS);
        Assert.assertEquals(casePage.getStatusOfCase(centerAdminCase2.getStudyNumber()), UIStrings.CASE_STATUS_INPROGRESS);
        WebElement row = casePage.getLineOfCase(centerAdminCase2.getStudyNumber());
        List<WebElement> cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(4).getText(), centerAdminCase2.getInputter());
        centerAdminCase2.setStatusOfStage(stage3, UIStrings.STAGE_STATUS_SUBMIT);
        centerAdminCase2.setStatusOfStage(stage4, UIStrings.STAGE_STATUS_INPROGRESS);
        centerAdminCase2.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        Log.info("到病例管理页面，确认阶段病例状态 - PASS");
        
        Log.info("到表单任务页面，确认任务");
        centerAdminTask3.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        centerAdminTask3.setStage(stage3);
        centerAdminTask3.setName(centerAdminCase2.getName());
        centerAdminTask3.setCaseStatus(centerAdminCase2.getStatus());
        centerAdminTask3.setStudyNumber(centerAdminCase2.getStudyNumber());
        centerAdminTask3.setGroup(centerAdminCase2.getGroupName());
        centerAdminTask3.setCenter(centerAdminCase2.getCenterName());
        centerAdminTask3.setInputter(menuBar.getUserName());
        centerAdminTask3.setAuditor("-");
        centerAdminTask4.setStatus(UIStrings.STAGE_STATUS_INPROGRESS);
        centerAdminTask4.setStage(stage4);
        centerAdminTask4.setName(centerAdminCase2.getName());
        centerAdminTask4.setCaseStatus(centerAdminCase2.getStatus());
        centerAdminTask4.setStudyNumber(centerAdminCase2.getStudyNumber());
        centerAdminTask4.setGroup(centerAdminCase2.getGroupName());
        centerAdminTask4.setCenter(centerAdminCase2.getCenterName());
        centerAdminTask4.setInputter(centerAdminCase2.getInputter());
        centerAdminTask4.setAuditor("-");
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_INPROGRESS).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask2.getStudyNumber(), centerAdminTask2.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask4.getStudyNumber(), centerAdminTask4.getStage()));
        row = taskPage.getLineOfTask(centerAdminTask4.getStudyNumber(), centerAdminTask4.getStage());
        cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(6).getText(), centerAdminTask4.getInputter());
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT).click();
        Thread.sleep(2000);
        taskPage.MyFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask3.getStudyNumber(), centerAdminTask3.getStage()));
        row = taskPage.getLineOfTask(centerAdminTask3.getStudyNumber(), centerAdminTask3.getStage());
        cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(6).getText(), centerAdminTask3.getInputter());
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask1.getStudyNumber(), centerAdminTask1.getStage()));
        Log.info("到表单任务页面，确认任务 - PASS");
        
        Log.info("到病例管理页面");
        menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("添加病例");
        CaseManagePageAction.AddCase(driver, inputterCase1, "id18");
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        CaseManagePageAction.AddCase(driver, inputterCase2, "id18");
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("确认添加成功");
        casePage.ActiveGroupBtn(groupname1).click();
        Thread.sleep(2000);
        Assert.assertNotNull(casePage.getLineOfCase(inputterCase1.getStudyNumber()));
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(2000);
        Assert.assertNotNull(casePage.getLineOfCase(inputterCase2.getStudyNumber()));
        inputterCase1.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        inputterCase1.setInputter(menuBar.getUserName());
        inputterCase1.addStageStatus(stage1, UIStrings.STAGE_STATUS_NEW);
        inputterCase1.addStageStatus(stage2, UIStrings.STAGE_STATUS_NEW);
        inputterCase2.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        inputterCase2.setInputter(menuBar.getUserName());
        inputterCase2.addStageStatus(stage3, UIStrings.STAGE_STATUS_NEW);
        inputterCase2.addStageStatus(stage4, UIStrings.STAGE_STATUS_NEW);
        Log.info("确认添加成功 - PASS");
        
        Log.info("填写提交表单");
        casePage.ActiveGroupBtn(groupname1).click();
        Thread.sleep(1000);
        casePage.getStageBtnOfCase(inputterCase1.getStudyNumber(), stage1).click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        fillinPage.getStageLink(stage2).click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        
        menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(1000);
        casePage.getStageBtnOfCase(inputterCase2.getStudyNumber(), stage3).click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        fillinPage.getStageLink(stage4).click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        
        Log.info("终止病例2填写");
        CaseFillinPageAction.abortCaseFillin(driver, stage4);
        Thread.sleep(1000);
        
        Log.info("到病例管理页面，确认阶段病例状态");
        menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        casePage.ActiveGroupBtn(groupname1).click();
        Thread.sleep(2000);
        Assert.assertEquals(casePage.getStageStatusOfCase(inputterCase1.getStudyNumber(), stage1), UIStrings.STAGE_STATUS_SUBMIT);
        Assert.assertEquals(casePage.getStageStatusOfCase(inputterCase1.getStudyNumber(), stage2), UIStrings.STAGE_STATUS_SUBMIT);
        Assert.assertEquals(casePage.getStatusOfCase(inputterCase1.getStudyNumber()), UIStrings.CASE_STATUS_INPROGRESS);
        inputterCase1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_SUBMIT);
        inputterCase1.setStatusOfStage(stage2, UIStrings.STAGE_STATUS_SUBMIT);
        inputterCase1.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(2000);
        Assert.assertEquals(casePage.getStageStatusOfCase(inputterCase2.getStudyNumber(), stage3), UIStrings.STAGE_STATUS_SUBMIT);
        Assert.assertEquals(casePage.getStageStatusOfCase(inputterCase2.getStudyNumber(), stage4), UIStrings.STAGE_STATUS_INPROGRESS);
        Assert.assertEquals(casePage.getStatusOfCase(inputterCase2.getStudyNumber()), UIStrings.CASE_STATUS_ABORT);
        inputterCase1.setStatusOfStage(stage3, UIStrings.STAGE_STATUS_SUBMIT);
        inputterCase1.setStatusOfStage(stage4, UIStrings.STAGE_STATUS_INPROGRESS);
        inputterCase1.setStatus(UIStrings.CASE_STATUS_ABORT);
        Log.info("到病例管理页面，确认阶段病例状态 - PASS");
        
        Log.info("到表单任务页面，确认任务");
        inputterTask1.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        inputterTask1.setStage(stage1);
        inputterTask1.setName(inputterCase1.getName());
        inputterTask1.setCaseStatus(inputterCase1.getStatus());
        inputterTask1.setStudyNumber(inputterCase1.getStudyNumber());
        inputterTask1.setGroup(inputterCase1.getGroupName());
        inputterTask1.setCenter(inputterCase1.getCenterName());
        inputterTask1.setInputter(inputterCase1.getInputter());
        inputterTask1.setAuditor("-");
        inputterTask2.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        inputterTask2.setStage(stage2);
        inputterTask2.setName(inputterCase1.getName());
        inputterTask2.setCaseStatus(inputterCase1.getStatus());
        inputterTask2.setStudyNumber(inputterCase1.getStudyNumber());
        inputterTask2.setGroup(inputterCase1.getGroupName());
        inputterTask2.setCenter(inputterCase1.getCenterName());
        inputterTask2.setInputter(inputterCase1.getInputter());
        inputterTask2.setAuditor("-");
        inputterTask3.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        inputterTask3.setStage(stage3);
        inputterTask3.setName(inputterCase2.getName());
        inputterTask3.setCaseStatus(inputterCase2.getStatus());
        inputterTask3.setStudyNumber(inputterCase2.getStudyNumber());
        inputterTask3.setGroup(inputterCase2.getGroupName());
        inputterTask3.setCenter(inputterCase2.getCenterName());
        inputterTask3.setInputter(inputterCase2.getInputter());
        inputterTask3.setAuditor("-");
        inputterTask4.setStatus(UIStrings.STAGE_STATUS_INPROGRESS);
        inputterTask4.setStage(stage4);
        inputterTask4.setName(inputterCase2.getName());
        inputterTask4.setCaseStatus(inputterCase2.getStatus());
        inputterTask4.setStudyNumber(inputterCase2.getStudyNumber());
        inputterTask4.setGroup(inputterCase2.getGroupName());
        inputterTask4.setCenter(inputterCase2.getCenterName());
        inputterTask4.setInputter(inputterCase2.getInputter());
        inputterTask4.setAuditor("-");
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_INPROGRESS).click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask4.getStudyNumber(), inputterTask4.getStage()));
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT).click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask1.getStudyNumber(), inputterTask1.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask2.getStudyNumber(), inputterTask2.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask3.getStudyNumber(), inputterTask3.getStage()));
        Log.info("到表单任务页面，确认任务 - PASS");
        
        Log.info("录入员登出，同中心录入员2登录");
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginInputterName2, JsonConf.LoginInputterPassWord2, UIStrings.MENU_CASE_MANAGE);
        
        Log.info("点击所有病例，确认能看见同中心的病例");
        casePage.AllCaseRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(casePage.getLineOfCase(inputterCase1.getStudyNumber()));
        Assert.assertNotNull(casePage.getLineOfCase(centerAdminCase1.getStudyNumber()));
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(2000);
        casePage.AllCaseRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(casePage.getLineOfCase(inputterCase2.getStudyNumber()));
        Assert.assertNotNull(casePage.getLineOfCase(centerAdminCase2.getStudyNumber()));
        Log.info("点击所有病例，确认能看见同中心的病例 - PASS");
        
        Log.info("确认可以操作同中心的病例的表单");
        casePage.getStageBtnOfCase(inputterCase2.getStudyNumber(), stage4).click();
        Thread.sleep(2000);
        Log.info("填写提交表单");
        CaseFillinPageAction.fillinTextInputCtrl(driver, "text");
        CaseFillinPageAction.fillinNumberCtrl(driver, "6");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        Log.info("确认可以操作同中心的病例的表单 - PASS");
        
        Log.info("到病例管理页面，确认阶段病例状态");
        menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(2000);
        casePage.AllCaseRadio().click();
        Thread.sleep(2000);
        Assert.assertEquals(casePage.getStageStatusOfCase(inputterCase2.getStudyNumber(), stage3), UIStrings.STAGE_STATUS_SUBMIT);
        Assert.assertEquals(casePage.getStageStatusOfCase(inputterCase2.getStudyNumber(), stage4), UIStrings.STAGE_STATUS_SUBMIT);
        Assert.assertEquals(casePage.getStatusOfCase(inputterCase2.getStudyNumber()), UIStrings.CASE_STATUS_ABORT);
        row = casePage.getLineOfCase(inputterCase2.getStudyNumber());
        cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(4).getText(), inputterCase2.getInputter());
        inputterCase2.setStatusOfStage(stage4, UIStrings.STAGE_STATUS_SUBMIT);
        Log.info("到病例管理页面，确认阶段病例状态 - PASS");
        
        Log.info("到表单任务页面，确认任务");
        inputterTask4.setInputter(menuBar.getUserName());
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT).click();
        Thread.sleep(2000);
        taskPage.MyFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask4.getStudyNumber(), inputterTask4.getStage()));
        row = taskPage.getLineOfTask(inputterTask4.getStudyNumber(), inputterTask4.getStage());
        cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(6).getText(), inputterTask4.getInputter());
        Log.info("到表单任务页面，确认任务 - PASS");
        
        Log.info("到首页");
        menuBar.getMenuItem(UIStrings.MENU_FRONTPAGE).click();
        Thread.sleep(2000);
        
        Log.info("点击今日提醒里的添加病例按钮");
        projectPage.getItemInRemindBlock(UIStrings.MENU_ADD_CASE).click();
        Thread.sleep(2000);
        
        Log.info("确认添加病例对话框打开");
        boolean found = true;
        try {
        	driver.findElement(By.xpath(".//ng-form[@name='addCaseForm']"));
        } catch (NoSuchElementException e) {
        	found = false;
        }
        Assert.assertTrue(found);
        Log.info("确认添加病例对话框打开 - PASS");
        
        Log.info("添加病例");
        casePage.AddEditCaseCancelBtn().click();
        Thread.sleep(1000);
        CaseManagePageAction.AddCase(driver, inputterCase3, "id18");
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        CaseManagePageAction.AddCase(driver, inputterCase4, "id18");
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        inputterCase3.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        inputterCase3.setInputter(menuBar.getUserName());
        inputterCase3.addStageStatus(stage1, UIStrings.STAGE_STATUS_NEW);
        inputterCase3.addStageStatus(stage2, UIStrings.STAGE_STATUS_NEW);
        inputterCase4.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        inputterCase4.setInputter(menuBar.getUserName());
        inputterCase4.addStageStatus(stage3, UIStrings.STAGE_STATUS_NEW);
        inputterCase4.addStageStatus(stage4, UIStrings.STAGE_STATUS_NEW);
        
        Log.info("录入员2登出，不同中心录入员3登录");
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginInputterName3, JsonConf.LoginInputterPassWord3, UIStrings.MENU_CASE_MANAGE);
        
        Log.info("确认看不到别的中心的病例");
        casePage.AllCaseRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(casePage.getLineOfCase(inputterCase1.getStudyNumber()));
        Assert.assertNull(casePage.getLineOfCase(centerAdminCase1.getStudyNumber()));
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(2000);
        Assert.assertNull(casePage.getLineOfCase(inputterCase2.getStudyNumber()));
        Assert.assertNull(casePage.getLineOfCase(centerAdminCase2.getStudyNumber()));
        Log.info("确认看不到别的中心的病例 - PASS");
        
        Log.info("确认看不到别的中心的表单任务");
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_INPROGRESS).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask2.getStudyNumber(), centerAdminTask2.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask4.getStudyNumber(), centerAdminTask4.getStage()));
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask1.getStudyNumber(), centerAdminTask1.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask3.getStudyNumber(), centerAdminTask3.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(inputterTask1.getStudyNumber(), inputterTask1.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(inputterTask2.getStudyNumber(), inputterTask2.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(inputterTask3.getStudyNumber(), inputterTask3.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(inputterTask4.getStudyNumber(), inputterTask4.getStage()));
        Log.info("确认看不到别的中心的表单任务 - PASS");
        
        Log.info("到病例管理页面");
        menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("添加病例");
        CaseManagePageAction.AddCase(driver, inputterCase5, "id18");
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        CaseManagePageAction.AddCase(driver, inputterCase6, "id18");
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        inputterCase5.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        inputterCase5.setInputter(menuBar.getUserName());
        inputterCase5.addStageStatus(stage1, UIStrings.STAGE_STATUS_NEW);
        inputterCase5.addStageStatus(stage2, UIStrings.STAGE_STATUS_NEW);
        inputterCase6.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        inputterCase6.setInputter(menuBar.getUserName());
        inputterCase6.addStageStatus(stage3, UIStrings.STAGE_STATUS_NEW);
        inputterCase6.addStageStatus(stage4, UIStrings.STAGE_STATUS_NEW);
        
        Log.info("填写提交表单");
        casePage.ActiveGroupBtn(groupname1).click();
        Thread.sleep(1000);
        casePage.getStageBtnOfCase(inputterCase5.getStudyNumber(), stage1).click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        fillinPage.getStageLink(stage2).click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, "testtext");
        CaseFillinPageAction.fillinNumberCtrl(driver, "3");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        inputterTask5.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        inputterTask5.setStage(stage1);
        inputterTask5.setName(inputterCase5.getName());
        inputterTask5.setCaseStatus(inputterCase5.getStatus());
        inputterTask5.setStudyNumber(inputterCase5.getStudyNumber());
        inputterTask5.setGroup(inputterCase5.getGroupName());
        inputterTask5.setCenter(inputterCase5.getCenterName());
        inputterTask5.setInputter(inputterCase5.getInputter());
        inputterTask5.setAuditor("-");
        inputterTask6.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        inputterTask6.setStage(stage2);
        inputterTask6.setName(inputterCase5.getName());
        inputterTask6.setCaseStatus(inputterCase5.getStatus());
        inputterTask6.setStudyNumber(inputterCase5.getStudyNumber());
        inputterTask6.setGroup(inputterCase5.getGroupName());
        inputterTask6.setCenter(inputterCase5.getCenterName());
        inputterTask6.setInputter(inputterCase5.getInputter());
        inputterTask6.setAuditor("-");
        
        Log.info("录入员登出");
        MenuBarAction.logout(driver);
        
        Log.info("****************** 录入员权限和操作的测试 - PART1 -- END ******************");
    }
    
    /**
     * 监查员权限和操作的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void AuditorTest1() throws InterruptedException {
        Log.info("****************** 监查员权限和操作的测试 - PART1 -- START ******************");
        
        Log.info("监查员登录进入项目主页");
        LoginAndGotoPage(JsonConf.LoginAuditorName, JsonConf.LoginAuditorPassWord, UIStrings.MENU_FRONTPAGE);
        
        Log.info("验证今日提醒里的信息");
        CheckInfoInReminderBlock(auditor1);
        Log.info("验证今日提醒里的信息 - PASS");
        
        Log.info("验证项目状况里的信息");
        CheckInfoInStatusBlock(auditor1);
        Log.info("验证项目状况里的信息 - PASS");
        
        Log.info("点击今日提醒里的表单任务按钮");
        projectPage.getItemInRemindBlock(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        
        Log.info("确认进入表单任务页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("caseEvents"));
        Log.info("确认进入表单任务页面 - PASS");
        
        Log.info("确认只能看到同中心的表单任务");
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask1.getStudyNumber(), centerAdminTask1.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask3.getStudyNumber(), centerAdminTask3.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask1.getStudyNumber(), inputterTask1.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask2.getStudyNumber(), inputterTask2.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask3.getStudyNumber(), inputterTask3.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask4.getStudyNumber(), inputterTask4.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(inputterTask5.getStudyNumber(), inputterTask5.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(inputterTask6.getStudyNumber(), inputterTask6.getStage()));
        Log.info("确认只能看到同中心的表单任务 - PASS");
        
        Log.info("进入inputterCase1的阶段1表单添加质疑");
        taskPage.getStageLink(inputterTask1.getStudyNumber(), inputterTask1.getStage()).click();
        Thread.sleep(1000);
        fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_NOAUDIT).get(0).click();
        Thread.sleep(1000);
        AuditManagePageAction.AddAuditRecordAction(driver, "add audit", "add", true);
		audit1.setOperation(UIStrings.AUDIT_STATUS_WAITFORFIX);
		audit1.setAuditor(menuBar.getUserName());
		audit1.setInputter(inputterCase1.getInputter());
		audit1.setCenter(inputterCase1.getCenterName());
		audit1.setQuestion(test1Ctrls[0]);
		audit1.setStudyNumber(inputterCase1.getStudyNumber());
		audit1.setGroup(inputterCase1.getGroupName());
		audit1.setStage(inputterTask1.getStage());
		audit1.setForm(fillinPage.getActiveFormName());
		audit1.setSection(fillinPage.getActiveSectionName());
        
        Log.info("通过inputterCase1的阶段2表单");
        fillinPage.getStageLink(stage2).click();
        Thread.sleep(1000);
        fillinPage.getPassBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("到表单任务页面");
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        
        Log.info("确认表单任务的状态和监查负责人变化");
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_AUDIT).click();
        Thread.sleep(2000);
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask1.getStudyNumber(), inputterTask1.getStage()));
        WebElement row = taskPage.getLineOfTask(inputterTask1.getStudyNumber(), inputterTask1.getStage());
        List<WebElement> cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(7).getText(), menuBar.getUserName());
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_PASS).click();
        Thread.sleep(2000);
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask2.getStudyNumber(), inputterTask2.getStage()));
        row = taskPage.getLineOfTask(inputterTask2.getStudyNumber(), inputterTask2.getStage());
        cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(7).getText(), menuBar.getUserName());
        inputterCase1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_AUDIT);
        inputterCase1.setStatusOfStage(stage2, UIStrings.STAGE_STATUS_PASS);
        inputterTask1.setAuditor(menuBar.getUserName());
        inputterTask1.setStatus(UIStrings.STAGE_STATUS_AUDIT);
        inputterTask2.setAuditor(menuBar.getUserName());
        inputterTask2.setStatus(UIStrings.STAGE_STATUS_PASS);
        Log.info("确认表单任务的状态和监查负责人变化 - PASS");
        
        Log.info("到质疑管理页面");
        menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认待修复质疑");
        auditPage.MyAuditRadioBtn().click();
        Thread.sleep(1000);
        Assert.assertNotNull(auditPage.getLineOfAudit(audit1));
        Log.info("确认待修复质疑 - PASS");
        
        Log.info("监查员2登录");
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginAuditorName2, JsonConf.LoginAuditorPassWord2, UIStrings.MENU_FORM_TASK);
        
        Log.info("确认只能看到同中心的表单任务");
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask1.getStudyNumber(), centerAdminTask1.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(centerAdminTask3.getStudyNumber(), centerAdminTask3.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(inputterTask3.getStudyNumber(), inputterTask3.getStage()));
        Assert.assertNull(taskPage.getLineOfTask(inputterTask4.getStudyNumber(), inputterTask4.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask5.getStudyNumber(), inputterTask5.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask6.getStudyNumber(), inputterTask6.getStage()));
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_AUDIT).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(taskPage.getLineOfTask(inputterTask1.getStudyNumber(), inputterTask1.getStage()));
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_PASS).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNull(taskPage.getLineOfTask(inputterTask2.getStudyNumber(), inputterTask2.getStage()));
        Log.info("确认只能看到同中心的表单任务 - PASS");
        
        Log.info("到质疑管理页面");
        menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认只能看到同中心的质疑");
        auditPage.AllAuditRadioBtn().click();
        Thread.sleep(1000);
        Assert.assertNull(auditPage.getLineOfAudit(audit1));
        Log.info("确认只能看到同中心的质疑 - PASS");
        
        Log.info("到表单任务页面");
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        
        Log.info("进入inputterCase5的阶段1表单添加质疑");
        taskPage.getStageLink(inputterTask5.getStudyNumber(), inputterTask5.getStage()).click();
        Thread.sleep(1000);
        fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_NOAUDIT).get(0).click();
        Thread.sleep(1000);
        AuditManagePageAction.AddAuditRecordAction(driver, "add audit", "add", true);
		audit2.setOperation(UIStrings.AUDIT_STATUS_WAITFORFIX);
		audit2.setAuditor(menuBar.getUserName());
		audit2.setInputter(inputterCase5.getInputter());
		audit2.setCenter(inputterCase5.getCenterName());
		audit2.setQuestion(test1Ctrls[0]);
		audit2.setStudyNumber(inputterCase5.getStudyNumber());
		audit2.setGroup(inputterCase5.getGroupName());
		audit2.setStage(inputterTask5.getStage());
		audit2.setForm(fillinPage.getActiveFormName());
		audit2.setSection(fillinPage.getActiveSectionName());
		
        Log.info("到表单任务页面");
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        
        Log.info("确认表单任务的状态和监查负责人变化");
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_AUDIT).click();
        Thread.sleep(2000);
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask5.getStudyNumber(), inputterTask5.getStage()));
        row = taskPage.getLineOfTask(inputterTask5.getStudyNumber(), inputterTask5.getStage());
        cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(7).getText(), menuBar.getUserName());
        inputterCase5.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_AUDIT);
        inputterTask5.setAuditor(menuBar.getUserName());
        inputterTask5.setStatus(UIStrings.STAGE_STATUS_AUDIT);
        Log.info("确认表单任务的状态和监查负责人变化 - PASS");
        
        Log.info("到质疑管理页面");
        menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认待修复质疑");
        auditPage.MyAuditRadioBtn().click();
        Thread.sleep(1000);
        Assert.assertNotNull(auditPage.getLineOfAudit(audit2));
        Log.info("确认待修复质疑 - PASS");
        
        Log.info("监查员登出");
        MenuBarAction.logout(driver);
        
        Log.info("****************** 监查员权限和操作的测试 - PART1 -- END ******************");
    }
    
    /**
     * 项目管理员权限和操作的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void ProjectAdminTest2() throws InterruptedException {
        Log.info("****************** 项目管理员权限和操作的测试 - PART2 -- START ******************");
        
        Log.info("管理员登录进入表单任务");
        LoginAndGotoPage(JsonConf.LoginAdminName, JsonConf.LoginAdminPassWord, UIStrings.MENU_FORM_TASK);
        
        Log.info("确认能看见所有中心的表单");
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask1.getStudyNumber(), centerAdminTask1.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(centerAdminTask3.getStudyNumber(), centerAdminTask3.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask3.getStudyNumber(), inputterTask3.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask4.getStudyNumber(), inputterTask4.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask6.getStudyNumber(), inputterTask6.getStage()));
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_AUDIT).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask1.getStudyNumber(), inputterTask1.getStage()));
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask5.getStudyNumber(), inputterTask5.getStage()));
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_PASS).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        Assert.assertNotNull(taskPage.getLineOfTask(inputterTask2.getStudyNumber(), inputterTask2.getStage()));
        Log.info("确认能看见所有中心的表单 - PASS");
        
        Log.info("进入监查中的表单");
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_AUDIT).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        taskPage.getStageLink(inputterTask1.getStudyNumber(), inputterTask1.getStage()).click();
        Thread.sleep(1000);
        
        Log.info("确认可操作已有的质疑");
        fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_WAITFORFIX).get(0).click();
        AuditManagePageAction.AddAuditRecordAction(driver, "close audit", "close", true);
        audit1.setOperation(UIStrings.AUDIT_STATUS_CLOSED);
        Log.info("确认可操作已有的质疑 - PASS");
        
        Log.info("确认不能通过其他监查负责人的表单");
        Assert.assertNull(fillinPage.getPassBtn());
        Log.info("确认不能通过其他监查负责人的表单 - PASS");
        
        Log.info("管理员接管表单任务");
        menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
        Thread.sleep(2000);
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_AUDIT).click();
        Thread.sleep(2000);
        taskPage.AllFormRadio().click();
        Thread.sleep(2000);
        taskPage.getUndertakeBtn(inputterTask1.getStudyNumber(), inputterTask1.getStage()).click();
        taskPage.ConfirmBtn().click();
        Thread.sleep(1000);
        inputterTask1.setAuditor(menuBar.getUserName());
        
        Log.info("进入接管的表单");
        taskPage.getStageLink(inputterTask1.getStudyNumber(), inputterTask1.getStage()).click();
        Thread.sleep(1000);
        
        Log.info("确认可以通过表单");
        Assert.assertNotNull(fillinPage.getPassBtn());
        Log.info("确认可以通过表单 - PASS");
        
        Log.info("到质疑管理页面");
        menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("确认可看到所有质疑");
        Assert.assertNotNull(auditPage.getLineOfAudit(audit2));
        auditPage.getStatusGroupBtn(UIStrings.AUDIT_STATUS_CLOSED).click();
        Thread.sleep(2000);
        Assert.assertNotNull(auditPage.getLineOfAudit(audit1));
        Log.info("确认可看到所有质疑 - PASS");
        
        Log.info("管理员登出");
        MenuBarAction.logout(driver);
        
        Log.info("****************** 项目管理员权限和操作的测试 - PART2 -- END ******************");
    }
    
    /**
     * 项目观察员权限和操作的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void WatcherTest() throws InterruptedException {
        Log.info("****************** 项目观察员权限和操作的测试 -- START ******************");
        
        Log.info("项目观察员登录进入项目主页");
        LoginAndGotoPage(JsonConf.LoginWatcherName, JsonConf.LoginWatcherPassWord, UIStrings.MENU_FRONTPAGE);
        
        Log.info("验证今日提醒里的信息");
        CheckInfoInReminderBlock(watcher);
        Log.info("验证今日提醒里的信息 - PASS");
        
        Log.info("验证项目状况里的信息");
        CheckInfoInStatusBlock(watcher);
        Log.info("验证项目状况里的信息 - PASS");
        
        Log.info("确认没有文件管理模块");
        Assert.assertNull(projectPage.getBlock(UIStrings.PROJECT_FILE_BLOCK));
        Log.info("确认没有文件管理模块 - PASS");
        
        Log.info("点击今日提醒里的表单管理按钮");
        projectPage.getItemInRemindBlock(UIStrings.MENU_FORM_MANAGE).click();
        Thread.sleep(1000);
        
        Log.info("验证进入表单管理页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("crfs"));
        Log.info("验证进入表单管理页面 - PASS");
        
        Log.info("点击表单链接");
        formPage.getLinkOfForm(formName1).click();
        Thread.sleep(1000);
        
        Log.info("验证打开表单");
        Assert.assertEquals(formPage.getOpenFormName(), formName1);
        Log.info("验证打开表单 - PASS");
        
        Log.info("项目观察员登出");
        MenuBarAction.logout(driver);
        
        Log.info("****************** 项目观察员权限和操作的测试  -- END ******************");
    }
    
    /**
     * 监查员权限和操作的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void AuditorTest2() throws InterruptedException {
        Log.info("****************** 监查员权限和操作的测试 - PART2 -- START ******************");
        
        Log.info("监查员3登录");
        LoginPageAction.Login(driver, JsonConf.LoginAuditorName3, JsonConf.LoginAuditorPassWord3);
        
        Log.info("确认不会出现2个相同项目");
        Assert.assertEquals(listPage.getProjectCount(projectInfo.getName()), 1);
        Log.info("确认不会出现2个相同项目 - PASS");
        
        Log.info("进入项目");
        ProjectListPageAction.enterProject(driver, projectInfo.getName());
        
        Log.info("验证今日提醒里的信息");
        CheckInfoInReminderBlock(auditor3);
        Log.info("验证今日提醒里的信息 - PASS");
        
        Log.info("验证项目状况里的信息");
        CheckInfoInStatusBlock(auditor3);
        Log.info("验证项目状况里的信息 - PASS");
        
        Log.info("监查员登出");
        MenuBarAction.logout(driver);
        
        Log.info("****************** 监查员权限和操作的测试 - PART2 -- END ******************");
    }
}