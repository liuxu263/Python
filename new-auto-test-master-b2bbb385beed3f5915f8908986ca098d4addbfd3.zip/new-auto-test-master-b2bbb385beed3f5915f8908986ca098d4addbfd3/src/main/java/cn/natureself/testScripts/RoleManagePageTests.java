package cn.natureself.testScripts;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cn.natureself.componentObjects.RoleInfo;
import cn.natureself.pageActions.LoginPageAction;
import cn.natureself.pageActions.ProjectListPageAction;
import cn.natureself.pageObjects.RoleManagePage;
import cn.natureself.pageActions.RoleManagePageAction;
import cn.natureself.pageObjects.MenuBar;
import cn.natureself.utils.*;

/**
 * 人员设置测试类
 * 
 * @author Andy
 */
public class RoleManagePageTests extends BasicTest {
    public WebDriver driver;
    public RoleManagePage rolePage;
    public MenuBar menuBar;

    // The logger for this test file
    public static Logger Log = LogManager.getLogger(RoleManagePageTests.class);
    
    public RoleManagePageTests() {
        super();
    }
    
    @Override
    public Logger getLogger() {
        return RoleManagePageTests.Log;
    }
    
    // test data
    public RoleInfo inputter = new RoleInfo(JsonConf.LoginInputterName, UIStrings.ROLE_INPUTTER);
    public RoleInfo centeradmin = new RoleInfo(JsonConf.LoginCenterAdminName, UIStrings.ROLE_CENTER_ADMIN);
    public RoleInfo auditor = new RoleInfo(JsonConf.LoginAuditorName, UIStrings.ROLE_AUDITOR);
    
    @BeforeClass
    public void beforeClass() throws InterruptedException {
        Log.info("");
        Log.info("******************人员设置页面测试 -- START ******************");
        Log.info("");
        
        driver = getDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        rolePage = new RoleManagePage(driver);
        
        // Pre1 - 打开主页
        Log.info("Pre1 - 打开主页");
        driver.get(JsonConf.LoginSystemURL);
        Thread.sleep(5000);
        
        // 确认进入主页
        Log.info("Assertion - 确认是否进入主页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 进入主页 - PASS");
        
        // Pre2 - 项目管理员登录
        Log.info("Pre2 - 项目管理员登录");
        LoginPageAction.Login(driver, JsonConf.LoginAdminName, JsonConf.LoginAdminPassWord);
        
        // Pre3 - 进入项目
        Log.info("Pre3 - 进入项目");
        ProjectListPageAction.enterProject(driver, "人员设置自动化测试项目");
        
        // Pre4 - 进入人员设置页面
        Log.info("Pre4 - 进入人员设置页面");
        menuBar = new MenuBar(driver);
        menuBar.getMenuItem(UIStrings.MENU_ROLE_MANAGE).click();
        Thread.sleep(2000);
        
        // Pre5 - 验证进入人员设置页面
        Log.info("Pre5 - 验证进入人员设置页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("roles"));
        Log.info("验证进入人员设置页面 - PASS");
    }
    
    @AfterClass
    public void afterClass() {
        Log.info("");
        Log.info("******************人员设置页面测试 -- END ******************");
        Log.info("");
        driver.quit();
    }
    
    /**
     * 正常添加人员流程测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void normalAddRoleTest() throws InterruptedException {
        
        Log.info("******************正常添加人员流程测试 -- START ******************");
        
        Log.info("Step1 - 点击添加按钮");        
        Log.info("Step2 - 添加录入员");
        RoleManagePageAction.addRole(driver, inputter);
        
        // Step3 - 验证添加结果
        Log.info("Step3 - 验证添加录入员结果");
        WebElement row = rolePage.getLineOfRole(inputter.getEmail());
        List<WebElement> cols = row.findElements(By.tagName("td"));
        Log.info("验证权限");
        Assert.assertTrue(cols.get(0).getText().equals(inputter.getRight()));
        Log.info("验证研究中心");
        Assert.assertTrue(cols.get(1).getText().equals(inputter.getCenter().get(0)));
        Log.info("验证姓名");
        Assert.assertTrue(cols.get(2).getText().equals(inputter.getName()));
        Log.info("验证邮箱");
        Assert.assertTrue(cols.get(3).getText().equals(inputter.getEmail()));
        Log.info("验证工作单位");
        Assert.assertTrue(cols.get(5).getText().equals(inputter.getSite()));
        Log.info("Assertion - 验证添加录入员结果 - PASS");
        
        Log.info("Step4 - 点击添加按钮");
        Log.info("Step5 - 添加中心管理员");
        RoleManagePageAction.addRole(driver, centeradmin);
        
        // Step6 - 验证添加结果
        Log.info("Step6 - 验证添加中心管理员结果");
        row = rolePage.getLineOfRole(centeradmin.getEmail());
        cols = row.findElements(By.tagName("td"));
        Log.info("验证权限");
        Assert.assertTrue(cols.get(0).getText().equals(centeradmin.getRight()));
        Log.info("验证研究中心");
        Assert.assertTrue(cols.get(1).getText().equals(centeradmin.getCenter().get(0)));
        Log.info("验证姓名"); 
        Assert.assertTrue(cols.get(2).getText().equals(centeradmin.getName()));
        Log.info("验证邮箱");
        Assert.assertTrue(cols.get(3).getText().equals(centeradmin.getEmail()));
        Log.info("验证工作单位");
        Assert.assertTrue(cols.get(5).getText().equals(centeradmin.getSite()));
        Log.info("Assertion - 验证添加中心管理员结果 - PASS");
        
        Log.info("Step7 - 点击添加按钮");
        Log.info("Step8 - 添加监查员");
        RoleManagePageAction.addRole(driver, auditor);
        
        // Step9 - 验证添加结果
        Log.info("Step9 - 验证添加监查员结果");
        row = rolePage.getLineOfRole(auditor.getEmail());
        cols = row.findElements(By.tagName("td"));
        Log.info("验证权限");
        Assert.assertTrue(cols.get(0).getText().equals(auditor.getRight()));
        Log.info("验证研究中心");
        boolean found = false;
        List<WebElement> centerList = cols.get(1).findElements(By.tagName("span"));
        Assert.assertEquals(auditor.getCenter().size(), centerList.size());
        for (WebElement center:centerList) {
            found = false;
            if(auditor.getCenter().contains(center.getText())) {
                found = true;
            }
        }
        Assert.assertTrue(found);
        Log.info("验证姓名");
        Assert.assertTrue(cols.get(2).getText().equals(auditor.getName()));
        Log.info("验证邮箱");
        Assert.assertTrue(cols.get(3).getText().equals(auditor.getEmail()));
        Log.info("验证工作单位");
        Assert.assertTrue(cols.get(5).getText().equals(auditor.getSite()));
        Log.info("Assertion - 验证添加监查员结果 - PASS");
        
        Log.info("******************正常添加人员流程测试 -- END ******************");
    }
    
    /**
     * 添加人员信息验证测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void addRoleCheckTest() throws InterruptedException {
        Log.info("******************添加人员信息验证测试 -- START ******************");
        
        // Step1 - 点击添加按钮
        Log.info("Step1 - 点击添加按钮");
        rolePage.addRoleBtn().click();
        Thread.sleep(1000);
        
        // Step2 - 添加错误信息
        Log.info("Step2 - 添加错误信息");
        rolePage.roleEmailInput().sendKeys("email");
        rolePage.AddRoleConfirmBtn().click();
        Thread.sleep(2000);
        Log.info("验证邮箱格式错误信息");
        String path = ".//p[contains(text(), '" + UIStrings.ROLE_MAIL_FORMAT_ERR + "')]";
        WebElement form = driver.findElement(By.xpath(".//ng-form[@name='addRoleForm']"));
        WebElement element = form.findElement(By.xpath(path));
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.ROLE_MAIL_FORMAT_ERR));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证邮箱格式错误信息 - PASS");
        
        Log.info("验证邮箱未注册错误信息");
        rolePage.roleEmailInput().clear();
        rolePage.roleEmailInput().sendKeys("not@exist.com");
        rolePage.AddRoleConfirmBtn().click();
        Thread.sleep(2000);
        path = ".//p[contains(text(), '" + UIStrings.ROLE_MAIL_NOT_EXIST_ERR + "')]";
        element = form.findElement(By.xpath(path));
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.ROLE_MAIL_NOT_EXIST_ERR));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证邮箱未注册错误信息  - PASS");
        
        Log.info("验证用户在项目中已经有角色错误信息");
        rolePage.roleEmailInput().clear();
        rolePage.roleEmailInput().sendKeys(JsonConf.LoginAdminName);
        rolePage.AddRoleConfirmBtn().click();
        Thread.sleep(2000);
        path = ".//p[contains(text(), '" + UIStrings.ROLE_EXIST_ERR + "')]";
        element = form.findElement(By.xpath(path));
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.ROLE_EXIST_ERR));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        
        Log.info("验证用户在项目中已经有角色错误信息  - PASS");
        
        // 取消操作
        rolePage.AddRoleCancelBtn().click();
        Thread.sleep(1000);
        
        Log.info("******************添加人员信息验证测试 -- END ******************");
    }
    
    /**
     * 删除人员
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void deleteRoleTest() throws InterruptedException {
        Log.info("******************删除人员测试 -- START ******************");
        
        // 删除所有人员
        Log.info("Step1 - 删除所有人员");
        RoleManagePageAction.deleteRole(driver, inputter.getEmail());
        RoleManagePageAction.deleteRole(driver, centeradmin.getEmail());
        RoleManagePageAction.deleteRole(driver, auditor.getEmail());
        
        // Step2 - 验证人员已删除
        Log.info("Step2 - 验证人员已删除");
        Assert.assertEquals(rolePage.getLinesOfRoleTable().size(), 1);
        Log.info("验证人员已删除  - PASS");
        
        Log.info("******************删除人员测试 -- END ******************");
    }
}