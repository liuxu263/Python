package cn.natureself.testScripts;

import cn.natureself.pageObjects.FormManagePage;
import cn.natureself.pageObjects.MenuBar;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import cn.natureself.pageActions.FormManagePageAction;
import cn.natureself.pageActions.LoginPageAction;
import cn.natureself.pageActions.ProjectListPageAction;
import cn.natureself.utils.*;

/**
 * 表单管理测试类
 * 
 * @author Andy
 */
public class FormManagePageTests extends BasicTest {
    public WebDriver driver;
    public FormManagePage formPage;
    public MenuBar menuBar;
    public String hostname;
    
    // The logger for this test file
    public static Logger Log = LogManager.getLogger(FormManagePageTests.class);
    
    public FormManagePageTests() {
        super("WIN10");
    }
    
    @Override
    public Logger getLogger() {
        return FormManagePageTests.Log;
    }
    
    // test data
    public String upload_file = "upload_form_test.exe";
    public String formName ="test";
    public String formUID ="test";
    
    @BeforeClass
    public void beforeClass() throws InterruptedException, UnknownHostException {
        Log.info("");
        Log.info("******************表单管理页面测试 START ******************");
        Log.info("");
        
        driver = getDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        formPage = new FormManagePage(driver);
        
        // get hostname
        hostname = GetProxyIp.getip((RemoteWebDriver)driver);
        
        // Pre1 - 打开主页
        Log.info("Pre1 - 打开主页");
        driver.get(JsonConf.LoginSystemURL);
        Thread.sleep(5000);
        
        // 确认进入主页
        Log.info("Assertion - 确认是否进入主页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 进入主页 - PASS");
        
        // Pre2 - 项目管理员登录
        Log.info("Pre2 - 项目管理员登录");
        LoginPageAction.Login(driver, JsonConf.LoginAdminName, JsonConf.LoginAdminPassWord);
        
        // Pre3 - 进入项目
        Log.info("Pre3 - 进入项目");
        ProjectListPageAction.enterProject(driver, "表单管理自动化测试项目");
        
        // Pre4 - 进入机构设置页面
        Log.info("Pre4 - 进入表单管理页面");
        menuBar = new MenuBar(driver);
        menuBar.getMenuItem(UIStrings.MENU_FORM_MANAGE).click();
        Thread.sleep(2000);
        
        // Pre5 - 验证进入表单管理页面
        Log.info("Pre5 - 验证进入表单管理页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("crfs"));
        Log.info("验证进入表单管理页面 - PASS");
    }
    
    @AfterClass
    public void afterClass() {
        Log.info("");
        Log.info("******************表单管理页面测试 END ******************");
        Log.info("");
        driver.quit();
    }
    
    /**
     * 上传表单测试
     * @author Andy
     * @throws IOException
     * @throws InterruptedException
     */
    @Test
    public void uploadFormTest() throws IOException, InterruptedException {
        
        Log.info("******************上传表单测试 START ******************");
        
        // Step1 - 上传表单
        Log.info("Step1 - 上传表单");
        FormManagePageAction.uploadForm(driver, hostname, upload_file);
        
        // Step2 - 验证上传成功
        Log.info("验证上传成功");
        List<WebElement> rows = formPage.getLinesOfFormTable();
        Assert.assertEquals(rows.size(), 1);
        List<WebElement> cols = rows.get(0).findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(0).getText(), formName);
        Assert.assertEquals(cols.get(1).getText(), formUID);
        Log.info("验证上传成功 - PASS");
        
        Log.info("******************上传表单测试 END ******************");
    }
    
    /**
     * 编辑表单测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void editFormTest() throws InterruptedException {
        
        Log.info("******************编辑表单测试 START ******************");
        
        // Step1 - 编辑表单
        Log.info("Step1 - 编辑表单");
        FormManagePageAction.editForm(driver, formUID, "test", "test1");
        
        // Step2 - 验证编辑成功
        // TODO
        
        Log.info("******************编辑表单测试 END ******************");
    }
    
    /**
     * 删除section和表单测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void deleteFormTest() throws InterruptedException {
        
        Log.info("******************删除section和表单测试 START ******************");
        
        // Step1 - 点击编辑表单
        Log.info("Step1 - 点击编辑表单");
        formPage.editFormBtn(formUID).click();
        Thread.sleep(1000);
        
        // Step2 - 删除section
        Log.info("Step2 - 删除section");
        List<WebElement> list = formPage.sectionBtnList();
        list.get(list.size() - 1).findElement(By.xpath(".//a[contains(@ng-click, 'removeCurrentSection')]")).click();
        Thread.sleep(1000);
        
        // 验证删除对话框
        Log.info("验证删除section对话框");
        formPage.confirmBtn().click();
        Thread.sleep(1000);
        Log.info("直接点确定，验证错误提示信息");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.SECTION_NAME_NOT_INPUT_ERR));
        Log.info("直接点确定，验证错误提示信息 - PASS");
        
        Log.info("验证输入名称不符合信息");
        formPage.formNameInput().sendKeys("empty");
        Thread.sleep(1000);
        formPage.confirmBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.SECTION_NAME_NOT_SAME_ERR));
        Log.info("验证输入名称不符合信息 - PASS");
        
        // 删除section
        formPage.formNameInput().clear();
        formPage.formNameInput().sendKeys("empty|empty");
        Thread.sleep(1000);
        formPage.confirmBtn().click();
        formPage.confirmBtn().click();
        Thread.sleep(1000);
        list = formPage.sectionBtnList();
        list.get(0).click();
        Thread.sleep(1000);
        formPage.saveBtn().click();
        Thread.sleep(1000);
        formPage.closeBtn().click();
        Thread.sleep(1000);
        
        // Step3 - 验证删除section成功
        Log.info("Step3 - 验证删除section成功");
        formPage.editFormBtn(formUID).click();
        Thread.sleep(1000);
        list = formPage.sectionBtnList();
        Assert.assertEquals(list.size(), 1);
        formPage.closeBtn().click();
        Thread.sleep(1000);
        Log.info("验证删除section成功 - PASS");
        
        // Step4 - 删除表单
        Log.info("Step4 - 删除表单");
        formPage.deleteFormBtn(formUID).click();
        Thread.sleep(1000);
        
        Log.info("验证删除表单对话框");
        formPage.confirmBtn().click();
        Thread.sleep(1000);
        Log.info("直接点确定，验证错误提示信息");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.FORM_NAME_NOT_INPUT_ERR));
        Log.info("直接点确定，验证错误提示信息 - PASS");
        
        Log.info("验证输入名称不符合信息");
        formPage.formNameInput().sendKeys("empty");
        Thread.sleep(1000);
        formPage.confirmBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.FORM_NAME_NOT_SAME_ERR));
        Log.info("验证输入名称不符合信息 - PASS");
        
        // 删除表单
        formPage.formNameInput().clear();
        formPage.formNameInput().sendKeys(formUID);
        Thread.sleep(1000);
        formPage.confirmBtn().click();
        formPage.confirmBtn().click();
        Thread.sleep(1000);
        
        // Step3 - 验证删除表单成功
        Log.info("验证删除表单成功");
        Assert.assertEquals(formPage.getLinesOfFormTable().size(), 0);
        Log.info("验证删除表单成功 - PASS");
        
        Log.info("******************删除section和表单测试 END ******************");
    }
}