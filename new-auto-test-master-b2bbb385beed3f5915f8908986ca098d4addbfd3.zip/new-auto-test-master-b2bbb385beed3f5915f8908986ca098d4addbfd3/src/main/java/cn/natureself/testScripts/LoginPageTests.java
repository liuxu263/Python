package cn.natureself.testScripts;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.*;
import org.testng.Assert;

import cn.natureself.pageObjects.LoginPage;
import cn.natureself.pageObjects.MenuBar;
import cn.natureself.pageActions.LoginPageAction;
import cn.natureself.utils.*;

/**
 * 登录和注册测试类
 * 
 * @author Andy
 */
//@Listeners({TestNGListener.class})
public class LoginPageTests extends BasicTest {
    
    public WebDriver driver;
    public LoginPage loginPage;
    public MenuBar menuBar;
    
    // The logger for this test file
    public static Logger Log = LogManager.getLogger(LoginPageTests.class);
    
    public LoginPageTests() {
        super();
    }
    
    @Override
    public Logger getLogger() {
        return LoginPageTests.Log;
    }
    
    // test data
    public String department = "神经科";
    public String title = "主任医师";
    public String site = "协和医院";
    public String address = "北京市";
    
    @BeforeClass
    public void beforeClass() throws InterruptedException {
        Log.info("");
        Log.info("****************** 登录和注册页面测试 -- START ******************");
        Log.info("");
        
        driver = getDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        loginPage = new LoginPage(driver);
        menuBar = new MenuBar(driver);
        
        // Pre1 - 打开主页
        Log.info("Pre1 - 打开主页");
        driver.get(JsonConf.LoginSystemURL);
        Thread.sleep(5000);
        
        // 确认进入主页
        Log.info("Assertion - 确认是否进入主页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 进入主页 - PASS");
    }
    
    @AfterClass
    public void afterClass() {
        Log.info("");
        Log.info("****************** 登录和注册页面测试 -- END ******************");
        Log.info("");
        driver.quit();
    }
    
    /**
     * 正常注册和登录流程测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void normalSignupAndLoginTest() throws InterruptedException {
        
        Log.info("******************正常注册和登录流程测试 -- START ******************");
        
        // Step1 - 使用正确信息注册
        Log.info("Step1 - 使用正确信息注册一个用户");
        Log.info("生成一个随机用户名和密码");
        String email = commonUtils.getNumber(10) + "@qq.com";
        String password = commonUtils.get_symbol(5) + commonUtils.getNumber(5);
        String name = commonUtils.getOneName();
        String phone = commonUtils.getNumber(11);
        
        // 点击注册link
        Log.info("点击注册");
        loginPage.signUpLink().click();
        Thread.sleep(1000);
        
        // 确认页面跳转
        Log.info("Assertion - 确认是否进入注册页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.SIGNUP_TITLE));
        Log.info("Assertion - 进入注册页 - PASS");
        
        // 点已有账号直接登录link，测试能否转回登录页
        loginPage.signInLink().click();
        Thread.sleep(5000);
        Log.info("Assertion - 点已有账号直接登录link，确认页面是否回登录页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 点已有账号直接登录link，页面回登录页 - PASS");
        
        // 开始注册
        loginPage.signUpLink().click();
        Thread.sleep(1000);
        Log.info("开始注册");
        LoginPageAction.signUp(driver, email, password, name, phone, department, title, site, address);
        
        // 确认注册成功，页面回登录页
        Log.info("Assertion - 确认注册成功后页面是否回登录页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 注册成功，页面回登录页 - PASS");
        
        // 使用注册账号登录
        Log.info("Step2 - 使用注册账号登录");
        LoginPageAction.Login(driver, email, password);
        
        // 确认登录成功
        Log.info("Assertion - 确认登录是否成功");
        Assert.assertTrue(driver.getPageSource().contains("项目列表"));
        Log.info("Assertion - 登录成功 - PASS");
        
        // logout
        Log.info("Step3 - Logout");
        menuBar.logoutLink().click();
        Thread.sleep(2000);
        
        // 确认回到主页
        Log.info("Assertion - 确认是否回到主页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - Logout回到主页 - PASS");
        
        Log.info("******************正常注册和登录流程测试 -- END ******************");
    }
    
    /**
     * 忘记密码流程测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void forgetPasswordTest() throws InterruptedException {
        
        Log.info("******************忘记密码流程测试 -- START ******************");
        
        // 点忘记密码link
        Log.info("Step1 - 点击忘记密码");
        loginPage.forgetPwdLink().click();
        Thread.sleep(1000);
        
        // 确认页面跳转
        Log.info("Assertion - 确认是否进入忘记密码页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.FORGET_PWD_TITLE));
        Log.info("Assertion - 进入忘记密码页 - PASS");
        
        // 找回密码操作
        Log.info("Step2 - 找回密码操作");
        LoginPageAction.forgetPwd(driver, JsonConf.LoginAdminName);
        
        // 确认找回密码成功
        Log.info("Assertion - 确认是否发送邮件成功");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.SEND_MAIL_MESSAGE));
        Log.info("Assertion - 找回密码成功 - PASS");
        
        // 错误邮箱找回密码操作
        Log.info("Step3 - 错误邮箱找回密码操作");
        loginPage.emailInput().clear();
        LoginPageAction.forgetPwd(driver, "wrong-email");
        
        // 确认找回密码失败
        Log.info("Assertion - 确认是否找回密码失败");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.MAIL_NOT_EXIST_MESSAGE));
        Log.info("Assertion - 确认找回密码失败 - PASS");
        
        // 点击已经想起密码
        Log.info("Step4 - 点击已经想起密码");
        loginPage.rememberLink().click();
        Thread.sleep(1000);
        
        // 确认返回登录页
        Log.info("Assertion - 确认返回登录页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 返回登录页 - PASS");
        
        Log.info("******************忘记密码流程测试 -- END ******************");
    }
    
    /**
     * 注册信息验证测试
     * @author Andy
     * 
     * @throws InterruptedException
     */
    @Test
    public void signupInfoCheckTest() throws InterruptedException {
        
        Log.info("******************注册信息验证测试 -- START ******************");
        
        // Step1 - 使用错误信息注册
        Log.info("Step1 - 使用错误信息注册");
        String wrongemail = commonUtils.getNumber(10);
        String existemail = JsonConf.LoginAdminName;
        String password = commonUtils.get_symbol(5);
        String password2 = commonUtils.getNumber(6);
        String name = commonUtils.getOneName();
        String phone = commonUtils.get_symbol(5) + commonUtils.getNumber(5);
        String rightpassword = commonUtils.get_symbol(5) + commonUtils.getNumber(5);
        String rightphone = commonUtils.getNumber(11);
        
        // 点击注册link
        Log.info("点击注册");
        loginPage.signUpLink().click();
        Thread.sleep(1000);
        
        // 确认页面跳转
        Log.info("Assertion - 确认是否进入注册页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.SIGNUP_TITLE));
        Log.info("Assertion - 进入注册页 - PASS");
        
        // 输入错误信息
        Log.info("输入错误邮箱，密码和手机号");
        LoginPageAction.signUp(driver, wrongemail, password, name, phone, department, title, site, address);
        
        // 验证错误提示信息
        Log.info("Assertion - 验证邮箱格式错误提示信息");
        String path = ".//p[contains(text(), '" + UIStrings.MAIL_FORMAT_ERROR + "')]";
        WebElement element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("Assertion - 验证邮箱格式错误提示信息 - PASS");
        
        Log.info("Assertion - 验证密码格式错误提示信息");
        path = ".//p[contains(text(), '" + UIStrings.PWD_FORMAT_ERROR + "')]";
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("Assertion - 验证密码格式错误提示信息 - PASS");
        
        Log.info("Assertion - 验证手机号格式错误提示信息");
        path = ".//p[contains(text(), '" + UIStrings.SIGNUP_PHONE_FORMAT_ERROR + "')]";
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("Assertion - 验证手机号格式错误提示信息  - PASS");
        
        Log.info("Assertion - 验证密码不一致错误提示信息");
        loginPage.signUpPwdInput().clear();
        loginPage.signUpRePwdInput().clear();
        loginPage.signUpPwdInput().sendKeys(password2 + "aaa");
        loginPage.signUpRePwdInput().sendKeys(password2);
        loginPage.signUpNameInput().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.PWD_NOT_SAME_ERROR));
        Log.info("Assertion - 验证密码不一致错误提示信息  - PASS");
        
        Log.info("Assertion - 验证邮箱已存在错误提示信息");
        loginPage.signUpEmailInput().clear();
        loginPage.signUpPwdInput().clear();
        loginPage.signUpRePwdInput().clear();
        loginPage.signUpPhoneInput().clear();
        loginPage.signUpEmailInput().sendKeys(existemail);
        loginPage.signUpPwdInput().sendKeys(rightpassword);
        loginPage.signUpRePwdInput().sendKeys(rightpassword);
        loginPage.signUpPhoneInput().sendKeys(rightphone);
        loginPage.signUpBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.SIGNUP_USER_EXIST_ERROR));
        loginPage.cancelBtn().click();
        Thread.sleep(1000);
        Log.info("Assertion - 验证邮箱已存在错误提示信息  - PASS");
        
        // 返回登录页
        Log.info("Step2 - 返回登录页");
        loginPage.signInLink().click();
        Thread.sleep(5000);
        Log.info("Assertion - 确认返回登录页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 返回登录页 - PASS");
        
        Log.info("******************注册信息验证测试 -- END ******************");
    }
    
    /**
     * 登录失败测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void loginFailTest() throws InterruptedException {
        
        String wrongUserName = "test@test.com";
        String wrongPwd = "test";
        
        Log.info("******************登录失败测试 -- START ******************");
        
        // Step1 - 输入错误用户名和密码登录
        Log.info("Step1 - 输入错误用户名和密码登录");
        LoginPageAction.Login(driver, wrongUserName, wrongPwd);
        
        // 验证错误信息
        Log.info("Assertion - 验证用户名或密码错误信息");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.LOGIN_WRONG_USER));
        Log.info("Assertion - 验证用户名或密码错误信息 - PASS");
        loginPage.cancelBtn().click();
     
        Log.info("******************登录失败测试 -- END ******************");
    }
    
}