package cn.natureself.testScripts;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import cn.natureself.componentObjects.CaseInfo;
import cn.natureself.pageActions.CaseManagePageAction;
import cn.natureself.pageActions.LoginPageAction;
import cn.natureself.pageActions.MenuBarAction;
import cn.natureself.pageActions.ProjectListPageAction;
import cn.natureself.pageObjects.CaseManagePage;
import cn.natureself.pageObjects.MenuBar;
import cn.natureself.utils.JsonConf;
import cn.natureself.utils.UIStrings;
import cn.natureself.utils.commonUtils;

import org.testng.annotations.BeforeClass;

/**
 * 病例管理测试类
 * 
 * @author lx
 */
public class CaseManagePageTests extends BasicTest {
    WebDriver driver;
    CaseManagePage casePage;
    public MenuBar menuBar;

    // The logger for this test file
    public static Logger Log = LogManager.getLogger(CaseManagePageTests.class);
    
    public CaseManagePageTests() {
        super();
    }
    
    @Override
    public Logger getLogger() {
        return CaseManagePageTests.Log;
    }

    // test data
    public String centername1 = "中日友好医院";
    public String centername2 = "中国人民解放军第306医院";
    public String groupname1 = "分组1";
    public String groupname2 = "分组2";
    public String stage1 = "阶段1";
    public String stage2 = "阶段2";

    public CaseInfo case1 = new CaseInfo(centername1, groupname1);
    public CaseInfo case2 = new CaseInfo(centername1, groupname1);
    public CaseInfo case3 = new CaseInfo(centername1, groupname2);
    public CaseInfo case4 = new CaseInfo(centername1, groupname1);
    public CaseInfo case5 = new CaseInfo(centername1, groupname2);
    public CaseInfo case6 = new CaseInfo(centername1, groupname2);
    public CaseInfo case7 = new CaseInfo(centername2, groupname1);

    @BeforeClass
    public void NormalLoginAndChooseProject() throws InterruptedException {
        Log.info("");
        Log.info("******************病例管理页面测试 -- START ******************");
        Log.info("");
        
        driver = getDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        casePage = new CaseManagePage(driver);

        // 打开主页
        Log.info("打开主页");
        driver.get(JsonConf.LoginSystemURL);
        Thread.sleep(5000);

        // 确认进入主页
        Log.info("Assertion - 确认是否进入主页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 进入主页 - PASS");
        
        // 登录并进入病例管理页面
        LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord);
    }

    @AfterClass
    public void NormalQuit() {
        Log.info("");
        Log.info("******************病例管理页面测试 -- END ******************");
        Log.info("");
        driver.quit();
    }

    /**
     * 进行正确添加病例的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void NormalAddCaseTest() throws InterruptedException {

        Log.info("******************正常添加病例流程测试 -- START ******************");

        // 初始化测试数据
        initCaseInfo(case1);
        initCaseInfo(case2);
        initCaseInfo(case3);

        // add cases
        Log.info("Step1 - 添加病例1-身份证号码为18位");
        CaseManagePageAction.AddCase(driver, case1, "id18");

        Log.info("Step2 - 验证病例1添加结果");
        checkAddCaseResults(case1);
        Log.info("验证病例1添加结果 - PASS");

        Log.info("Step3 - 添加病例2-身份证号码为15位");
        CaseManagePageAction.AddCase(driver, case2, "id15");

        Log.info("Step4 - 验证病例2添加结果");
        checkAddCaseResults(case2);
        Log.info("验证病例2添加结果 - PASS");

        Log.info("Step5 - 添加病例3-身份证号码为17位+x");
        CaseManagePageAction.AddCase(driver, case3, "id17x");

        Log.info("Step6 - 验证病例3添加结果");
        checkAddCaseResults(case3);
        Log.info("验证病例3添加结果 - PASS");

        Log.info("Step7 - 录入员1登出");
        MenuBarAction.logout(driver);

        Log.info("Step8 - 同中心录入员3登录");
        LoginAndGotoPage(JsonConf.LoginInputterName3, JsonConf.LoginInputterPassWord3);

        // 初始化测试数据
        initCaseInfo(case4);
        initCaseInfo(case5);
        initCaseInfo(case6);

        Log.info("Step9 - 添加病例4-护照");
        CaseManagePageAction.AddCase(driver, case4, "passport");

        Log.info("Step10 - 验证病例4添加结果");
        checkAddCaseResults(case4);
        Log.info("验证病例4添加结果 - PASS");

        Log.info("Step11 - 添加病例5-军人证");
        CaseManagePageAction.AddCase(driver, case5, "army");

        Log.info("Step12 - 验证病例5添加结果");
        checkAddCaseResults(case5);
        Log.info("验证病例5添加结果 - PASS");
        
        Log.info("Step13 - 添加病例6-身份证号码为18位");
        CaseManagePageAction.AddCase(driver, case6, "id18");

        Log.info("Step14 - 验证病例6添加结果");
        checkAddCaseResults(case6);
        Log.info("验证病例6添加结果 - PASS");
        
        Log.info("Step15 - 录入员3登出");
        MenuBarAction.logout(driver);

        Log.info("Step16 - 不同中心录入员2登录");
        LoginAndGotoPage(JsonConf.LoginInputterName2, JsonConf.LoginInputterPassWord2);

        initCaseInfo(case7);
        Log.info("Step17 - 添加病例7-身份证号码为18位");
        CaseManagePageAction.AddCase(driver, case7, "id18");

        Log.info("Step18 - 验证病例7添加结果");
        checkAddCaseResults(case7);
        Log.info("验证病例7添加结果 - PASS");
        
        Log.info("所有病例添加成功");
        Log.info("******************正常添加病例流程测试 -- END ******************");
    }

    /**
     * 添加病例对话框对输入信息的检查
     * 
     * @throws InterruptedException
     */
    @Test
    public void AddCaseCheckTest() throws InterruptedException {

        Log.info("******************添加病例对话框对输入信息的检查 -- START ******************");

        Log.info("Step1 - 打开添加病历对话框");
        casePage.ActiveGroupBtn(groupname2).click();
        Thread.sleep(1000);
        casePage.AddCaseBtn().click();
        Thread.sleep(1000);

        Log.info("Step2 - 验证错误信息");
        Log.info("验证研究对象编号已存在提示");
        casePage.StudyObjectNumberInput().sendKeys(case1.getStudyNumber());
        casePage.NameInput().sendKeys(case1.getName());
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.STUDY_NUMBER_EXIST_ERR));
        Log.info("验证研究对象编号已存在提示 - PASS");

        Log.info("验证身份证号码格式错误提示 - 长度17");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(commonUtils.getNumber(17));
        String path = ".//p[contains(text(), '" + UIStrings.ID_NUMBER_FORMAT_ERR + "')]";
        WebElement element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证身份证号码格式错误提示 - 长度17 - PASS");

        Log.info("验证身份证号码格式错误提示 - 长度19");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(commonUtils.getNumber(19));
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证身份证号码格式错误提示 - 长度19 - PASS");

        Log.info("验证身份证号码格式错误提示 - 长度14");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(commonUtils.getNumber(14));
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证身份证号码格式错误提示 - 长度14 - PASS");

        Log.info("验证身份证号码格式错误提示 - 长度16");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(commonUtils.getNumber(16));
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证身份证号码格式错误提示 - 长度16 - PASS");
        
        Log.info("验证身份证号码格式错误提示 - 长度17+a");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(commonUtils.getNumber(17) + "a");
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证身份证号码格式错误提示 - 长度17+a - PASS");
        
        Log.info("验证身份证号码格式错误提示 - 长度16+xx");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(commonUtils.getNumber(16) + "xx");
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证身份证号码格式错误提示 - 长度16+xx - PASS");
        
        Log.info("验证身份证号码已存在错误提示");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(case1.getIDNumber());
        casePage.NameInput().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.ID_NUMBER_EXIST_ERR));
        Log.info("验证身份证号码已存在错误提示 - PASS");
        
        Log.info("验证护照号码格式错误提示");
        casePage.IDNumberInput().clear();
        casePage.IDTypeSelect().selectByVisibleText("护照");
        casePage.IDNumberInput().sendKeys("...");
        path = ".//p[contains(text(), '" + UIStrings.PASSPORT_NUMBER_FORMAT_ERR + "')]";
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证护照号码格式错误提示 - PASS");
        
        Log.info("验证护照号码已存在错误提示");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(case4.getIDNumber());
        casePage.NameInput().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.ID_NUMBER_EXIST_ERR));
        Log.info("验证护照号码已存在错误提示 - PASS");
        
        Log.info("验证军人证号码格式错误提示 - 北字第号");
        casePage.IDNumberInput().clear();
        casePage.IDTypeSelect().selectByVisibleText("军人证");
        casePage.IDNumberInput().sendKeys("北字第号");
        path = ".//p[contains(text(), '" + UIStrings.ARMYID_NUMBER_FORMAT_ERR + "')]";
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证军人证号码格式错误提示 - 北字第号 - PASS");
        
        Log.info("验证军人证号码格式错误提示 - 北字第1号");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys("北字第1号");
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证军人证号码格式错误提示 - 北字第1号 - PASS");
        
        Log.info("验证军人证号码格式错误提示 - 北字第111111111号");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys("北字第111111111号");
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证军人证号码格式错误提示 - 北字第111111111号 - PASS");
        
        Log.info("验证军人证号码格式错误提示 - 北字第a号");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys("北字第a号");
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证军人证号码格式错误提示 - 北字第a号 - PASS");
        
        Log.info("验证军人证号码格式错误提示 - 12345678");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys("12345678");
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证军人证号码格式错误提示 - 12345678 - PASS");
        
        Log.info("验证军人证号码格式错误提示 - 第12345678号");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys("第12345678号");
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证军人证号码格式错误提示 - 第12345678号 - PASS");
        
        Log.info("验证军人证号码格式错误提示 - 东字第12345678号");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys("东字第12345678号");
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证军人证号码格式错误提示 - 东字第12345678号 - PASS");
        
        Log.info("验证军人证号码已存在错误提示");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(case5.getIDNumber());
        casePage.NameInput().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.ID_NUMBER_EXIST_ERR));
        Log.info("验证军人证号码已存在错误提示 - PASS");
        
        casePage.AddEditCaseCancelBtn().click();
        Thread.sleep(1000);

        Log.info("******************添加病例对话框对输入信息的检查 -- END ******************");
    }
    
    /**
     * 编辑病例流程测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void EditCaseTest() throws InterruptedException {
        Log.info("******************编辑病例流程测试 -- START ******************");
        
        Log.info("Step1 - 录入员2登出");
        MenuBarAction.logout(driver);

        Log.info("Step2 - 录入员1登录");
        LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord);
        
        Log.info("Step3 - 点击病例1的编辑按钮");
        casePage.ActiveGroupBtn(case1.getGroupName()).click();
        Thread.sleep(1000);
        casePage.ChangeCaseBtn(case1.getStudyNumber()).click();
        Thread.sleep(1000);
        
        Log.info("Step4 - 检查对话框里的信息");
        Log.info("检查研究对象编号");
        Assert.assertEquals(casePage.StudyObjectNumberInput().getAttribute("value"), case1.getStudyNumber());
        Log.info("检查研究对象编号 - PASS");
        Log.info("检查姓名");
        Assert.assertEquals(casePage.NameInput().getAttribute("value"), case1.getName());
        Log.info("检查姓名 - PASS");
        Log.info("检查证件类型");
        Assert.assertEquals(casePage.IDTypeSelect().getFirstSelectedOption().getText(), case1.getIDType());
        Log.info("检查证件类型 - PASS");
        Log.info("检查证件号码");
        Assert.assertEquals(casePage.IDNumberInput().getAttribute("value").replaceAll(" ", ""), case1.getIDNumber());
        Log.info("检查证件号码 - PASS");
        Log.info("检查中心");
        Assert.assertEquals(casePage.CenterSelect().getFirstSelectedOption().getText(), case1.getCenterName());
        Log.info("检查中心 - PASS");
        Log.info("检查分组");
        Assert.assertEquals(casePage.GroupSelect().getFirstSelectedOption().getText(), case1.getGroupName());
        Log.info("检查分组 - PASS");
        Log.info("检查入组时间");
        String date = casePage.getDateInputInCaseDialog().getAttribute("value");
        String time = casePage.getTimeInputInCaseDialog().getAttribute("value");
        WebElement row = casePage.getLineOfCase(case1.getStudyNumber());
        List<WebElement> cols = row.findElements(By.tagName("td"));
        String[] enterTime = cols.get(5).getText().split(" ");
        Assert.assertEquals(date, enterTime[0]);
        Assert.assertEquals(time, enterTime[1]);
        Log.info("检查入组时间 - PASS");
        Log.info("Step4 - 检查对话框里的信息 - PASS");
        
        Log.info("Step5 - 编辑病例");
        casePage.AddEditCaseCancelBtn().click();
        CaseManagePageAction.EditCase(driver, case1, "passport");
        
        Log.info("Step6 - 点击返回修改按钮");
        casePage.BackToEditBtn().click();
        Thread.sleep(1000);
        Log.info("确认更改还在");
        Assert.assertEquals(casePage.StudyObjectNumberInput().getAttribute("value"), case1.getStudyNumber());
        Assert.assertEquals(casePage.NameInput().getAttribute("value"), case1.getName());
        Assert.assertEquals(casePage.IDTypeSelect().getFirstSelectedOption().getText(), case1.getIDType());
        Assert.assertEquals(casePage.IDNumberInput().getAttribute("value").replaceAll(" ", ""), case1.getIDNumber());
        Log.info("确认更改还在 - PASS");
        
        Log.info("Step7 - 输入更改原因确认更改");
        casePage.AddEditCaseConfirmBtn().click();
        Thread.sleep(1000);
        casePage.ChangeReasonTextArea().sendKeys("change ok");
        casePage.AddEditCaseConfirmBtn().click();
        Thread.sleep(1000);
        String msg = casePage.EditCaseSuccessMessage();
        Assert.assertTrue(msg.contains(case1.getName()));
        Assert.assertTrue(msg.contains("修改成功"));
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step8 - 检查编辑病例结果");
        row = casePage.getLineOfCase(case1.getStudyNumber());
        cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(0).getText(), case1.getName());
        Assert.assertEquals(cols.get(1).getText(), case1.getStudyNumber());
        Log.info("Step8 - 检查编辑病例结果 - PASS");
        
        Log.info("******************编辑病例流程测试 -- END ******************");
    }
    
    /**
     * 编辑病例对话框对输入信息的检查
     * 
     * @throws InterruptedException
     */
    @Test
    public void EditCaseCheckTest() throws InterruptedException {
        
        Log.info("******************编辑病例对话框对输入信息的检查 -- START ******************");
        
        Log.info("Step1 - 点击病例1的编辑按钮");
        casePage.ActiveGroupBtn(case1.getGroupName()).click();
        Thread.sleep(1000);
        casePage.ChangeCaseBtn(case1.getStudyNumber()).click();
        Thread.sleep(1000);
        
        Log.info("Step2 - 验证错误信息");
        Log.info("验证研究对象编号已存在提示");
        casePage.StudyObjectNumberInput().clear();
        casePage.StudyObjectNumberInput().sendKeys(case2.getStudyNumber());
        casePage.NameInput().clear();
        casePage.NameInput().sendKeys(case2.getName());
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.STUDY_NUMBER_EXIST_ERR));
        Log.info("验证研究对象编号已存在提示 - PASS");
        
        Log.info("验证身份证号码格式错误提示 - 长度17");
        casePage.IDTypeSelect().selectByVisibleText("身份证号码");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(commonUtils.getNumber(17));
        String path = ".//p[contains(text(), '" + UIStrings.ID_NUMBER_FORMAT_ERR + "')]";
        WebElement element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证身份证号码格式错误提示 - 长度17 - PASS");
        
        Log.info("验证身份证号码已存在错误提示");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(case2.getIDNumber());
        casePage.NameInput().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.ID_NUMBER_EXIST_ERR));
        Log.info("验证身份证号码已存在错误提示 - PASS");
        
        Log.info("验证护照号码格式错误提示");
        casePage.IDTypeSelect().selectByVisibleText("护照");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys("...");
        path = ".//p[contains(text(), '" + UIStrings.PASSPORT_NUMBER_FORMAT_ERR + "')]";
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证护照号码格式错误提示 - PASS");
        
        Log.info("验证护照号码已存在错误提示");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(case4.getIDNumber());
        casePage.NameInput().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.ID_NUMBER_EXIST_ERR));
        Log.info("验证护照号码已存在错误提示 - PASS");
        
        Log.info("验证军人证号码格式错误提示 - 北字第号");
        casePage.IDTypeSelect().selectByVisibleText("军人证");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys("北字第号");
        path = ".//p[contains(text(), '" + UIStrings.ARMYID_NUMBER_FORMAT_ERR + "')]";
        element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证军人证号码格式错误提示 - 北字第号 - PASS");
        
        Log.info("验证军人证号码已存在错误提示");
        casePage.IDNumberInput().clear();
        casePage.IDNumberInput().sendKeys(case5.getIDNumber());
        casePage.NameInput().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.ID_NUMBER_EXIST_ERR));
        Log.info("验证军人证号码已存在错误提示 - PASS");
        
        casePage.AddEditCaseCancelBtn().click();
        Thread.sleep(1000);
        
        Log.info("******************编辑病例对话框对输入信息的检查 -- END ******************");
    }
    
    /**
     * 病例过滤测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void FilterCaseTest() throws InterruptedException {
        Log.info("******************病例过滤测试 -- START ******************");
        
        Log.info("Step1 - 分组1，点我的病例");
        casePage.ActiveGroupBtn(case1.getGroupName()).click();
        Thread.sleep(1000);
        casePage.MyCaseRadio().click();
        Thread.sleep(1000);
        
        Log.info("Step2 - 检查过滤结果 - 2个病例，录入人为录入员1，中心为中日友好医院");
        List<WebElement> rows = casePage.getLinesOfCaseTable();
        Assert.assertEquals(rows.size(), 2);
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            Assert.assertEquals(cols.get(4).getText(), case1.getInputter());
            Assert.assertEquals(cols.get(3).getText(), case1.getCenterName());
        }
        Log.info("检查过滤结果 - PASS");
        
        Log.info("Step3 - 分组1，点所有病例");
        casePage.AllCaseRadio().click();
        Thread.sleep(1000);
        
        Log.info("Step4 - 检查过滤结果 - 3个病例，录入人为录入员1和录入员3");
        rows = casePage.getLinesOfCaseTable();
        Assert.assertEquals(rows.size(), 3);
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            Assert.assertTrue(cols.get(4).getText().equals(case1.getInputter()) || 
                    cols.get(4).getText().equals(case4.getInputter()));
            Assert.assertEquals(cols.get(3).getText(), case1.getCenterName());
        }
        Log.info("检查过滤结果 - PASS");
        
        Log.info("Step5 - 录入员1登出");
        MenuBarAction.logout(driver);

        Log.info("Step6 - 录入员2登录");
        LoginAndGotoPage(JsonConf.LoginInputterName2, JsonConf.LoginInputterPassWord2);
        
        Log.info("Step7 - 分组1，点我的病例");
        casePage.ActiveGroupBtn(case1.getGroupName()).click();
        Thread.sleep(1000);
        casePage.MyCaseRadio().click();
        Thread.sleep(1000);
        
        Log.info("Step8 - 检查过滤结果 - 1个病例，录入人为录入员2，中心为中国人民解放军第306医院");
        rows = casePage.getLinesOfCaseTable();
        Assert.assertEquals(rows.size(), 1);
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            Assert.assertEquals(cols.get(4).getText(), case7.getInputter());
            Assert.assertEquals(cols.get(3).getText(), case7.getCenterName());
        }
        Log.info("检查过滤结果 - PASS");
        
        Log.info("Step9 - 分组1，点所有病例");
        casePage.AllCaseRadio().click();
        Thread.sleep(1000);
        
        Log.info("Step10 - 检查过滤结果 - 1个病例，录入人为录入员2");
        rows = casePage.getLinesOfCaseTable();
        Assert.assertEquals(rows.size(), 1);
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            Assert.assertEquals(cols.get(4).getText(), case7.getInputter());
            Assert.assertEquals(cols.get(3).getText(), case7.getCenterName());
        }
        Log.info("检查过滤结果 - PASS");
        
        Log.info("******************病例过滤测试 -- END ******************");
    }
    
    /**
     * 搜索病例测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void SearchCaseTest() throws InterruptedException {
        Log.info("******************搜索病例测试 -- START ******************");
        
        Log.info("Step1 - 录入员2登出");
        MenuBarAction.logout(driver);

        Log.info("Step2 - 录入员1登录");
        LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord);
        
        Log.info("Step3 - 分组1，点所有病例");
        casePage.ActiveGroupBtn(case1.getGroupName()).click();
        Thread.sleep(1000);
        casePage.AllCaseRadio().click();
        Thread.sleep(1000);
        
        Log.info("Step4 - 按姓名搜索");
        CaseManagePageAction.SearchCase(driver, "name", case1.getName());
        
        Log.info("Step5 - 检查结果 - 1个病例");
        List<WebElement> rows = casePage.getLinesOfCaseTable();
        Assert.assertEquals(rows.size(), 1);
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            Assert.assertEquals(cols.get(0).getText(), case1.getName());
        }
        
        Log.info("Step6 - 按研究编号搜索");
        CaseManagePageAction.SearchCase(driver, "id", case1.getStudyNumber());
        
        Log.info("Step7 - 检查结果 - 1个病例");
        rows = casePage.getLinesOfCaseTable();
        Assert.assertEquals(rows.size(), 1);
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            Assert.assertEquals(cols.get(1).getText(), case1.getStudyNumber());
        }
        
        Log.info("Step8 - 按状态搜索");
        CaseManagePageAction.SearchCase(driver, "status", case1.getStatus());
        
        Log.info("Step9 - 检查结果 - 3个病例");
        rows = casePage.getLinesOfCaseTable();
        Assert.assertEquals(rows.size(), 3);
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            Assert.assertEquals(cols.get(2).getText(), case1.getStatus());
        }
        
        Log.info("Step10 - 按不存在状态搜索");
        CaseManagePageAction.SearchCase(driver, "status", UIStrings.CASE_STATUS_COMPLETE);
        
        Log.info("Step11 - 检查结果 - 0个病例");
        rows = casePage.getLinesOfCaseTable();
        Assert.assertEquals(rows.size(), 0);
        
        Log.info("Step12 - 3种组合搜索");
        CaseManagePageAction.SearchCase(driver, case1.getName(), case1.getStudyNumber(), case1.getStatus());
        
        Log.info("Step13 - 检查结果 - 1个病例");
        rows = casePage.getLinesOfCaseTable();
        Assert.assertEquals(rows.size(), 1);
        for (WebElement row:rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            Assert.assertEquals(cols.get(0).getText(), case1.getName());
            Assert.assertEquals(cols.get(1).getText(), case1.getStudyNumber());
            Assert.assertEquals(cols.get(2).getText(), case1.getStatus());
        }
        
        // 恢复列表
        CaseManagePageAction.SearchCase(driver, "status", case1.getStatus());
        
        Log.info("******************搜索病例测试 -- END ******************");
    }
    
    /**
     * 删除病例测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void DeleteCaseTest() throws InterruptedException {
        Log.info("******************删除病例测试 -- START ******************");
        
        Log.info("Step1 - 点击删除病例1按钮");
        casePage.ActiveGroupBtn(case1.getGroupName()).click();
        Thread.sleep(1000);
        casePage.AllCaseRadio().click();
        Thread.sleep(1000);
        casePage.DeleteCaseBtn(case1.getStudyNumber()).click();
        Thread.sleep(1000);
        
        Log.info("Step2 - 检查删除对话框中的病例姓名");
        Assert.assertEquals(casePage.getCaseNameInDeleteCaseDialog(), case1.getName());
        Log.info("检查删除对话框中的病例姓名 - PASS");
        
        Log.info("Step3 - 删除病例，选择病例信息输入错误");
        casePage.DeleteCaseReasonInputErrorCheckbox().click();
        Thread.sleep(1000);
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step4 - 确认删除");
        Assert.assertNull(casePage.getLineOfCase(case1.getStudyNumber()));
        Log.info("确认删除 - PASS");
        
        Log.info("Step5 - 删除病例2，选择其它");
        CaseManagePageAction.DeleteCase(driver, case2.getStudyNumber(), "other");
        
        Log.info("Step6 - 确认删除");
        Assert.assertNull(casePage.getLineOfCase(case2.getStudyNumber()));
        Log.info("确认删除 - PASS");
        
        Log.info("Step7 - 删除所有病例");
        CaseManagePageAction.DeleteCase(driver, case4.getStudyNumber(), "inputerror");
        
        casePage.ActiveGroupBtn(case3.getGroupName()).click();
        Thread.sleep(1000);
        casePage.AllCaseRadio().click();
        Thread.sleep(1000);
        CaseManagePageAction.DeleteCase(driver, case3.getStudyNumber(), "inputerror");
        CaseManagePageAction.DeleteCase(driver, case5.getStudyNumber(), "inputerror");
        CaseManagePageAction.DeleteCase(driver, case6.getStudyNumber(), "inputerror");
        
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginInputterName2, JsonConf.LoginInputterPassWord2);
        casePage.ActiveGroupBtn(case7.getGroupName()).click();
        Thread.sleep(1000);
        casePage.AllCaseRadio().click();
        Thread.sleep(1000);
        CaseManagePageAction.DeleteCase(driver, case7.getStudyNumber(), "inputerror");
        
        Log.info("******************删除病例测试 -- END ******************");
    }
    
    /**
     * 登录并进入病例管理页面
     * @param user - user name
     * @param pwd - password
     * @throws InterruptedException
     */
    public void LoginAndGotoPage(String user, String pwd) throws InterruptedException {
        // 用户登陆
        Log.info("用户登陆");
        LoginPageAction.Login(driver, user, pwd);

        // 进入项目
        Log.info("选择病例管理自动化测试项目");
        ProjectListPageAction.enterProject(driver, "病例管理自动化测试项目");

        // 进入病例管理界面
        Log.info("进入病例管理界面");
        menuBar = new MenuBar(driver);
        menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);

        // 验证进入病例管理页面
        Log.info("验证进入病例管理页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("cases"));
        Log.info("验证进入病例管理页面 - PASS");
    }

    /**
     * 设置病例信息测试数据
     * 
     * @param caseInfo - CaseInfo object
     */
    public void initCaseInfo(CaseInfo caseInfo) {
        caseInfo.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        caseInfo.setInputter(menuBar.getUserName());
        caseInfo.addStageStatus(stage1, UIStrings.STAGE_STATUS_NEW);
        caseInfo.addStageStatus(stage2, UIStrings.STAGE_STATUS_NEW);
    }

    /**
     * 检查添加病例结果
     * 
     * @param caseInfo - CaseInfo object
     * @throws InterruptedException
     */
    public void checkAddCaseResults(CaseInfo caseInfo) throws InterruptedException {
        Log.info("验证添加成功信息");
        String successMsg = casePage.AddCaseSuccessMessage();
        String groupMsg = casePage.AddCaseSuccessGroupMessage();
        Assert.assertTrue(successMsg.contains(caseInfo.getName()));
        Assert.assertTrue(successMsg.contains("入组成功"));
        Assert.assertTrue(groupMsg.contains(caseInfo.getGroupName()));
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        Log.info("验证添加成功信息 - PASS");

        Log.info("验证表格信息");
        casePage.ActiveGroupBtn(caseInfo.getGroupName()).click();
        Thread.sleep(1000);

        WebElement row = casePage.getLineOfCase(caseInfo.getStudyNumber());
        String statusOfStage1 = casePage.getStageStatusOfCase(caseInfo.getStudyNumber(), stage1);
        String statusOfStage2 = casePage.getStageStatusOfCase(caseInfo.getStudyNumber(), stage2);
        List<WebElement> cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(0).getText(), caseInfo.getName());
        Assert.assertEquals(cols.get(1).getText(), caseInfo.getStudyNumber());
        Assert.assertEquals(cols.get(2).getText(), caseInfo.getStatus());
        Assert.assertEquals(cols.get(3).getText(), caseInfo.getCenterName());
        Assert.assertEquals(cols.get(4).getText(), caseInfo.getInputter());
        Assert.assertEquals(cols.get(5).getText(), caseInfo.getEnterTime());
        Assert.assertEquals(statusOfStage1, caseInfo.getStatusOfStage(stage1));
        Assert.assertEquals(statusOfStage2, caseInfo.getStatusOfStage(stage2));
        Log.info("验证表格信息 - PASS");
    }
}