package cn.natureself.testScripts;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import cn.natureself.componentObjects.CaseInfo;
import cn.natureself.pageActions.CaseManagePageAction;
import cn.natureself.pageActions.LoginPageAction;
import cn.natureself.pageActions.MenuBarAction;
import cn.natureself.pageActions.ProjectListPageAction;
import cn.natureself.pageActions.SiteManagePageAction;
import cn.natureself.pageObjects.CaseManagePage;
import cn.natureself.pageObjects.MenuBar;
import cn.natureself.utils.GetProxyIp;
import cn.natureself.utils.JsonConf;
import cn.natureself.utils.UIStrings;

/**
 * 随机化项目病例管理测试类
 * 
 * @author Andy
 */
public class RandomProjectCaseManageTests extends BasicTest {
    public WebDriver driver;
    CaseManagePage casePage;
    public MenuBar menuBar;
    public String hostname;
    
    // The logger for this test file
    public static Logger Log = LogManager.getLogger(RandomProjectCaseManageTests.class);
    
    public RandomProjectCaseManageTests() {
        super("WIN10");
    }
    
    @Override
    public Logger getLogger() {
        return RandomProjectCaseManageTests.Log;
    }
    
    // test data
    public String groupname1 = "分组1";
    public String groupname2 = "分组2";
    public String stage1 = "阶段1";
    public String stage2 = "阶段2";
    public String randomCenter = "北京大学医院";
    public String[][] randomFormData = {{"00019", "分组1"}, {"00047", "分组2"}}; 
    public CaseInfo randomCase1 = new CaseInfo(randomCenter);
    public CaseInfo randomCase2 = new CaseInfo(randomCenter);
    public CaseInfo randomCase3 = new CaseInfo(randomCenter);
    
    @BeforeClass
    public void NormalLoginAndChooseProject() throws InterruptedException, UnknownHostException {
        Log.info("");
        Log.info("******************随机化项目病例管理测试 -- START ******************");
        Log.info("");
        
        driver = getDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        casePage = new CaseManagePage(driver);
        
        // get hostname
        hostname = GetProxyIp.getip((RemoteWebDriver)driver);

        // 打开主页
        Log.info("打开主页");
        driver.get(JsonConf.LoginSystemURL);
        Thread.sleep(5000);

        // 确认进入主页
        Log.info("Assertion - 确认是否进入主页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 进入主页 - PASS");
    }

    @AfterClass
    public void NormalQuit() {
        Log.info("");
        Log.info("******************随机化项目病例管理测试 -- END ******************");
        Log.info("");
        driver.quit();
    }
    
    /**
     * 设置随机化项目病例信息测试数据
     * 
     * @param caseInfo - CaseInfo object
     * @param data - 随机表数据
     */
    public void initRandomCaseInfo(CaseInfo caseInfo, String[] data) {
        caseInfo.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
        caseInfo.setInputter(menuBar.getUserName());
        caseInfo.addStageStatus(stage1, UIStrings.STAGE_STATUS_NEW);
        caseInfo.addStageStatus(stage2, UIStrings.STAGE_STATUS_NEW);
        caseInfo.setRandomNumber(data[0]);
        caseInfo.setGroupName(data[1]);
    }
    
    /**
     * 检查随机化项目添加病例结果
     * 
     * @param caseInfo - CaseInfo object
     * @throws InterruptedException
     */
    public void checkRandomAddCaseResults(CaseInfo caseInfo) throws InterruptedException {
        Log.info("验证添加成功信息");
        String successMsg = casePage.AddCaseSuccessMessage();
        String groupname = casePage.RandomAddCaseGroupName();
        Assert.assertTrue(successMsg.contains(caseInfo.getName()));
        Assert.assertTrue(successMsg.contains("入组成功"));
        Assert.assertTrue(groupname.equals(caseInfo.getGroupName()));
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
        Log.info("验证添加成功信息 - PASS");

        Log.info("验证表格信息");
        casePage.ActiveGroupBtn(caseInfo.getGroupName()).click();
        Thread.sleep(1000);

        WebElement row = casePage.getLineOfCase(caseInfo.getStudyNumber());
        String statusOfStage1 = casePage.getStageStatusOfCase(caseInfo.getStudyNumber(), stage1);
        String statusOfStage2 = casePage.getStageStatusOfCase(caseInfo.getStudyNumber(), stage2);
        List<WebElement> cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(0).getText(), caseInfo.getName());
        Assert.assertEquals(cols.get(2).getText(), caseInfo.getStudyNumber());
        Assert.assertEquals(cols.get(3).getText(), caseInfo.getStatus());
        Assert.assertEquals(cols.get(4).getText(), caseInfo.getCenterName());
        Assert.assertEquals(cols.get(5).getText(), caseInfo.getInputter());
        Assert.assertEquals(cols.get(6).getText(), caseInfo.getEnterTime());
        Assert.assertEquals(statusOfStage1, caseInfo.getStatusOfStage(stage1));
        Assert.assertEquals(statusOfStage2, caseInfo.getStatusOfStage(stage2));
        Log.info("验证表格信息 - PASS");
    }
    
    /**
     * 随机化项目添加病例测试
     * 
     * @throws IOException
     * @throws InterruptedException
     */
    @Test
    public void RandomAddCaseTest() throws IOException, InterruptedException {
        Log.info("******************随机化项目添加病例测试 -- START ******************");
        
        Log.info("Step1 - 管理员登录");
        LoginPageAction.Login(driver, JsonConf.LoginAdminName, JsonConf.LoginAdminPassWord);
        
        Log.info("Step2 - 进入随机化项目");
        ProjectListPageAction.enterProject(driver, "随机化病例管理自动化测试项目");
        
        Log.info("Step3 - 进入机构管理界面");
        menuBar = new MenuBar(driver);
        menuBar.getMenuItem(UIStrings.MENU_SITE_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("Step4 - 上传随机表");
        SiteManagePageAction.uploadRandomForm(driver, hostname, randomCase1.getCenterName());
        
        Log.info("Step5 - 录入员登录");
        MenuBarAction.logout(driver);
        LoginPageAction.Login(driver, JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord);
        
        Log.info("Step6 - 进入随机化项目");
        ProjectListPageAction.enterProject(driver, "随机化病例管理自动化测试项目");
        
        Log.info("Step7 - 进入病例管理界面");
        menuBar = new MenuBar(driver);
        menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
        Thread.sleep(2000);
        
        Log.info("Step8 - 添加病例1");
        initRandomCaseInfo(randomCase1, randomFormData[0]);
        CaseManagePageAction.AddCase(driver, randomCase1, "id18");
        
        Log.info("Step9 - 验证病例1添加结果");
        checkRandomAddCaseResults(randomCase1);
        Log.info("验证病例1添加结果 - PASS");
        
        Log.info("Step10 - 添加病例2");
        initRandomCaseInfo(randomCase2, randomFormData[1]);
        CaseManagePageAction.AddCase(driver, randomCase2, "id18");
        
        Log.info("Step11 - 验证病例2添加结果");
        checkRandomAddCaseResults(randomCase2);
        Log.info("验证病例2添加结果 - PASS");
        
        Log.info("Step12 - 确认病例已达目标数");
        CaseManagePageAction.AddCase(driver, randomCase3, "id18");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.CASE_REACH_TARGET));
        casePage.CancelBtn().click();
        Thread.sleep(1000);

        Log.info("Step13 - 删除病例1");
        casePage.ActiveGroupBtn(randomCase1.getGroupName()).click();
        Thread.sleep(1000);
        CaseManagePageAction.DeleteCase(driver, randomCase1.getStudyNumber(), "inputerror");
        
        Log.info("Step14 - 确认删除");
        Assert.assertNull(casePage.getLineOfCase(randomCase1.getStudyNumber()));
        Log.info("确认删除 - PASS");
        
        Log.info("Step15 - 删除病例2");
        casePage.ActiveGroupBtn(randomCase2.getGroupName()).click();
        Thread.sleep(1000);
        CaseManagePageAction.DeleteCase(driver, randomCase2.getStudyNumber(), "inputerror");
        
        Log.info("Step16 - 确认删除");
        Assert.assertNull(casePage.getLineOfCase(randomCase2.getStudyNumber()));
        Log.info("确认删除 - PASS");
        
        Log.info("******************随机化项目添加病例测试 -- END ******************");
    }
}