package cn.natureself.testScripts;

import cn.natureself.pageObjects.GroupManagePage;
import cn.natureself.pageObjects.MenuBar;

import java.util.concurrent.TimeUnit;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import cn.natureself.pageActions.GroupManagePageAction;
import cn.natureself.pageActions.LoginPageAction;
import cn.natureself.pageActions.ProjectListPageAction;
import cn.natureself.utils.*;

/**
 * 分组和阶段管理测试类
 * 
 * @author Andy
 */
public class GroupManagePageTests extends BasicTest {
    public WebDriver driver;
    public GroupManagePage groupPage;
    public MenuBar menuBar;
    
    // The logger for this test file
    public static Logger Log = LogManager.getLogger(GroupManagePageTests.class);
    
    public GroupManagePageTests() {
        super();
    }
    
    @Override
    public Logger getLogger() {
        return GroupManagePageTests.Log;
    }
    
    // test data
    public String groupName1 = "Group1";
    public String groupUid1 = "id1";
    public String groupName2 = "Group2";
    public String groupUid2 = "id2";
    public String stageName1 = "Stage1";
    public String stageUid1 = "id1";
    public String stageName2 = "Stage2";
    public String stageUid2 = "id2";
    public String stageName3 = "Stage3";
    public String stageUid3 = "id3";
    public String stageName4 = "Stage4";
    public String stageUid4 = "id4";
    
    @BeforeClass
    public void beforeClass() throws InterruptedException {
        Log.info("");
        Log.info("******************分组和阶段管理页面测试 -- START ******************");
        Log.info("");
        
        driver = getDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        groupPage = new GroupManagePage(driver);
        
        // Pre1 - 打开主页
        Log.info("Pre1 - 打开主页");
        driver.get(JsonConf.LoginSystemURL);
        Thread.sleep(5000);
        
        // 确认进入主页
        Log.info("Assertion - 确认是否进入主页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 进入主页 - PASS");
        
        // Pre2 - 项目管理员登录
        Log.info("Pre2 - 项目管理员登录");
        LoginPageAction.Login(driver, JsonConf.LoginAdminName, JsonConf.LoginAdminPassWord);
        
        // Pre3 - 进入项目
        Log.info("Pre3 - 进入项目");
        ProjectListPageAction.enterProject(driver, "分组和阶段管理自动化测试项目");
        
        // Pre4 - 进入分组和阶段管理页面
        Log.info("Pre4 - 进入分组和阶段管理页面");
        menuBar = new MenuBar(driver);
        menuBar.getMenuItem(UIStrings.MENU_GROUP_MANAGE).click();
        Thread.sleep(2000);
        
        // Pre5 - 验证进入分组和阶段管理页面
        Log.info("Pre5 - 验证进入分组和阶段管理页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("groupevents"));
        Log.info("验证进入分组和阶段管理页面 - PASS");
    }
    
    @AfterClass
    public void afterClass() {
        Log.info("");
        Log.info("******************分组和阶段管理页面测试 -- END ******************");
        Log.info("");
        driver.quit();
    }
    
    /**
     * 正常添加分组流程测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void normalAddGroupTest() throws InterruptedException {
        Log.info("******************正常添加分组流程测试 -- START ******************");
        
        // Step1 - 添加分组
        Log.info("Step1 - 添加分组");
        GroupManagePageAction.AddGroup(driver, groupName1, groupUid1);
        GroupManagePageAction.AddGroup(driver, groupName2, groupUid2);
        
        // Step2 - 验证添加成功
        Log.info("Step2 - 验证添加成功");
        List<WebElement> list = groupPage.getGroups();
        Assert.assertEquals(list.size(), 2);
        Assert.assertTrue(list.get(0).getText().contains(groupName1));
        Assert.assertTrue(list.get(1).getText().contains(groupName2));
        Log.info("验证添加成功 - PASS");
        
        Log.info("******************正常添加分组流程测试 -- END ******************");
    }
    
    /**
     * 正常添加阶段流程测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void normalAddStageTest() throws InterruptedException {
        Log.info("******************正常添加阶段流程测试 -- START ******************");
        
        // Step1 - 添加阶段
        Log.info("Step1 - 添加阶段");
        GroupManagePageAction.AddStage(driver, groupName1, stageName1, stageUid1);
        GroupManagePageAction.AddStage(driver, groupName1, stageName2, stageUid2);
        GroupManagePageAction.AddStage(driver, groupName2, stageName3, stageUid3);
        GroupManagePageAction.AddStage(driver, groupName2, stageName4, stageUid4);
        
        // Step2 - 验证添加成功
        Log.info("Step2 - 验证添加成功");
        groupPage.ActiveGroupBtn(groupName1).click();
        Thread.sleep(1000);
        List<WebElement> headList = groupPage.getHeadsFromTable();
        List<WebElement> checkboxList = groupPage.AssignFormCheckboxInput();
        Log.info(groupName1 + "验证列表中阶段名称的显示");
        Assert.assertEquals(headList.size(), 3);
        Assert.assertEquals(headList.get(1).getText(), stageName1);
        Assert.assertEquals(headList.get(2).getText(), stageName2);
        Log.info(groupName1 + "验证checkbox个数和未选状态");
        Assert.assertEquals(checkboxList.size(), 4);
        for (WebElement box:checkboxList) {
            Assert.assertTrue(box.getAttribute("class").contains("ng-empty"));
        }
        
        Log.info(groupName2 + "验证列表中阶段名称的显示");
        groupPage.ActiveGroupBtn(groupName2).click();
        Thread.sleep(1000);
        headList = groupPage.getHeadsFromTable();
        checkboxList = groupPage.AssignFormCheckboxInput();
        Assert.assertEquals(headList.size(), 3);
        Assert.assertEquals(headList.get(1).getText(), stageName3);
        Assert.assertEquals(headList.get(2).getText(), stageName4);
        Log.info(groupName2 + "验证checkbox个数和未选状态");
        Assert.assertEquals(checkboxList.size(), 4);
        for (WebElement box:checkboxList) {
            Assert.assertTrue(box.getAttribute("class").contains("ng-empty"));
        }
        Log.info("验证添加成功 - PASS");
        
        Log.info("******************正常添加阶段流程测试 -- END ******************");
    }
    
    /**
     * 给阶段分配表单流程测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void selectFormForStageTest() throws InterruptedException {
        Log.info("******************给阶段分配表单流程测试 -- START ******************");
        
        // Step1 - 选择checkbox
        Log.info("Step1 - 选择checkbox, 但不保存");
        groupPage.ActiveGroupBtn(groupName1).click();
        Thread.sleep(1000);
        List<WebElement> checkboxList = groupPage.AssignFormCheckbox();
        checkboxList.get(0).click();
        Thread.sleep(1000);
        checkboxList.get(1).click();
        Thread.sleep(1000);
        checkboxList.get(2).click();
        Thread.sleep(1000);
        checkboxList.get(3).click();
        Thread.sleep(1000);
        
        // Step2 - 验证未保存
        Log.info("Step2 - 验证未保存");
        groupPage.ActiveGroupBtn(groupName2).click();
        Thread.sleep(1000);
        groupPage.ActiveGroupBtn(groupName1).click();
        Thread.sleep(1000);
        checkboxList = groupPage.AssignFormCheckboxInput();
        for (WebElement box:checkboxList) {
            Assert.assertTrue(box.getAttribute("class").contains("ng-empty"));
        }
        Log.info("验证未保存 - PASS");
        
        // Step3 - 选择checkbox并保存
        Log.info("Step3 - 选择checkbox并保存");
        groupPage.ActiveGroupBtn(groupName1).click();
        Thread.sleep(1000);
        checkboxList = groupPage.AssignFormCheckbox();
        checkboxList.get(0).click();
        Thread.sleep(1000);
        checkboxList.get(3).click();
        Thread.sleep(1000);
        groupPage.SaveStageBtn().click();
        Thread.sleep(1000);
        
        groupPage.ActiveGroupBtn(groupName2).click();
        Thread.sleep(1000);
        checkboxList = groupPage.AssignFormCheckbox();
        checkboxList.get(1).click();
        Thread.sleep(1000);
        checkboxList.get(2).click();
        Thread.sleep(1000);
        groupPage.SaveStageBtn().click();
        Thread.sleep(1000);
        
        // Step4 - 验证保存
        Log.info("Step4 - 验证保存成功");
        menuBar.getMenuItem("机构设置").click();
        Thread.sleep(2000);
        menuBar.getMenuItem("分组和阶段管理").click();
        Thread.sleep(2000);
        groupPage.ActiveGroupBtn(groupName1).click();
        Thread.sleep(1000);
        checkboxList = groupPage.AssignFormCheckboxInput();
        Assert.assertTrue(checkboxList.get(0).getAttribute("class").contains("ng-not-empty"));
        Assert.assertTrue(checkboxList.get(1).getAttribute("class").contains("ng-empty"));
        Assert.assertTrue(checkboxList.get(2).getAttribute("class").contains("ng-empty"));
        Assert.assertTrue(checkboxList.get(3).getAttribute("class").contains("ng-not-empty"));
        groupPage.ActiveGroupBtn(groupName2).click();
        Thread.sleep(1000);
        checkboxList = groupPage.AssignFormCheckboxInput();
        Assert.assertTrue(checkboxList.get(0).getAttribute("class").contains("ng-empty"));
        Assert.assertTrue(checkboxList.get(1).getAttribute("class").contains("ng-not-empty"));
        Assert.assertTrue(checkboxList.get(2).getAttribute("class").contains("ng-not-empty"));
        Assert.assertTrue(checkboxList.get(3).getAttribute("class").contains("ng-empty"));
        Log.info("验证保存成功 - PASS");
        
        Log.info("******************给阶段分配表单流程测试 -- END ******************");
    }
    
    /**
     * 添加分组和阶段错误信息测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void addGroupStageCheckTest() throws InterruptedException {
        Log.info("******************添加分组和阶段错误信息测试 -- START ******************");
        
        // Step1 - 添加分组输入错误信息
        Log.info("Step1 - 添加分组输入错误信息");
        GroupManagePageAction.AddGroup(driver, "group3", "...");
        
        // Step2 - 验证错误信息
        Log.info("Step2 - 验证错误信息");
        Log.info("验证分组uid格式错误");
        String path = ".//p[contains(text(), '" + UIStrings.GROUP_UID_FORMAT_ERR + "')]";
        WebElement form = driver.findElement(By.xpath(".//ng-form[@name='addGroupForm']"));
        WebElement element = form.findElement(By.xpath(path));
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.GROUP_UID_FORMAT_ERR));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证分组uid格式错误 - PASS");
        
        Log.info("验证分组uid已存在错误");
        groupPage.CancelBtn().click();
        Thread.sleep(1000);
        GroupManagePageAction.AddGroup(driver, "group3", groupUid1);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.GROUP_UID_EXIST_ERR));
        groupPage.CancelBtn().click();
        Thread.sleep(1000);
        Log.info("验证分组uid已存在错误 - PASS");
        
        // Step3 - 添加阶段输入错误信息
        Log.info("Step3 - 添加阶段输入错误信息");
        groupPage.ActiveGroupBtn(groupName1).click();
        Thread.sleep(1000);
        groupPage.SetStageBtn().click();
        Thread.sleep(1000);
        groupPage.StageNameInput().sendKeys("stage3");
        Thread.sleep(1000);
        groupPage.StageNumberInput().sendKeys("...");
        Thread.sleep(1000);
        
        // Step4 - 验证错误信息
        Log.info("Step4 - 验证错误信息");
        Log.info("验证阶段uid格式错误");
        path = ".//p[contains(text(), '" + UIStrings.STAGE_UID_FORMAT_ERR + "')]";
        form = driver.findElement(By.xpath(".//ng-form[@name='addEventForm']"));
        element = form.findElement(By.xpath(path));
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.STAGE_UID_FORMAT_ERR));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证阶段uid格式错误 - PASS");
        
        Log.info("验证阶段uid已存在错误");
        groupPage.StageNumberInput().clear();
        groupPage.StageNumberInput().sendKeys(stageUid1);
        groupPage.AddStageBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.STAGE_UID_EXIST_ERR));
        groupPage.CancelBtn().click();
        Thread.sleep(1000);
        groupPage.AddStageConfirmBtn().click();
        Thread.sleep(1000);
        Log.info("验证阶段uid已存在错误 - PASS");
        
        Log.info("******************添加分组和阶段错误信息测试 -- END ******************");
    }
    
    /**
     * 删除阶段测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void deleteStageTest() throws InterruptedException {
        Log.info("******************删除阶段测试 -- START ******************");
        
        // Step1 - 点击删除按钮
        Log.info("Step1 - 点击删除按钮");
        groupPage.ActiveGroupBtn(groupName1).click();
        Thread.sleep(1000);
        groupPage.SetStageBtn().click();
        Thread.sleep(1000);
        groupPage.DeleteStageBtn(stageName1).click();
        Thread.sleep(1000);
        
        // Step2 - 验证错误信息
        Log.info("Step2 - 验证错误信息");
        Log.info("直接点确定，验证请输入要删除的阶段名称");
        groupPage.ConfirmBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.STAGE_NAME_NOT_INPUT_ERR));
        Log.info("直接点确定，验证请输入要删除的阶段名称 - PASS");
        
        Log.info("验证输入名称不符合信息");
        groupPage.inputInDeleteDialog().sendKeys(stageName2);
        groupPage.ConfirmBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.STAGE_NAME_NOT_SAME_ERR));
        Log.info("验证输入名称不符合信息 - PASS");
        
        // Step3 - 删除所有阶段
        Log.info("Step3 - 删除所有阶段");
        groupPage.CancelBtn().click();
        Thread.sleep(1000);
        groupPage.AddStageConfirmBtn().click();
        Thread.sleep(1000);
        GroupManagePageAction.deleteStage(driver, groupName1, stageName1);
        GroupManagePageAction.deleteStage(driver, groupName1, stageName2);
        groupPage.ActiveGroupBtn(groupName2).click();
        Thread.sleep(1000);
        GroupManagePageAction.deleteStage(driver, groupName2, stageName3);
        GroupManagePageAction.deleteStage(driver, groupName2, stageName4);
        
        //Step4 - 验证删除成功
        Log.info("Step4 - 验证删除成功");
        groupPage.ActiveGroupBtn(groupName1).click();
        Thread.sleep(1000);
        Assert.assertEquals(groupPage.getHeadsFromTable().size(), 1);
        Assert.assertEquals(groupPage.AssignFormCheckbox().size(), 0);
        groupPage.ActiveGroupBtn(groupName2).click();
        Thread.sleep(1000);
        Assert.assertEquals(groupPage.getHeadsFromTable().size(), 1);
        Assert.assertEquals(groupPage.AssignFormCheckbox().size(), 0);
        Log.info("删除所有阶段 - PASS");
        
        Log.info("******************删除阶段测试 -- END ******************");
    }
    
    /**
     * 删除分组测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void deleteGroupTest() throws InterruptedException {
        Log.info("******************删除分组测试 -- START ******************");
        
        // Step1 - 点击删除按钮
        Log.info("Step1 - 点击删除按钮");
        groupPage.ActiveGroupBtn(groupName1).click();
        Thread.sleep(1000);
        groupPage.DeleteGroupBtn(groupName1).click();
        Thread.sleep(1000);
        
        // Step2 - 验证错误信息
        Log.info("Step2 - 验证错误信息");
        Log.info("直接点确定，验证请输入要删除的分组名称");
        groupPage.ConfirmBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.GROUP_NAME_NOT_INPUT_ERR));
        Log.info("直接点确定，验证请输入要删除的分组名称 - PASS");
        
        Log.info("验证输入名称不符合信息");
        groupPage.inputInDeleteDialog().sendKeys(groupName2);
        groupPage.ConfirmBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.GROUP_NAME_NOT_SAME_ERR));
        Log.info("验证输入名称不符合信息 - PASS");
        
        // Step3 - 删除所有分组
        Log.info("Step3 - 删除所有分组");
        groupPage.CancelBtn().click();
        Thread.sleep(1000);
        GroupManagePageAction.deleteGroup(driver, groupName1);
        groupPage.ActiveGroupBtn(groupName2).click();
        Thread.sleep(1000);
        GroupManagePageAction.deleteGroup(driver, groupName2);
        
        //Step4 - 验证删除成功
        Log.info("Step4 - 验证删除成功");
        Assert.assertEquals(groupPage.getGroups().size(), 0);

        Log.info("删除所有分组 - PASS");
        
        Log.info("******************删除分组测试 -- END ******************");
    }
    
}