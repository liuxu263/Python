package cn.natureself.testScripts;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import cn.natureself.componentObjects.PeopleInfo;
import cn.natureself.pageActions.LoginPageAction;
import cn.natureself.pageActions.MenuBarAction;
import cn.natureself.pageActions.PersonalInfoPageAction;
import cn.natureself.pageObjects.MenuBar;
import cn.natureself.pageObjects.PersonalInfoPage;
import cn.natureself.utils.JsonConf;
import cn.natureself.utils.UIStrings;

/**
 * 个人信息页面测试类
 * 
 * @author Andy
 */
public class PersonalInfoPageTests extends BasicTest {
	public WebDriver driver;
	public PersonalInfoPage infoPage;
	public MenuBar menuBar;
	
	public PeopleInfo profile = new PeopleInfo();

	// The logger for this test file
	public static Logger Log = LogManager.getLogger(PersonalInfoPageTests.class);

	public PersonalInfoPageTests() {
		super();
	}

	@Override
	public Logger getLogger() {
		return PersonalInfoPageTests.Log;
	}
	
	@BeforeClass
	public void BeforeClass() throws InterruptedException {
		Log.info("");
		Log.info("****************** 个人信息页面测试 -- START ******************");
		Log.info("");

		driver = getDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		menuBar = new MenuBar(driver);
		infoPage = new PersonalInfoPage(driver);
		
		// test data
		profile.setEmail("testuser@newauto.com");
		profile.setPassword("password");
		profile.setName("新自动化测试用户");
		profile.setPhone("15899999999");
		profile.setAddress("北京市");
		profile.setSite("北京大学医院");
		profile.setDepartment("心脏外科");
		profile.setTitle("主任医师");

		// 打开主页
		Log.info("打开主页");
		driver.get(JsonConf.LoginSystemURL);
		Thread.sleep(5000);

		// 确认进入主页
		Log.info("Assertion - 确认是否进入主页");
		Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
		Log.info("Assertion - 进入主页 - PASS");
		
		Log.info("用户登录");
		LoginPageAction.Login(driver, "testuser@newauto.com", "password");
		
		Log.info("进入个人信息页面");
		MenuBarAction.enterPersonalInfoPage(driver);
		
		Log.info("确认进入个人信息页面");
		Assert.assertTrue(driver.getCurrentUrl().contains("profile"));
		Log.info("确认进入个人信息页面 - PASS");
	}

	@AfterClass
	public void AfterClass() {
		Log.info("");
		Log.info("****************** 个人信息页面测试 -- END ******************");
		Log.info("");
		driver.quit();
	}
	
    /**
     * 基本信息编辑测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void BasicInfoEditTest() throws InterruptedException {
        Log.info("****************** 基本信息编辑测试  - START ******************");
        
        Log.info("确认基本信息");
        List<WebElement> info = infoPage.getBasicInfo(driver);
        Assert.assertEquals(info.get(0).getText(), profile.getName());
        Assert.assertEquals(info.get(1).getText(), profile.getDepartment() + "·" + profile.getTitle());
        Assert.assertEquals(info.get(2).getText(), profile.getSite());
        Assert.assertEquals(info.get(3).getText(), profile.getAddress());
        Assert.assertEquals(info.get(4).getText(), profile.getPhone());
        Assert.assertEquals(info.get(5).getText(), profile.getEmail());
        Log.info("确认基本信息 - PASS");
        
        Log.info("编辑基本信息");
        PersonalInfoPageAction.EditBasicInfoAction(driver, "新自动化测试用户2", "神经外科", 
        		"副主任医师", "北京肿瘤医院", "北京市朝阳区望京北路", "13888888888");
        
        Log.info("确认基本信息更改");
        info = infoPage.getBasicInfo(driver);
        Assert.assertEquals(info.get(0).getText(), "新自动化测试用户2");
        Assert.assertEquals(info.get(1).getText(), "神经外科·副主任医师");
        Assert.assertEquals(info.get(2).getText(), "北京肿瘤医院");
        Assert.assertEquals(info.get(3).getText(), "北京市朝阳区望京北路");
        Assert.assertEquals(info.get(4).getText(), "13888888888");
        Assert.assertEquals(info.get(5).getText(), profile.getEmail());
        Log.info("确认基本信息更改 - PASS");
        
        Log.info("改回来");
        PersonalInfoPageAction.EditBasicInfoAction(driver, profile.getName(), 
        		profile.getDepartment(), profile.getTitle(), profile.getSite(), 
        		profile.getAddress(), profile.getPhone());
        
        Log.info("****************** 基本信息编辑测试  - END ******************");
    }
    
    /**
     * 专注领域编辑测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void AreaInfoEditTest() throws InterruptedException {
        Log.info("****************** 专注领域编辑测试  - START ******************");
        
        Log.info("选择专注领域");
        String name1 = PersonalInfoPageAction.EditPersionalFocusAction(driver, 1);
        String name2 = PersonalInfoPageAction.EditPersionalFocusAction(driver, 10);
        
        Log.info("确认选中");
        List<WebElement> list = infoPage.SelectedPersonalFocusCheckbox();
        Assert.assertEquals(list.size(), 2);
        Assert.assertEquals(list.get(0).getText(), name1);
        Assert.assertEquals(list.get(1).getText(), name2);
        Log.info("确认选中 - PASS");
        
        Log.info("取消选择");
        PersonalInfoPageAction.EditPersionalFocusAction(driver, 1);
        PersonalInfoPageAction.EditPersionalFocusAction(driver, 10);
        
        Log.info("确认取消选择");
        list = infoPage.SelectedPersonalFocusCheckbox();
        Assert.assertEquals(list.size(), 0);
        Log.info("确认取消选择 - PASS");
        
        Log.info("****************** 专注领域编辑测试  - END ******************");
    }
    
    /**
     * 科研成果编辑测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void AchievementInfoEditTest() throws InterruptedException {
        Log.info("****************** 科研成果编辑测试  - START ******************");
        
        Log.info("添加科研成果");
        PersonalInfoPageAction.AddPersonalWorkAction(driver, "论文", "论文标题", "论文简介", "http://www.baidu.com");
        PersonalInfoPageAction.AddPersonalWorkAction(driver, "著作", "著作标题", "著作简介", "http://www.baidu.com");
        
        Log.info("确认添加成功");
        Assert.assertEquals(infoPage.getPersonalWorkCount(), 2);
        Assert.assertEquals(infoPage.getPersonalWorkInfo("论文标题", "title"), "论文标题");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("论文标题", "type"), "类型:论文");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("论文标题", "desc"), "论文简介");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("论文标题", "link"), "http://www.baidu.com");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("著作标题", "title"), "著作标题");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("著作标题", "type"), "类型:著作");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("著作标题", "desc"), "著作简介");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("著作标题", "link"), "http://www.baidu.com");
        Log.info("确认添加成功 - PASS");
        
        Log.info("编辑科研成果");
        PersonalInfoPageAction.EditPersonalWorkAction(driver, "论文标题", "项目", "项目标题", "项目简介", "http://www.google.com");
        
        Log.info("确认编辑成功");
        Assert.assertEquals(infoPage.getPersonalWorkCount(), 2);
        Assert.assertEquals(infoPage.getPersonalWorkInfo("项目标题", "title"), "项目标题");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("项目标题", "type"), "类型:项目");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("项目标题", "desc"), "项目简介");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("项目标题", "link"), "http://www.google.com");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("著作标题", "title"), "著作标题");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("著作标题", "type"), "类型:著作");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("著作标题", "desc"), "著作简介");
        Assert.assertEquals(infoPage.getPersonalWorkInfo("著作标题", "link"), "http://www.baidu.com");
        Log.info("确认编辑成功 - PASS");
        
        Log.info("删除科研成果");
        PersonalInfoPageAction.DeletePersonalWorkAction(driver, "项目标题");
        PersonalInfoPageAction.DeletePersonalWorkAction(driver, "著作标题");
        
        Log.info("确认删除成功");
        Assert.assertEquals(infoPage.getPersonalWorkCount(), 0);
        Log.info("确认删除成功");
        
        Log.info("****************** 科研成果编辑测试  - END ******************");
    }
    
    /**
     * 修改密码测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void ChangePwdTest() throws InterruptedException {
        Log.info("****************** 修改密码测试  - START ******************");
        
        Log.info("输入错误新密码格式");
        infoPage.ChangePwdBtn().click();
        Thread.sleep(1000);
        PersonalInfoPageAction.ChangePwdAction(driver, "password", "pwd", "pwd");
        
        Log.info("验证格式错误信息");
        String path = ".//p[contains(text(), '" + UIStrings.PWD_FORMAT_ERROR + "')]";
        WebElement element = driver.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证格式错误信息 - PASS");
        
        Log.info("2次输入新密码不一致");
        PersonalInfoPageAction.ChangePwdAction(driver, "password", "password1", "password2");
        
        Log.info("验证密码不一致错误信息");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.PWD_NOT_SAME_ERROR));
        Log.info("验证密码不一致错误信息 - PASS");
        
        Log.info("旧密码错误");
        PersonalInfoPageAction.ChangePwdAction(driver, "pass", "password1", "password1");
        
        Log.info("验证错误信息");
        Assert.assertTrue(driver.getPageSource().contains("密码错误"));
        infoPage.CancelBtn().click();
        Log.info("验证错误信息 - PASS");
        
        Log.info("正确输入");
        PersonalInfoPageAction.ChangePwdAction(driver, "password", "password1", "password1");
        
        Log.info("验证修改成功");
        Log.info("用户登出");
        MenuBarAction.logout(driver);
        
		Log.info("用户登录");
		LoginPageAction.Login(driver, "testuser@newauto.com", "password1");
		
		Log.info("进入个人信息页面");
		MenuBarAction.enterPersonalInfoPage(driver);
		
		Log.info("确认进入个人信息页面");
		Assert.assertTrue(driver.getCurrentUrl().contains("profile"));
		Log.info("确认进入个人信息页面 - PASS");
        Log.info("验证修改成功 - PASS");
        
        Log.info("改回原密码");
        infoPage.ChangePwdBtn().click();
        Thread.sleep(1000);
        PersonalInfoPageAction.ChangePwdAction(driver, "password1", "password", "password");
        
        Log.info("用户登出");
        MenuBarAction.logout(driver);
        
        Log.info("****************** 修改密码测试  - END ******************");
    }
}