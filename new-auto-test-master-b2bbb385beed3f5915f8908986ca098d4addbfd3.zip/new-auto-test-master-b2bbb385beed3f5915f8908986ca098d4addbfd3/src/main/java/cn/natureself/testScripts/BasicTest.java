package cn.natureself.testScripts;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import cn.natureself.utils.JsonConf;
import cn.natureself.utils.UIStrings;

import java.net.URL;

/**
 * The basic class of all test classes
 */
public class BasicTest {
    private RemoteWebDriver driver;
    public static Logger Log = LogManager.getLogger(BasicTest.class);
    
    static {
        JsonConf.init();
        UIStrings.init();
    }

    public BasicTest() {
        // 本地
        //System.setProperty("webdriver.chrome.driver", "D:/Work/chromedriver.exe");
        //driver = new ChromeDriver();

        // 远端测试
        DesiredCapabilities capability = DesiredCapabilities.chrome();
        try {
            driver = new RemoteWebDriver(new URL(JsonConf.hubURL), capability);
            driver.manage().window().maximize();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public BasicTest(String platform) {
        // 本地
        // WebDriver browser = new ChromeDriver();

        // 远端测试
        DesiredCapabilities capability = DesiredCapabilities.chrome();
        Platform p;
        switch (platform) {
        case "WIN10":
            p = Platform.WIN10;
            break;
        case "VISTA":
            p = Platform.VISTA;
            break;
        case "MAC":
            p = Platform.MAC;
            break;
        case "LINUX":
            p = Platform.LINUX;
            break;
        default:
            p = Platform.ANY;
        }
        capability.setPlatform(p);
        try {
            driver = new RemoteWebDriver(new URL(JsonConf.hubURL), capability);
            driver.manage().window().maximize();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public WebDriver getDriver() {
        return driver;
    }
    
    public Logger getLogger() {
        return Log;
    }

    public void setDriver(RemoteWebDriver driver) {
        this.driver = driver;
    }
}
