package cn.natureself.testScripts;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cn.natureself.componentObjects.SiteInfo;
import cn.natureself.pageActions.LoginPageAction;
import cn.natureself.pageActions.ProjectListPageAction;
import cn.natureself.pageObjects.SiteManagePage;
import cn.natureself.pageActions.SiteManagePageAction;
import cn.natureself.pageObjects.MenuBar;
import cn.natureself.utils.*;

/**
 * 机构设置测试类
 * 
 * @author Andy
 */
public class SiteManagePageTests extends BasicTest {
    
    public WebDriver driver;
    public SiteManagePage sitePage;
    public MenuBar menuBar;
    
    // test data
    public String sitename = "北京大学医院";
    public String sitecode = "123";
    public String casenumber = "100";
    public String sitename2 = "北京大学人民医院";
    public String sitecode2 = "333";
    public String casenumber2 = "100";
    public String changecode = "321";
    public String changenumber = "90";
    
    public SiteInfo site1 = new SiteInfo(sitename, sitecode, casenumber);
    public SiteInfo site2 = new SiteInfo(sitename2, sitecode2, casenumber2);
    
    // The logger for this test file
    public static Logger Log = LogManager.getLogger(SiteManagePageTests.class);
    
    public SiteManagePageTests() {
        super();
    }
    
    @Override
    public Logger getLogger() {
        return SiteManagePageTests.Log;
    }
    
    @BeforeClass
    public void beforeClass() throws InterruptedException {
        Log.info("");
        Log.info("******************机构设置页面测试 -- START ******************");
        Log.info("");
        
        driver = getDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        sitePage = new SiteManagePage(driver);
        
        // Pre1 - 打开主页
        Log.info("Pre1 - 打开主页");
        driver.get(JsonConf.LoginSystemURL);
        Thread.sleep(5000);
        
        // 确认进入主页
        Log.info("Assertion - 确认是否进入主页");
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
        Log.info("Assertion - 进入主页 - PASS");
        
        // Pre2 - 项目管理员登录
        Log.info("Pre2 - 项目管理员登录");
        LoginPageAction.Login(driver, JsonConf.LoginAdminName, JsonConf.LoginAdminPassWord);
        
        // Pre3 - 进入项目
        Log.info("Pre3 - 进入项目");
        ProjectListPageAction.enterProject(driver, "机构设置自动化测试项目");
        
        // Pre4 - 进入机构设置页面
        Log.info("Pre4 - 进入机构设置页面");
        menuBar = new MenuBar(driver);
        menuBar.getMenuItem(UIStrings.MENU_SITE_MANAGE).click();
        Thread.sleep(2000);
        
        // Pre5 - 验证进入机构设置页面
        Log.info("Pre5 - 验证进入机构设置页面");
        Assert.assertTrue(driver.getCurrentUrl().contains("sites"));
        Log.info("验证进入机构设置页面 - PASS");
    }
    
    @AfterClass
    public void afterClass() {
        Log.info("");
        Log.info("******************机构设置页面测试 -- END ******************");
        Log.info("");
        driver.quit();
    }
    
    /**
     * 正常添加机构流程测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void normalAddSiteTest() throws InterruptedException {
        
        Log.info("******************正常添加机构流程测试 -- START ******************");
        
        Log.info("Step1 - 点击添加机构按钮");
        Log.info("Step2 - 填写信息");
        SiteManagePageAction.addSite(driver, site1);
        
        // Step3 - 验证添加结果
        Log.info("Step3 - 验证添加结果");
        WebElement row = sitePage.getLineOfSite(site1.getName());
        List<WebElement> cols = row.findElements(By.tagName("td"));
        Log.info("验证机构名");
        Assert.assertTrue(cols.get(0).getText().equals(site1.getName()));
        Log.info("验证机构编号");
        Assert.assertTrue(cols.get(1).getText().equals(site1.getID()));
        Log.info("验证病例数");
        Assert.assertTrue(cols.get(2).getText().equals(site1.getCaseNumber()));
        Log.info("所在省份");
        Assert.assertTrue(cols.get(3).getText().equals(site1.getProvince()));
        Log.info("机构类型");
        Assert.assertTrue(cols.get(4).getText().equals(site1.getType()));
        Log.info("Assertion - 验证添加结果 - PASS");
        
        Log.info("******************正常添加机构流程测试 -- END ******************");
    }
    
    /**
     * 正常编辑机构流程测试
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void normalEditSiteTest() throws InterruptedException {
        
        Log.info("******************正常编辑机构流程测试 -- START ******************");
        
        // 取得列表中的机构行用于验证
        WebElement row = sitePage.getLineOfSite(site1.getName());
        List<WebElement> cols = row.findElements(By.tagName("td"));
        
        // Step1 - 点击编辑机构按钮
        Log.info("Step1 - 点击编辑机构按钮");
        sitePage.editSiteBtn(site1.getName()).click();
        Thread.sleep(1000);
        
        // Step2 - 验证显示的机构信息
        Log.info("Step2 - 验证编辑对话框中显示的机构信息");
        List<WebElement> siteInfo = sitePage.getInfoInEditSiteDialog();
        String actualname = siteInfo.get(0).getText();
        String actualprovince = siteInfo.get(1).getText();
        String actualtype = siteInfo.get(2).getText();
        Log.info("验证机构名");
        Assert.assertEquals(actualname, cols.get(0).getText());
        Log.info("验证机构省份");
        Assert.assertEquals(actualprovince, cols.get(3).getText());
        Log.info("验证机构类型");
        Assert.assertEquals(actualtype, cols.get(4).getText());
        Log.info("验证中心编号");
        String actualcode = sitePage.siteCodeInput().getAttribute("value");
        Assert.assertEquals(actualcode, cols.get(1).getText());
        Log.info("验证病例数");
        String actualcase = sitePage.siteCaseInput().getAttribute("value");
        Assert.assertEquals(actualcase, cols.get(2).getText());
        Log.info("Assertion - 验证编辑对话框中显示的机构信息 - PASS");
        
        // Step3 - 填写信息
        Log.info("Step3 - 填写信息");
        site1.setID(changecode);
        site1.setCaseNumber(changenumber);
        SiteManagePageAction.editSite(driver, changecode, changenumber);
        
        // Step4 - 验证修改结果
        Log.info("Step4 - 验证修改结果");
        row = sitePage.getLineOfSite(sitename);
        cols = row.findElements(By.tagName("td"));
        Log.info("验证机构名");
        Assert.assertTrue(cols.get(0).getText().equals(site1.getName()));
        Log.info("验证机构编号");
        Assert.assertTrue(cols.get(1).getText().equals(site1.getID()));
        Log.info("验证病例数");
        Assert.assertTrue(cols.get(2).getText().equals(site1.getCaseNumber()));
        Log.info("Assertion - 验证修改结果 - PASS");
        
        Log.info("******************正常编辑机构流程测试 -- END ******************");
    }
    
    /**
     * 添加机构时的机构信息验证
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void addSiteCheckTest() throws InterruptedException {
        
        Log.info("******************添加机构时的机构信息验证 -- START ******************");
        
        // Step1 - 点击添加机构按钮
        Log.info("Step1 - 点击添加机构按钮");
        sitePage.addSiteBtn().click();
        Thread.sleep(1000);
        
        // Step2 - 填写错误信息
        Log.info("Step2 - 填写错误信息");
        SiteManagePageAction.addSite(driver, site1.getName(), site1.getID(), "-1");
        
        // Step3 - 验证错误提示
        Log.info("Step3 - 验证错误提示");
        Log.info("验证项目中已有该机构提示");
        String path = ".//p[contains(text(), '" + UIStrings.SITE_EXIST_ERROR + "')]";
        WebElement form = driver.findElement(By.xpath(".//ng-form[@name='addSiteForm']"));
        WebElement element = form.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证项目中已有该机构提示 - PASS");
        
        Log.info("验证项目中已有该编号提示");
        path = ".//p[contains(text(), '" + UIStrings.SITE_UID_EXIST_ERROR + "')]";
        element = form.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证项目中已有该编号提示 - PASS");
        
        Log.info("验证目标病例数只能是正整数提示");
        path = ".//p[contains(text(), '" + UIStrings.SITE_CASE_NUMBER_FORMAT_ERR + "')]";
        element = form.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证目标病例数只能是正整数提示 - PASS");
        
        Log.info("验证机构编号只能由字母或数字构成提示");
        sitePage.siteCodeInput().clear();
        Thread.sleep(1000);
        sitePage.siteCodeInput().sendKeys(":::");
        Thread.sleep(1000);
        path = ".//p[contains(text(), '" + UIStrings.SITE_UID_FORMAT_ERROR + "')]";
        element = form.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证机构编号只能由字母或数字构成提示 - PASS");
        
        Log.info("输入小数验证目标病例数只能是正整数提示");
        sitePage.siteCaseInput().clear();
        Thread.sleep(1000);
        sitePage.siteCaseInput().sendKeys("1.2");
        Thread.sleep(1000);
        path = ".//p[contains(text(), '" + UIStrings.SITE_CASE_NUMBER_FORMAT_ERR + "')]";
        element = form.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("输入小数验证目标病例数只能是正整数提示 - PASS");
        
        // 关闭对话框
        sitePage.cancelBtn().click();
        Thread.sleep(1000);
        
        Log.info("******************添加机构时的机构信息验证 -- END ******************");
    }
    
    /**
     * 编辑机构时的验证
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void editSiteCheckTest() throws InterruptedException {

        Log.info("******************编辑机构时的机构信息验证 -- START ******************");
        
        Log.info("Step1 - 点击添加机构按钮");
        Log.info("Step2 - 添加另一条机构");
        SiteManagePageAction.addSite(driver, site2);
        
        // Step3 - 点击编辑机构按钮
        Log.info("Step3 - 点击编辑机构按钮");
        sitePage.editSiteBtn(sitename).click();
        Thread.sleep(1000);
        
        // Step4 - 填写错误信息
        Log.info("Step4 - 填写错误信息");
        SiteManagePageAction.editSite(driver, site2.getID(), "-1");
        
        // Step5 - 验证错误提示
        Log.info("Step5 - 验证错误提示");
        Log.info("验证项目中已有该编号提示");
        String path = ".//p[contains(text(), '" + UIStrings.SITE_UID_EXIST_ERROR + "')]";
        WebElement form = driver.findElement(By.xpath(".//ng-form[@name='editSiteForm']"));
        WebElement element = form.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证项目中已有该编号提示 - PASS");
        
        Log.info("验证目标病例数只能是正整数提示");
        path = ".//p[contains(text(), '" + UIStrings.SITE_CASE_NUMBER_FORMAT_ERR + "')]";
        element = form.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证目标病例数只能是正整数提示 - PASS");
        
        Log.info("验证机构编号只能由字母或数字构成提示");
        sitePage.siteCodeInput().clear();
        Thread.sleep(1000);
        sitePage.siteCodeInput().sendKeys(":::");
        Thread.sleep(1000);
        path = ".//p[contains(text(), '" + UIStrings.SITE_UID_FORMAT_ERROR + "')]";
        element = form.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("验证机构编号只能由字母或数字构成提示 - PASS");
        
        Log.info("输入小数验证目标病例数只能是正整数提示");
        sitePage.siteCaseInput().clear();
        Thread.sleep(1000);
        sitePage.siteCaseInput().sendKeys("1.2");
        Thread.sleep(1000);
        path = ".//p[contains(text(), '" + UIStrings.SITE_CASE_NUMBER_FORMAT_ERR + "')]";
        element = form.findElement(By.xpath(path));
        Assert.assertFalse(element.getAttribute("class").contains("ng-hide"));
        Log.info("输入小数验证目标病例数只能是正整数提示 - PASS");
        
        // 关闭对话框
        sitePage.cancelBtn().click();
        Thread.sleep(1000);
        
        Log.info("******************编辑机构时的机构信息验证 -- END ******************");
    }
    
    /**
     * 删除机构时的验证
     * @author Andy
     * @throws InterruptedException
     */
    @Test
    public void deleteSiteCheckTest() throws InterruptedException {
        Log.info("******************删除机构时的验证 -- START ******************");
        
        // Step1 - 点击删除机构按钮
        Log.info("Step1 - 点击删除机构按钮");
        sitePage.deleteSiteBtn(site1.getName()).click();
        Thread.sleep(1000);
        
        // 验证对话框中机构名称的显示
        Log.info("Step2 - 验证对话框中机构名称的显示");
        WebElement dialog = driver.findElement(By.xpath(".//div[@class='modal-body delete-crf']"));
        WebElement element = dialog.findElement(By.xpath(".//h5[@class='text-center title ng-binding']"));
        Assert.assertEquals(element.getText(), site1.getName());
        element = dialog.findElement(By.tagName("input"));
        Assert.assertTrue(element.getAttribute("placeholder").contains(site1.getName()));
        Log.info("验证对话框中机构名称的显示 - PASS");
        
        // Step3 - 验证错误信息
        Log.info("Step3 - 验证错误信息");
        Log.info("直接点确定，验证请输入要删除的机构名称");
        sitePage.confirmBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.SITE_NAME_NOT_INPUT_ERR));
        Log.info("直接点确定，验证请输入要删除的机构名称 - PASS");
        
        Log.info("验证输入名称不符合信息");
        sitePage.siteNameInputInDeleteDialog().sendKeys(site2.getName());
        sitePage.confirmBtn().click();
        Thread.sleep(1000);
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.SITE_NAME_NOT_SAME_ERR));
        Log.info("验证输入名称不符合信息 - PASS");
        
        // 取消操作
        sitePage.cancelBtn().click();
        Thread.sleep(1000);
        
        Log.info("******************删除机构时的验证 -- END ******************");
    }
    
    /**
     * 删除机构
     * @author Andy 
     * @throws InterruptedException
     */
    @Test
    public void deleteSiteTest() throws InterruptedException {
        Log.info("******************删除机构 -- START ******************");
        
        // 删除机构
        Log.info("Step1 - 删除所有机构");
        SiteManagePageAction.deleteSite(driver, site1.getName());
        SiteManagePageAction.deleteSite(driver, site2.getName());
        
        // Step2 - 验证机构已删除
        Log.info("Step2 - 验证机构已删除");
        Assert.assertEquals(sitePage.getLinesOfSiteTable().size(), 0);
        Log.info("验证机构已删除  - PASS");
        
        Log.info("******************删除机构 -- END ******************");
    }
}