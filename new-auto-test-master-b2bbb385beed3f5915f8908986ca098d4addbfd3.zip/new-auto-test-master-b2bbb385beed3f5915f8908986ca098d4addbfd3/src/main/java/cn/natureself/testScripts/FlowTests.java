package cn.natureself.testScripts;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import cn.natureself.componentObjects.AuditInfo;
import cn.natureself.componentObjects.CaseInfo;
import cn.natureself.componentObjects.FormTaskInfo;
import cn.natureself.pageActions.AuditManagePageAction;
import cn.natureself.pageActions.CaseFillinPageAction;
import cn.natureself.pageActions.CaseManagePageAction;
import cn.natureself.pageActions.LoginPageAction;
import cn.natureself.pageActions.MenuBarAction;
import cn.natureself.pageActions.ProjectListPageAction;
import cn.natureself.pageObjects.AuditManagePage;
import cn.natureself.pageObjects.CaseFillinPage;
import cn.natureself.pageObjects.CaseManagePage;
import cn.natureself.pageObjects.FormTaskPage;
import cn.natureself.pageObjects.MenuBar;
import cn.natureself.pageObjects.SiteManagePage;
import cn.natureself.utils.JsonConf;
import cn.natureself.utils.UIStrings;

/**
 * 复杂流程测试类
 * 
 * @author Andy
 */
public class FlowTests extends BasicTest {
	public WebDriver driver;
	public CaseManagePage casePage;
	public CaseFillinPage fillinPage;
	public FormTaskPage taskPage;
	public AuditManagePage auditPage;
	public SiteManagePage sitePage;
	public MenuBar menuBar;

	// The logger for this test file
	public static Logger Log = LogManager.getLogger(FlowTests.class);

	public FlowTests() {
		super();
	}

	@Override
	public Logger getLogger() {
		return FlowTests.Log;
	}

	// test data
	public String centername1 = "北京大学医院";
	public String centername2 = "北京电力医院";
	public String groupname1 = "分组1";
	public String groupname2 = "分组2";
	public String stage1 = "阶段1";
	public String stage2 = "阶段2";
	public String stage3 = "阶段3";
	public String[] controls = {"text_1", "text_2", "text_3", "text_4", "text_5"};
	public String inputStr = "testtext";
	public String auditQuestion = "This is a question";
	public String auditAnswer = "This is an answer";
	public String auditClose = "Close audit";

	public CaseInfo case1 = new CaseInfo(centername1, groupname1);
	public CaseInfo case2 = new CaseInfo(centername1, groupname1);
	public CaseInfo case3 = new CaseInfo(centername1, groupname1);
	public CaseInfo case4 = new CaseInfo(centername1, groupname2);
	public FormTaskInfo formTask1 = new FormTaskInfo();
	public AuditInfo audit1 = new AuditInfo();

	@BeforeClass
	public void NormalLoginAndChooseProject() throws InterruptedException {
		Log.info("");
		Log.info("****************** 流程和状态转换测试 -- START ******************");
		Log.info("");

		driver = getDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		casePage = new CaseManagePage(driver);
		fillinPage = new CaseFillinPage(driver);
		menuBar = new MenuBar(driver);
		taskPage = new FormTaskPage(driver);
		auditPage = new AuditManagePage(driver);
		sitePage = new SiteManagePage(driver);

		// 打开主页
		Log.info("打开主页");
		driver.get(JsonConf.LoginSystemURL);
		Thread.sleep(5000);

		// 确认进入主页
		Log.info("Assertion - 确认是否进入主页");
		Assert.assertTrue(driver.getPageSource().contains(UIStrings.WELCOME_MESSAGE));
		Log.info("Assertion - 进入主页 - PASS");
	}

	@AfterClass
	public void NormalQuit() {
		Log.info("");
		Log.info("****************** 流程和状态转换测试 -- END ******************");
		Log.info("");
		driver.quit();
	}

	/**
	 * 登录并进入指定页面
	 * 
	 * @param user - user name
	 * @param pwd - password
	 * @param page - page name
	 * @throws InterruptedException
	 */
	public void LoginAndGotoPage(String user, String pwd, String page) throws InterruptedException {
		// 用户登陆
		Log.info("用户登陆");
		LoginPageAction.Login(driver, user, pwd);

		// 进入项目
		Log.info("选择复杂流程自动化测试项目");
		ProjectListPageAction.enterProject(driver, "复杂流程自动化测试项目");
		
		// 进入指定页面
		Log.info("进入指定页面");
		menuBar.getMenuItem(page).click();
		Thread.sleep(2000);
	}

	/**
	 * 设置病例信息测试数据
	 * 
	 * @param caseInfo - CaseInfo object
	 */
	public void initCaseInfo(CaseInfo caseInfo) {
		caseInfo.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
		caseInfo.setInputter(menuBar.getUserName());
		caseInfo.addStageStatus(stage1, UIStrings.STAGE_STATUS_NEW);
		caseInfo.addStageStatus(stage2, UIStrings.STAGE_STATUS_NEW);
	}
	
    /**
     * 检查添加病例结果
     * 
     * @param caseInfo - CaseInfo object
     * @throws InterruptedException
     */
    public void checkAddCaseResults(CaseInfo caseInfo) throws InterruptedException {
        String successMsg = casePage.AddCaseSuccessMessage();
        String groupMsg = casePage.AddCaseSuccessGroupMessage();
        Assert.assertTrue(successMsg.contains(caseInfo.getName()));
        Assert.assertTrue(successMsg.contains("入组成功"));
        Assert.assertTrue(groupMsg.contains(caseInfo.getGroupName()));
        casePage.ConfirmBtn().click();
        Thread.sleep(1000);
    }
    
    /**
     * 检查病例和阶段状态
     * 
     * @param caseInfo - CaseInfo object
     * @throws InterruptedException
     */
    public void checkCaseStageStatus(CaseInfo caseInfo) throws InterruptedException {
        casePage.ActiveGroupBtn(caseInfo.getGroupName()).click();
        Thread.sleep(1000);

        WebElement row = casePage.getLineOfCase(caseInfo.getStudyNumber());
        String statusOfStage1 = casePage.getStageStatusOfCase(caseInfo.getStudyNumber(), stage1);
        String statusOfStage2 = casePage.getStageStatusOfCase(caseInfo.getStudyNumber(), stage2);
        List<WebElement> cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(2).getText(), caseInfo.getStatus());
        Assert.assertEquals(statusOfStage1, caseInfo.getStatusOfStage(stage1));
        Assert.assertEquals(statusOfStage2, caseInfo.getStatusOfStage(stage2));
    }
    
    /**
     * 检查表单任务表格中的信息
     * 
     * @param taskInfo - FormTaskInfo object
     * @throws InterruptedException
     */
    public void checkFormTaskInfo(FormTaskInfo taskInfo) throws InterruptedException {
        taskPage.getStatusGroupBtn(taskInfo.getStatus()).click();
        Thread.sleep(1000);
        WebElement row = taskPage.getLineOfTask(taskInfo.getStudyNumber(), taskInfo.getStage());
        List<WebElement> cols = row.findElements(By.tagName("td"));
        Assert.assertEquals(cols.get(0).getText(), taskInfo.getStage());
        Assert.assertEquals(cols.get(1).getText(), taskInfo.getName());
        Assert.assertEquals(cols.get(2).getText(), taskInfo.getCaseStatus());
        Assert.assertEquals(cols.get(3).getText(), taskInfo.getStudyNumber());
        Assert.assertEquals(cols.get(4).getText(), taskInfo.getGroup());
        Assert.assertEquals(cols.get(5).getText(), taskInfo.getCenter());
        Assert.assertEquals(cols.get(6).getText(), taskInfo.getInputter());
        Assert.assertEquals(cols.get(7).getText(), taskInfo.getAuditor());
    }
    
    /**
     * 检查质疑管理表格中的信息
     * 
     * @param auditInfo - AuditInfo object
     * @throws InterruptedException
     */
    public void checkAuditInfo(AuditInfo auditInfo) throws InterruptedException {
        auditPage.getStatusGroupBtn(auditInfo.getOperation()).click();
        Thread.sleep(1000);
        WebElement row = auditPage.getLineOfAudit(auditInfo);
        List<WebElement> cols = row.findElements(By.tagName("td"));
        String status = auditPage.getOperationBtn(auditInfo).getText();
        String link = auditPage.getQuestionLink(auditInfo).getText();
        Assert.assertEquals(status, auditInfo.getOperation());
        Assert.assertEquals(link, auditInfo.getQuestion());
        Assert.assertEquals(cols.get(3).getText(), auditInfo.getStudyNumber());
        Assert.assertEquals(cols.get(4).getText(), auditInfo.getCenter());
        Assert.assertEquals(cols.get(5).getText(), auditInfo.getGroup());
        Assert.assertEquals(cols.get(6).getText(), auditInfo.getStage());
        Assert.assertEquals(cols.get(7).getText(), auditInfo.getForm());
        Assert.assertEquals(cols.get(8).getText(), auditInfo.getSection());
        Assert.assertEquals(cols.get(9).getText(), auditInfo.getAuditor());
        Assert.assertEquals(cols.get(10).getText(), auditInfo.getInputter());
    }
	
    /**
     * 病例填写流程和状态转换的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void CaseFormFillinFlowAndStateTransTest() throws InterruptedException {
        Log.info("****************** 病例填写流程和状态转换的测试 -- START ******************");
        
		// 登录并进入病例管理页面
        Log.info("Step1 - 录入员登录并进入病例管理页面");
		LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord, UIStrings.MENU_CASE_MANAGE);

		// 验证进入病例管理页面
		Log.info("验证进入病例管理页面");
		Assert.assertTrue(driver.getCurrentUrl().contains("cases"));
		Log.info("验证进入病例管理页面 - PASS");
		
		Log.info("Step2 - 录入员添加病例1");
		initCaseInfo(case1);
		CaseManagePageAction.AddCase(driver, case1, "id18");
		
        Log.info("验证病例1添加结果");
        checkAddCaseResults(case1);
        Log.info("验证病例1添加结果 - PASS");
        
        Log.info("验证病例1状态和阶段状态");
        checkCaseStageStatus(case1);
        Log.info("验证病例1状态和阶段状态 - PASS");
        
        Log.info("Step3 - 点击进入阶段1表单");
        casePage.getStageBtnOfCase(case1.getStudyNumber(), stage1).click();
        
        Log.info("Step4 - 检查表单填写页面里的信息");
        List<WebElement> info = fillinPage.getCaseInfo();
        Log.info("检查编号");
        Assert.assertEquals(info.get(0).getText(), case1.getStudyNumber());
        Log.info("检查编号 - PASS");
        Log.info("检查中心");
        Assert.assertEquals(info.get(1).getText(), case1.getCenterName());
        Log.info("检查中心 - PASS");
        Log.info("检查分组");
        Assert.assertEquals(info.get(2).getText(), case1.getGroupName());
        Log.info("检查分组 - PASS");
        Log.info("检查状态");
        Assert.assertEquals(info.get(3).getText(), case1.getStatus());
        Log.info("检查状态 - PASS");
        Log.info("检查姓名");
        Assert.assertEquals(info.get(4).getText(), case1.getName());
        Log.info("检查姓名 - PASS");
        Log.info("检查阶段1状态");
        String status = fillinPage.getStageStatus(stage1);
        Assert.assertEquals(status, case1.getStatusOfStage(stage1));
        Log.info("检查阶段1状态 - PASS");
        Log.info("检查阶段2状态");
        status = fillinPage.getStageStatus(stage2);
        Assert.assertEquals(status, case1.getStatusOfStage(stage2));
        Log.info("检查阶段2状态 - PASS");
        Log.info("检查表单填写页面里的信息 - PASS");
        
        Log.info("Step5 - 填写表单并保存");
        CaseFillinPageAction.fillinTextInputCtrl(driver, inputStr);
        fillinPage.getSaveBtn().click();
        Thread.sleep(2000);
        
        Log.info("Step6 - 检查状态变化");
        info = fillinPage.getCaseInfo();
        Log.info("检查病例状态 - 进行中");
        Assert.assertEquals(info.get(3).getText(), case1.getStatus());
        Log.info("检查病例状态 - PASS");
        Log.info("检查阶段1状态 - 填写中");
        case1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_INPROGRESS);
        status = fillinPage.getStageStatus(stage1);
        Assert.assertEquals(status, case1.getStatusOfStage(stage1));
        Log.info("检查阶段1状态 - PASS");
        Log.info("检查阶段2状态 - 新建立");
        status = fillinPage.getStageStatus(stage2);
        Assert.assertEquals(status, case1.getStatusOfStage(stage2));
        Log.info("检查阶段2状态 - PASS");
        
        Log.info("回到病例管理页面");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(2000);
        Log.info("验证病例1状态和阶段状态");
        checkCaseStageStatus(case1);
        Log.info("验证病例1状态和阶段状态 - PASS");
        
        Log.info("Step7 - 到表单任务页面");
        formTask1.setStatus(UIStrings.STAGE_STATUS_INPROGRESS);
        formTask1.setStage(stage1);
        formTask1.setName(case1.getName());
        formTask1.setCaseStatus(case1.getStatus());
        formTask1.setStudyNumber(case1.getStudyNumber());
        formTask1.setGroup(case1.getGroupName());
        formTask1.setCenter(case1.getCenterName());
        formTask1.setInputter(case1.getInputter());
        formTask1.setAuditor("-");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(2000);
		
        Log.info("验证表单任务填写中表格中的信息");
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        checkFormTaskInfo(formTask1);
        Log.info("验证表单任务填写中表格中的信息 - PASS");
        
        Log.info("Step8 - 进入病例管理，点击进入阶段1表单");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(2000);
        casePage.getStageBtnOfCase(case1.getStudyNumber(), stage1).click();
        
        Log.info("Step9 - 点击保存并到下一个表单");
        fillinPage.getSaveToNextBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step10 - 填写表单并保存");
        CaseFillinPageAction.fillinTextInputCtrl(driver, inputStr);
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step11 - 提交阶段1");
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step12 - 检查状态变化");
        Log.info("检查阶段1状态 - 已提交");
        case1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_SUBMIT);
        status = fillinPage.getStageStatus(stage1);
        Assert.assertEquals(status, case1.getStatusOfStage(stage1));
        Log.info("检查阶段1状态 - 已提交 - PASS");
        Log.info("检查阶段2状态 - 新建立");
        status = fillinPage.getStageStatus(stage2);
        Assert.assertEquals(status, case1.getStatusOfStage(stage2));
        Log.info("检查阶段2状态 - 新建立 - PASS");
        Log.info("检查提交按钮变成撤回按钮");
        Assert.assertNull(fillinPage.getSubmitBtn());
        Assert.assertNotNull(fillinPage.getWithdrawBtn());
        Log.info("检查提交按钮变成撤回按钮 - PASS");
        Log.info("检查表单控件不可编辑状态");
    	List<WebElement> inputs = fillinPage.getTextInputCtrlInForm();
    	for (WebElement input:inputs) {
    		Assert.assertTrue(input.getAttribute("style").equals("background: rgb(238, 238, 238);"));
    		Assert.assertTrue(input.getAttribute("disabled").equals("true"));
    	}
        Log.info("检查表单控件不可编辑状态 - PASS");
        Log.info("检查表单保存按钮不可点击状态");
        Assert.assertTrue(fillinPage.getSaveBtn().getAttribute("class").contains("disabled"));
        Assert.assertTrue(fillinPage.getSaveToNextBtn().getAttribute("class").contains("disabled"));
        Log.info("检查表单保存按钮不可点击状态 - PASS");
        
        Log.info("回到病例管理页面");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(2000);
        Log.info("验证病例1状态和阶段状态");
        checkCaseStageStatus(case1);
        Log.info("验证病例1状态和阶段状态 - PASS");
        
        Log.info("到表单任务页面");
        formTask1.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(2000);
		Log.info("验证填写中组中没有信息");
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_INPROGRESS).click();
        Thread.sleep(1000);
        Assert.assertNull(taskPage.getLineOfTask(formTask1.getStudyNumber(), formTask1.getStage()));
		Log.info("验证填写中组中没有信息 - PASS");
        Log.info("验证表单任务移动到已提交组中");
        checkFormTaskInfo(formTask1);
        Log.info("验证表单任务移动到已提交组中 - PASS");
        
        Log.info("Step13 - 进入病例管理，点击进入阶段1表单");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(2000);
        casePage.getStageBtnOfCase(case1.getStudyNumber(), stage1).click();
        
        Log.info("Step14 - 点击撤回按钮");
        fillinPage.getWithdrawBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step15 - 验证撤回对话框中的信息");
        String str = fillinPage.getInfoInWithdrawDialog();
        Log.info("验证病例名");
        Assert.assertTrue(str.contains(case1.getName()));
        Log.info("验证病例名 - PASS");
        Log.info("验证阶段名");
        Assert.assertTrue(str.contains(stage1));
        Log.info("验证阶段名 - PASS");
        
        Log.info("Step16 - 点击确认撤回");
        fillinPage.getRadioInWithdrawDialog("error").click();
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step17 - 确认状态变化");
        Log.info("检查阶段1状态 - 填写中");
        case1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_INPROGRESS);
        status = fillinPage.getStageStatus(stage1);
        Assert.assertEquals(status, case1.getStatusOfStage(stage1));
        Log.info("检查阶段1状态 - 填写中 - PASS");
        Log.info("检查阶段2状态 - 新建立");
        status = fillinPage.getStageStatus(stage2);
        Assert.assertEquals(status, case1.getStatusOfStage(stage2));
        Log.info("检查阶段2状态 - 新建立 - PASS");
        Log.info("检查撤回按钮变成提交按钮");
        Assert.assertNotNull(fillinPage.getSubmitBtn());
        Assert.assertNull(fillinPage.getWithdrawBtn());
        Log.info("检查撤回按钮变成提交按钮 - PASS");
        Log.info("检查表单控件可编辑状态");
    	inputs = fillinPage.getTextInputCtrlInForm();
    	for (WebElement input:inputs) {
    		Assert.assertTrue(input.getAttribute("style").isEmpty());
    		Assert.assertNull(input.getAttribute("disabled"));
    	}
        Log.info("检查表单控件可编辑状态 - PASS");
        Log.info("检查表单保存按钮可点击状态");
        Assert.assertFalse(fillinPage.getSaveBtn().getAttribute("class").contains("disabled"));
        Assert.assertFalse(fillinPage.getSaveToNextBtn().getAttribute("class").contains("disabled"));
        Log.info("检查表单保存按钮可点击状态 - PASS");
        
        Log.info("回到病例管理页面");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(2000);
        Log.info("验证病例1状态和阶段状态");
        checkCaseStageStatus(case1);
        Log.info("验证病例1状态和阶段状态 - PASS");
        
        Log.info("到表单任务页面");
        formTask1.setStatus(UIStrings.STAGE_STATUS_INPROGRESS);
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(2000);
        Log.info("验证表单任务移动到填写中组中");
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        checkFormTaskInfo(formTask1);
        Log.info("验证表单任务移动到填写中组中 - PASS");
		Log.info("验证已提交组中没有信息");
        taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT).click();
        Thread.sleep(1000);
        Assert.assertNull(taskPage.getLineOfTask(formTask1.getStudyNumber(), formTask1.getStage()));
		Log.info("验证已提交组中没有信息 - PASS");
		
		Log.info("Step18 - 提交阶段1");
		taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_INPROGRESS).click();
        Thread.sleep(1000);
		taskPage.getStageLink(formTask1.getStudyNumber(), formTask1.getStage()).click();
		Thread.sleep(1000);
		fillinPage.getSubmitBtn().click();
		Thread.sleep(1000);
		fillinPage.getConfirmBtn().click();
		Thread.sleep(1000);
		formTask1.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
		case1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_SUBMIT);
		
		Log.info("Step19 - 录入员登出");
		MenuBarAction.logout(driver);
		
        Log.info("****************** 病例填写流程和状态转换的测试 -- END ******************");
    }
    
    /**
     * 监查流程和状态转换的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void AuditFlowAndStateTransTest() throws InterruptedException {
        Log.info("****************** 监查流程和状态转换的测试 -- START ******************");
        
        Log.info("Step1 - 监察员登录并进入表单任务页面");
        LoginAndGotoPage(JsonConf.LoginAuditorName, JsonConf.LoginAuditorPassWord, UIStrings.MENU_FORM_TASK);
        
		Log.info("验证进入表单任务页面");
		Assert.assertTrue(driver.getCurrentUrl().contains("caseEvents"));
		Log.info("验证进入表单任务页面 - PASS");
		
		Log.info("Step2 - 点击所有表单，点已提交组");
		taskPage.AllFormRadio().click();
		Thread.sleep(1000);
		taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT);
		Thread.sleep(1000);
		
        Log.info("验证表单任务信息");
        checkFormTaskInfo(formTask1);
        Log.info("验证表单任务信息 - PASS");
        
        Log.info("Step3 - 进入阶段1表单");
        taskPage.getStageLink(formTask1.getStudyNumber(), formTask1.getStage()).click();
        
        Log.info("Step4 - 检查表单内状态");
        Log.info("检查病例信息");
        List<WebElement> info = fillinPage.getCaseInfo();
        Log.info("检查编号");
        Assert.assertEquals(info.get(0).getText(), case1.getStudyNumber());
        Log.info("检查编号 - PASS");
        Log.info("检查中心");
        Assert.assertEquals(info.get(1).getText(), case1.getCenterName());
        Log.info("检查中心 - PASS");
        Log.info("检查分组");
        Assert.assertEquals(info.get(2).getText(), case1.getGroupName());
        Log.info("检查分组 - PASS");
        Log.info("检查状态");
        Assert.assertEquals(info.get(3).getText(), case1.getStatus());
        Log.info("检查状态 - PASS");
        Log.info("检查姓名");
        Assert.assertEquals(info.get(4).getText(), case1.getName());
        Log.info("检查姓名 - PASS");
        Log.info("检查病例信息 - PASS");
        Log.info("检查阶段状态");
        String status = fillinPage.getStageStatus(stage1);
        Assert.assertEquals(status, case1.getStatusOfStage(stage1));
        status = fillinPage.getStageStatus(stage2);
        Assert.assertEquals(status, case1.getStatusOfStage(stage2));
        Log.info("检查阶段状态 - PASS");
        Log.info("检查通过按钮");
        Assert.assertNull(fillinPage.getSubmitBtn());
        Assert.assertNotNull(fillinPage.getPassBtn());
        Log.info("检查通过按钮 - PASS");
        Log.info("检查控件不可编辑");
    	List<WebElement> inputs = fillinPage.getTextInputCtrlInForm();
    	for (WebElement input:inputs) {
    		Assert.assertTrue(input.getAttribute("style").equals("background: rgb(238, 238, 238);"));
    		Assert.assertTrue(input.getAttribute("disabled").equals("true"));
    	}
        Log.info("检查控件不可编辑 - PASS");
        Log.info("检查控件旁有无质疑按钮");
        List<WebElement> buttons = fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_NOAUDIT);
        Assert.assertEquals(buttons.size(), 5);
        Log.info("检查控件旁有无质疑按钮 - PASS");

        Log.info("Step5 - 给第一项添加质疑");
        Log.info("点击无质疑按钮");
        buttons.get(0).click();
        Thread.sleep(1000);
        Log.info("确认质疑对话框里的问题和答案信息");
        String qaInfo = auditPage.getInfoInAuditDialog();
        String question = qaInfo.split(" ")[0];
        String answer = qaInfo.split(" ")[1];
        Assert.assertEquals(question, controls[0]);
        Assert.assertEquals(answer, inputStr);
        Log.info("确认质疑对话框里的问题和答案信息 - PASS");
        
        Log.info("添加质疑记录");
        AuditManagePageAction.AddAuditRecordAction(driver, auditQuestion, "add", false);
        Log.info("确认记录已添加");
        List<WebElement> rows = auditPage.getRecordsInAuditDialog();
        List<WebElement> cols = rows.get(0).findElements(By.tagName("td"));
        Log.info("确认类型");
        Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_QUESTION);
        Log.info("确认类型 - PASS");
        Log.info("确认内容");
        Assert.assertEquals(cols.get(1).getText(), auditQuestion);
        Log.info("确认内容 - PASS");
        Log.info("确认角色");
        Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        Log.info("确认角色 - PASS");
        Log.info("确认记录已添加 - PASS");
        
        Log.info("Step6 - 确认添加质疑后的状态变化");
        auditPage.AuditDialogCloseBtn().click();
        Thread.sleep(1000);
        
        // update data
        case1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_AUDIT);
		audit1.setOperation(UIStrings.AUDIT_STATUS_WAITFORFIX);
		audit1.setAuditor(menuBar.getUserName());
		audit1.setInputter(case1.getInputter());
		audit1.setCenter(case1.getCenterName());
		audit1.setQuestion(question);
		audit1.setStudyNumber(case1.getStudyNumber());
		audit1.setGroup(case1.getGroupName());
		audit1.setStage(formTask1.getStage());
		audit1.setForm(fillinPage.getActiveFormName());
		audit1.setSection(fillinPage.getActiveSectionName());
        
        Log.info("确认无质疑变成待修复");
        Assert.assertEquals(fillinPage.getAuditBtnStatusInForm(0), UIStrings.AUDIT_STATUS_WAITFORFIX);
        Log.info("确认无质疑变成待修复 - PASS");
        
        Log.info("确认阶段1状态变为监查中");
        status = fillinPage.getStageStatus(stage1);
        Assert.assertEquals(status, case1.getStatusOfStage(stage1));
        Log.info("确认阶段1状态变为监查中 - PASS");
        
        Log.info("到表单任务页面");
        formTask1.setStatus(UIStrings.STAGE_STATUS_AUDIT);
        formTask1.setAuditor(menuBar.getUserName());
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(2000);
        Log.info("验证表单任务移动到监查中组中");
        taskPage.AllFormRadio().click();
        Thread.sleep(1000);
        checkFormTaskInfo(formTask1);
        Log.info("验证表单任务移动到监查中组中 - PASS");
        
        Log.info("到质疑管理页面");
		menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
		Thread.sleep(2000);
		Log.info("验证质疑列表中的信息");
		checkAuditInfo(audit1);
		Log.info("验证质疑列表中的信息 - PASS");
		
		Log.info("点击待修复按钮");
		auditPage.getOperationBtn(audit1).click();
		Thread.sleep(1000);
		
		Log.info("确认质疑记录对话框打开并验证信息");
        qaInfo = auditPage.getInfoInAuditDialog();
        question = qaInfo.split(" ")[0];
        answer = qaInfo.split(" ")[1];
        Assert.assertEquals(question, controls[0]);
        Assert.assertEquals(answer, inputStr);
        rows = auditPage.getRecordsInAuditDialog();
        Assert.assertEquals(rows.size(), 1);
        auditPage.AuditDialogCloseBtn().click();
        Thread.sleep(1000);
		Log.info("确认质疑记录对话框打开并验证信息 - PASS");
		
		Log.info("点击问题链接");
		auditPage.getQuestionLink(audit1).click();
		Thread.sleep(1000);
		
		Log.info("确认进入正确表单");
		Assert.assertEquals(fillinPage.getActiveFormName(), audit1.getForm());
		Assert.assertEquals(fillinPage.getActiveSectionName(), audit1.getSection());
		fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_WAITFORFIX).get(0).click();
        qaInfo = auditPage.getInfoInAuditDialog();
        question = qaInfo.split(" ")[0];
        answer = qaInfo.split(" ")[1];
        Assert.assertEquals(question, controls[0]);
        Assert.assertEquals(answer, inputStr);
        auditPage.AuditDialogCloseBtn().click();
        Thread.sleep(1000);
		Log.info("确认进入正确表单 - PASS");
		
		Log.info("点击通过按钮");
		fillinPage.getPassBtn().click();
		Thread.sleep(1000);
		fillinPage.getConfirmBtn().click();
		Thread.sleep(1000);
		Log.info("确认提示信息");
		Assert.assertTrue(driver.getPageSource().contains(UIStrings.STAGE_CANNOT_PASS_ERR));
		fillinPage.getCancelBtn().click();
		Log.info("确认提示信息 - PASS");
		
		Log.info("Step7 - 监查员登出, 录入员登入");
		MenuBarAction.logout(driver);
		LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord, UIStrings.MENU_CASE_MANAGE);
		
		Log.info("Step8 - 验证病例状态和表单任务和质疑");
		Log.info("验证病例和阶段状态");
		checkCaseStageStatus(case1);
		Log.info("验证病例和阶段状态 - PASS");
		
		Log.info("验证表单任务在监察中组");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(1000);
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        checkFormTaskInfo(formTask1);
		Log.info("验证表单任务在监察中组 - PASS");
		
		Log.info("验证质疑在待修复组");
		menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
		Thread.sleep(1000);
		auditPage.MyAuditRadioBtn().click();
        Thread.sleep(1000);
        checkAuditInfo(audit1);
		Log.info("验证质疑在待修复组 - PASS");
		
		Log.info("Step9 - 点击质疑的操作按钮， 给质疑添加回复");
		AuditManagePageAction.AddAuditRecordAction(driver, audit1, auditAnswer, "reply", false);
		
        Log.info("确认回复已添加");
        rows = auditPage.getRecordsInAuditDialog();
        cols = rows.get(0).findElements(By.tagName("td"));
        Log.info("确认类型");
        Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_REPLY);
        Log.info("确认类型 - PASS");
        Log.info("确认内容");
        Assert.assertEquals(cols.get(1).getText(), auditAnswer);
        Log.info("确认内容 - PASS");
        Log.info("确认角色");
        Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        Log.info("确认角色 - PASS");
        Log.info("确认回复已添加 - PASS");
		
        Log.info("关闭对话框, 验证质疑移动到待校验组");
        auditPage.AuditDialogCloseBtn().click();
        Thread.sleep(1000);
        audit1.setOperation(UIStrings.AUDIT_STATUS_WAITFORCHECK);
        Assert.assertNull(auditPage.getLineOfAudit(audit1));
        checkAuditInfo(audit1);
        Log.info("验证质疑移动到待校验组 - PASS");

		Log.info("点击问题链接");
		auditPage.getQuestionLink(audit1).click();
		Thread.sleep(1000);
		
		Log.info("确认进入正确表单和质疑状态");
		Assert.assertEquals(fillinPage.getActiveFormName(), audit1.getForm());
		Assert.assertEquals(fillinPage.getActiveSectionName(), audit1.getSection());
		status = fillinPage.getAuditBtnStatusInForm(0);
		Assert.assertEquals(status, UIStrings.AUDIT_STATUS_WAITFORCHECK);
		Log.info("确认进入正确表单和质疑状态 - PASS");
		
        Log.info("Step10 - 监察员登录并进入质疑管理页面");
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginAuditorName, JsonConf.LoginAuditorPassWord, UIStrings.MENU_AUDIT_MANAGE);
        
		Log.info("Step11 - 点击问题链接进入表单");
		auditPage.getStatusGroupBtn(UIStrings.AUDIT_STATUS_WAITFORCHECK).click();
		Thread.sleep(1000);
		auditPage.getQuestionLink(audit1).click();
		Thread.sleep(1000);
		
		Log.info("Step12 - 点击质疑按钮并关闭质疑");
		fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_WAITFORCHECK).get(0).click();
		AuditManagePageAction.AddAuditRecordAction(driver, auditClose, "close", false);
		
        Log.info("确认关闭记录已添加");
        rows = auditPage.getRecordsInAuditDialog();
        cols = rows.get(0).findElements(By.tagName("td"));
        Log.info("确认类型");
        Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_CLOSE);
        Log.info("确认类型 - PASS");
        Log.info("确认内容");
        Assert.assertEquals(cols.get(1).getText(), auditClose);
        Log.info("确认内容 - PASS");
        Log.info("确认角色");
        Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        Log.info("确认角色 - PASS");
        Log.info("确认关闭记录已添加 - PASS");
		
        Log.info("关闭对话框, 验证质疑已关闭状态");
        auditPage.AuditDialogCloseBtn().click();
        Thread.sleep(1000);
		status = fillinPage.getAuditBtnStatusInForm(0);
		Assert.assertEquals(status, UIStrings.AUDIT_STATUS_CLOSED);
        Log.info("验证质疑已关闭状态 - PASS");
        
        Log.info("进入质疑管理页面, 验证质疑在已关闭组");
        audit1.setOperation(UIStrings.AUDIT_STATUS_CLOSED);
		menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
		Thread.sleep(1000);
        checkAuditInfo(audit1);
        Log.info("验证质疑在已关闭组 - PASS");
        
		Log.info("Step13 - 点击问题链接进入表单");
		auditPage.getQuestionLink(audit1).click();
		Thread.sleep(1000);
		
		Log.info("点击通过阶段1");
		fillinPage.getPassBtn().click();
		Thread.sleep(1000);
		fillinPage.getConfirmBtn().click();
		Thread.sleep(1000);
		
		Log.info("验证阶段1状态变成已通过");
		Assert.assertEquals(fillinPage.getStageStatus(stage1), UIStrings.STAGE_STATUS_PASS);
		formTask1.setStatus(UIStrings.STAGE_STATUS_PASS);
		Log.info("验证阶段1状态变成已通过 - PASS");
		
        Log.info("Step14 - 到表单任务页面");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(1000);
        Log.info("验证表单任务移动到已通过组中");
        checkFormTaskInfo(formTask1);
        Log.info("验证表单任务移动到已通过组中 - PASS");
        
		Log.info("Step15 - 监查员登出, 录入员登入");
		MenuBarAction.logout(driver);
		LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord, UIStrings.MENU_CASE_MANAGE);
		
		Log.info("Step16 - 验证病例状态和表单任务和质疑");
		Log.info("验证病例和阶段状态");
		case1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_PASS);
		checkCaseStageStatus(case1);
		Log.info("验证病例和阶段状态 - PASS");
		
		Log.info("验证表单任务在已通过组");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(1000);
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        checkFormTaskInfo(formTask1);
		Log.info("验证表单任务在已通过组 - PASS");
		
		Log.info("验证质疑在已关闭组");
		menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
		Thread.sleep(2000);
		auditPage.MyAuditRadioBtn().click();
        Thread.sleep(1000);
        checkAuditInfo(audit1);
		Log.info("验证质疑在已关闭组 - PASS");
		
		Log.info("Step17 - 填写阶段2表单并提交");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(1000);
		casePage.getStageBtnOfCase(case1.getStudyNumber(), stage2).click();
		Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, inputStr);
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step18 - 监察员登录并进入表单任务页面");
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginAuditorName, JsonConf.LoginAuditorPassWord, UIStrings.MENU_FORM_TASK);
		taskPage.AllFormRadio().click();
		Thread.sleep(1000);
		taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT);
		Thread.sleep(1000);
        
        Log.info("进入阶段2表单");
        taskPage.getStageLink(case1.getStudyNumber(), stage2).click();
        
		Log.info("点击通过阶段2");
		fillinPage.getPassBtn().click();
		Thread.sleep(1000);
		fillinPage.getConfirmBtn().click();
		Thread.sleep(1000);
		
		Log.info("Step19 - 验证各页面病例状态变为已完成");
		// update data
        case1.setStatus(UIStrings.CASE_STATUS_COMPLETE);
        case1.setStatusOfStage(stage2, UIStrings.STAGE_STATUS_PASS);
        formTask1.setCaseStatus(UIStrings.CASE_STATUS_COMPLETE);

        Log.info("检查病例状态");
        info = fillinPage.getCaseInfo();
        Assert.assertEquals(info.get(3).getText(), UIStrings.CASE_STATUS_COMPLETE);
        Log.info("检查病例状态 - PASS");
        
		Log.info("验证表单任务里病例状态");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(1000);
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        checkFormTaskInfo(formTask1);
		Log.info("验证表单任务里病例状态 - PASS");
		
		Log.info("Step20 - 监查员登出, 录入员登入");
		MenuBarAction.logout(driver);
		LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord, UIStrings.MENU_CASE_MANAGE);
		
		Log.info("Step21 - 验证病例状态");
		Log.info("验证病例和阶段状态");
		checkCaseStageStatus(case1);
		Log.info("验证病例和阶段状态 - PASS");
		
		Log.info("验证表单任务病例状态");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(1000);
        taskPage.MyFormRadio().click();
        Thread.sleep(1000);
        checkFormTaskInfo(formTask1);
		Log.info("验证表单任务病例状态 - PASS");
		
		Log.info("验证病例无法删除");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(1000);
		casePage.DeleteCaseBtn(case1.getStudyNumber()).click();
		Assert.assertTrue(driver.getPageSource().contains(UIStrings.CASE_CANNOT_DELETE));
		casePage.ConfirmBtn().click();
		Log.info("验证病例无法删除 - PASS");
		
		Log.info("Step22 - 管理员登入");
		MenuBarAction.logout(driver);
		LoginAndGotoPage(JsonConf.LoginAdminName, JsonConf.LoginAdminPassWord, UIStrings.MENU_FORM_TASK);
		
		Log.info("Step23 - 进入表单任务");
		taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_PASS).click();;
		Thread.sleep(1000);
		taskPage.AllFormRadio().click();
		Thread.sleep(1000);
		
		Log.info("Step24 - 点击接管阶段1任务");
		taskPage.getUndertakeBtn(formTask1.getStudyNumber(), formTask1.getStage()).click();
		
		Log.info("验证对话框内监查负责人");
		Assert.assertEquals(taskPage.getInfoFromTakeTaskDialog(), formTask1.getAuditor());
		Log.info("验证对话框内监查负责人 - PASS");
		
		Log.info("点击确定, 验证监查负责人变化");
		taskPage.ConfirmBtn().click();
		Thread.sleep(3000);
		formTask1.setAuditor(menuBar.getUserName());
		audit1.setAuditor(menuBar.getUserName());
		checkFormTaskInfo(formTask1);
		Log.info("验证监查负责人变化 - PASS");
		
		Log.info("Step25 - 进入阶段1表单");
		taskPage.getStageLink(case1.getStudyNumber(), stage1).click();
		Thread.sleep(1000);
		
		Log.info("点击已关闭的质疑，添加质疑");
		fillinPage.getAuditBtnInForm(UIStrings.AUDIT_RECORD_TYPE_CLOSE).get(0).click();
		AuditManagePageAction.AddAuditRecordAction(driver, inputStr, "add", true);
		Thread.sleep(1000);
		
		Log.info("验证质疑状态变为待修复");
		Assert.assertEquals(fillinPage.getAuditBtnStatusInForm(0), UIStrings.AUDIT_STATUS_WAITFORFIX);
		audit1.setOperation(UIStrings.AUDIT_STATUS_WAITFORFIX);
		Log.info("验证质疑状态变为待修复 - PASS");
		
		Log.info("验证阶段1状态变为监查中");
		Assert.assertEquals(fillinPage.getStageStatus(stage1), UIStrings.STAGE_STATUS_AUDIT);
		case1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_AUDIT);
		Log.info("验证阶段1状态变为监查中 - PASS");
		
		Log.info("验证表单任务变为监查中");
		formTask1.setStatus(UIStrings.STAGE_STATUS_AUDIT);
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(1000);
        taskPage.AllFormRadio().click();
        Thread.sleep(1000);
        checkFormTaskInfo(formTask1);
		Log.info("验证表单任务变为监查中 - PASS");
		
        Log.info("进入质疑管理页面, 验证质疑在待修复组");
		menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
		Thread.sleep(1000);
        checkAuditInfo(audit1);
        Log.info("验证质疑在待修复组 - PASS");
		
		Log.info("Step26 - 验证机构无法删除");
		menuBar.getMenuItem(UIStrings.MENU_SITE_MANAGE).click();
		Thread.sleep(1000);
		sitePage.deleteSiteBtn(case1.getCenterName()).click();
		Assert.assertTrue(driver.getPageSource().contains(UIStrings.SITE_CANNOT_DELETE));
		sitePage.confirmBtn().click();
		Log.info("验证机构无法删除 - PASS");
		
		Log.info("Step27 - 录入员登入");
		MenuBarAction.logout(driver);
		LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord, UIStrings.MENU_CASE_MANAGE);
		
		Log.info("验证病例和阶段状态");
		checkCaseStageStatus(case1);
		Log.info("验证病例和阶段状态 - PASS");
		
		Log.info("Step28 - 进入阶段1表单");
		casePage.getStageBtnOfCase(case1.getStudyNumber(), stage1).click();
		Thread.sleep(1000);
		
		Log.info("检查病例状态还是已完成");
		Assert.assertEquals(fillinPage.getCaseInfo().get(3).getText(), case1.getStatus());
		Log.info("检查病例状态还是已完成 - PASS");
		
        Log.info("检查控件可编辑");
    	inputs = fillinPage.getTextInputCtrlInForm();
    	for (WebElement input:inputs) {
    		Assert.assertTrue(input.getAttribute("style").isEmpty());
    		Assert.assertNull(input.getAttribute("disabled"));
    	}
        Log.info("检查控件可编辑 - PASS");
        
        Log.info("修改表单的第一个input并保存");
        CaseFillinPageAction.fillinTextInputCtrl(driver, 0, "111");
        fillinPage.getSaveBtn().click();
        
        Log.info("验证修改原因对话框中的信息");
        String rtn = fillinPage.getInfoFromLineOfModify(controls[0]);
        Log.info("验证问题");
        Assert.assertEquals(rtn.split("#")[0], controls[0]);
        Log.info("验证问题 - PASS");
        Log.info("验证修改");
        Assert.assertEquals(rtn.split("#")[1], inputStr + " -> 111");
        Log.info("验证修改 - PASS");
        Log.info("验证修改原因对话框中的信息 - PASS");
        
        Log.info("直接点保存按钮, 验证错误消息");
        fillinPage.getConfirmBtn().click();
        Assert.assertTrue(driver.getPageSource().contains(UIStrings.MODIFY_REASON_REQUIRED));
        Log.info("直接点保存按钮, 验证错误消息 - PASS");
        
        Log.info("填写原因并关闭");
        fillinPage.getInputFromLineOfModify(controls[0]).sendKeys("reason");
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("确认保存成功");
        fillinPage.getSectionLink("test2").click();
        Thread.sleep(1000);
        fillinPage.getSectionLink("test1").click();
        Thread.sleep(1000);
        Assert.assertEquals(fillinPage.getTextInputCtrlInForm().get(0).getAttribute("value"), "111");
        audit1.setOperation(UIStrings.AUDIT_STATUS_WAITFORCHECK);
        
        Log.info("确认质疑记录里添加了修改记录");
        fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_WAITFORCHECK).get(0).click();
        rows = auditPage.getRecordsInAuditDialog();
        cols = rows.get(0).findElements(By.tagName("td"));
        if (cols.get(0).getText().equals(UIStrings.AUDIT_RECORD_TYPE_MODIFY)) {
        	Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_MODIFY);
            Assert.assertEquals(cols.get(1).getText(), inputStr + " -> 111");
            Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        } else {
            Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_MODIFY_REASON);
            Assert.assertEquals(cols.get(1).getText(), "reason");
            Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        }
        cols = rows.get(1).findElements(By.tagName("td"));
        if (cols.get(0).getText().equals(UIStrings.AUDIT_RECORD_TYPE_MODIFY)) {
        	Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_MODIFY);
            Assert.assertEquals(cols.get(1).getText(), inputStr + " -> 111");
            Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        } else {
            Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_MODIFY_REASON);
            Assert.assertEquals(cols.get(1).getText(), "reason");
            Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        }
        auditPage.AuditDialogCloseBtn().click();
        Log.info("确认质疑记录里添加了修改记录 - PASS");
        
        Log.info("修改表单的第2个input并保存");
        CaseFillinPageAction.fillinTextInputCtrl(driver, 1, "111");
        fillinPage.getSaveBtn().click();
        
        Log.info("填写原因并关闭");
        fillinPage.getInputFromLineOfModify(controls[1]).sendKeys("reason");
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("确认出现新的待校验质疑，质疑记录里添加了修改记录");
        fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_WAITFORCHECK).get(1).click();
        rows = auditPage.getRecordsInAuditDialog();
        cols = rows.get(0).findElements(By.tagName("td"));
        if (cols.get(0).getText().equals(UIStrings.AUDIT_RECORD_TYPE_MODIFY)) {
        	Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_MODIFY);
            Assert.assertEquals(cols.get(1).getText(), inputStr + " -> 111");
            Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        } else {
            Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_MODIFY_REASON);
            Assert.assertEquals(cols.get(1).getText(), "reason");
            Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        }
        cols = rows.get(1).findElements(By.tagName("td"));
        if (cols.get(0).getText().equals(UIStrings.AUDIT_RECORD_TYPE_MODIFY)) {
        	Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_MODIFY);
            Assert.assertEquals(cols.get(1).getText(), inputStr + " -> 111");
            Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        } else {
            Assert.assertEquals(cols.get(0).getText(), UIStrings.AUDIT_RECORD_TYPE_MODIFY_REASON);
            Assert.assertEquals(cols.get(1).getText(), "reason");
            Assert.assertEquals(cols.get(2).getText(), menuBar.getUserName());
        }
        auditPage.AuditDialogCloseBtn().click();
        Log.info("确认质疑记录里添加了修改记录 - PASS");
        
        Log.info("进入质疑管理页面, 验证待校验组有2条质疑");
        AuditInfo audit2 = new AuditInfo();
		audit2.setOperation(audit1.getOperation());
		audit2.setAuditor(audit1.getAuditor());
		audit2.setInputter(audit1.getInputter());
		audit2.setCenter(audit1.getCenter());
		audit2.setQuestion("text_2");
		audit2.setStudyNumber(audit1.getStudyNumber());
		audit2.setGroup(audit1.getGroup());
		audit2.setStage(audit1.getStage());
		audit2.setForm(audit1.getForm());
		audit2.setSection(audit1.getSection());
		menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
		Thread.sleep(1000);
        checkAuditInfo(audit1);
        checkAuditInfo(audit2);
        Log.info("验证待校验组有2条质疑 - PASS");
        
		Log.info("验证没有提交按钮");
		Assert.assertNull(fillinPage.getSubmitBtn());
		Log.info("验证没有提交按钮 - PASS");
		
        Log.info("Step29 - 监察员登录并进入质疑管理页面");
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginAuditorName, JsonConf.LoginAuditorPassWord, UIStrings.MENU_AUDIT_MANAGE);
		auditPage.AllAuditRadioBtn().click();
		Thread.sleep(1000);
		auditPage.getStatusGroupBtn(UIStrings.AUDIT_STATUS_WAITFORCHECK).click();
		Thread.sleep(1000);
		
		Log.info("关闭质疑");
		AuditManagePageAction.AddAuditRecordAction(driver, audit1, auditClose, "close", true);
		AuditManagePageAction.AddAuditRecordAction(driver, audit2, auditClose, "close", true);
		audit1.setOperation(UIStrings.AUDIT_RECORD_TYPE_CLOSE);
		
		Log.info("进入表单, 验证没有通过按钮");
		auditPage.getStatusGroupBtn(UIStrings.AUDIT_RECORD_TYPE_CLOSE).click();
		Thread.sleep(1000);
		auditPage.getQuestionLink(audit1).click();
		Thread.sleep(1000);
		Assert.assertNull(fillinPage.getPassBtn());
		Log.info("验证没有通过按钮 - PASS");
		
		Log.info("Step30 - 管理员登入进入表单任务");
		MenuBarAction.logout(driver);
		LoginAndGotoPage(JsonConf.LoginAdminName, JsonConf.LoginAdminPassWord, UIStrings.MENU_FORM_TASK);
		taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_AUDIT).click();
		Thread.sleep(1000);
		taskPage.AllFormRadio().click();
		Thread.sleep(1000);
		
		Log.info("Step31 - 进入表单，通过阶段");
		taskPage.getStageLink(case1.getStudyNumber(), stage1).click();
		Thread.sleep(1000);
		fillinPage.getPassBtn().click();
		Thread.sleep(1000);
		fillinPage.getConfirmBtn().click();
		Thread.sleep(1000);
		
		Log.info("验证阶段1状态变为已通过");
		Assert.assertEquals(fillinPage.getStageStatus(stage1), UIStrings.STAGE_STATUS_PASS);
		case1.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_PASS);
		Log.info("验证阶段1状态变为已通过 - PASS");
		
		MenuBarAction.logout(driver);
		
        Log.info("****************** 监查流程和状态转换的测试 -- END ******************");
    }
    
    /**
     * 终止病例填写流程和状态转换的测试
     * 
     * @throws InterruptedException
     */
    @Test
    public void AbortCaseFillinFlowTest() throws InterruptedException {
        Log.info("****************** 终止病例填写流程和状态转换的测试 -- START ******************");
        
        Log.info("Step1 - 录入员登录并进入病例管理页面");
		LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord, UIStrings.MENU_CASE_MANAGE);
		
		Log.info("Step2 - 录入员添加病例2");
		initCaseInfo(case2);
		CaseManagePageAction.AddCase(driver, case2, "id18");
		
        Log.info("验证病例2添加结果");
        checkAddCaseResults(case2);
        Log.info("验证病例2添加结果 - PASS");
        
        Log.info("Step3 - 点击进入阶段1表单");
        casePage.getStageBtnOfCase(case2.getStudyNumber(), stage1).click();
        
        Log.info("Step4 - 点击终止病例填写, 填写对话框");
        CaseFillinPageAction.abortCaseFillin(driver, stage1);
        
        Log.info("Step5 - 验证病例状态变成已终止");
        Assert.assertEquals(fillinPage.getCaseInfo().get(3).getText(), UIStrings.CASE_STATUS_ABORT);
        case2.setStatus(UIStrings.CASE_STATUS_ABORT);
        Log.info("验证病例状态变成已终止 - PASS");
        
        Log.info("Step6 - 验证控件可编辑");
    	List<WebElement> inputs = fillinPage.getTextInputCtrlInForm();
    	for (WebElement input:inputs) {
    		Assert.assertTrue(input.getAttribute("style").isEmpty());
    		Assert.assertNull(input.getAttribute("disabled"));
    	}
        Log.info("验证控件可编辑 - PASS");
        
        Log.info("Step7 - 保存表单，验证有非空校验");
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        List<String> hints = fillinPage.getHintsInCheckFormDialog();
        for (String hint:hints) {
        	Assert.assertEquals(hint, UIStrings.FORM_CHECK_HINT_NOTNULL);
        }
        fillinPage.getForceSaveBtn().click();
        Thread.sleep(1000);
        Log.info("保存表单，验证有非空校验 - PASS");
        
        Log.info("Step8 - 提交阶段1，验证没有非空校验");
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        Assert.assertFalse(driver.getPageSource().contains(UIStrings.FORM_CHECK_HINT_NOTNULL));
        case2.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_SUBMIT);
        Log.info("提交阶段1，验证没有非空校验 - PASS");
        
        Log.info("检查表单控件不可编辑状态");
    	inputs = fillinPage.getTextInputCtrlInForm();
    	for (WebElement input:inputs) {
    		Assert.assertTrue(input.getAttribute("style").equals("background: rgb(238, 238, 238);"));
    		Assert.assertTrue(input.getAttribute("disabled").equals("true"));
    	}
        Log.info("检查表单控件不可编辑状态 - PASS");
        Log.info("检查表单保存按钮不可点击状态");
        Assert.assertTrue(fillinPage.getSaveBtn().getAttribute("class").contains("disabled"));
        Assert.assertTrue(fillinPage.getSaveToNextBtn().getAttribute("class").contains("disabled"));
        Log.info("检查表单保存按钮不可点击状态 - PASS");
        
        Log.info("Step9 - 到病例管理页面");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(2000);
		
        Log.info("验证病例2状态和阶段状态");
        checkCaseStageStatus(case2);
        Log.info("验证病例2状态和阶段状态 - PASS");
        
        Log.info("Step10 - 到表单任务页面");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(2000);
		
        Log.info("验证表单任务");
        FormTaskInfo formTask2 = new FormTaskInfo();
        formTask2.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        formTask2.setStage(stage1);
        formTask2.setName(case2.getName());
        formTask2.setCaseStatus(case2.getStatus());
        formTask2.setStudyNumber(case2.getStudyNumber());
        formTask2.setGroup(case2.getGroupName());
        formTask2.setCenter(case2.getCenterName());
        formTask2.setInputter(case2.getInputter());
        formTask2.setAuditor("-");
        checkFormTaskInfo(formTask2);
        Log.info("验证表单任务 - PASS");
        
        Log.info("Step11 - 进入阶段1表单");
        taskPage.getStageLink(case2.getStudyNumber(), stage1).click();
        Thread.sleep(1000);
        
        Log.info("Step12 - 点击撤回按钮");
        fillinPage.getWithdrawBtn().click();
        Thread.sleep(1000);
        fillinPage.getRadioInWithdrawDialog("error").click();
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        Log.info("验证控件可编辑");
    	inputs = fillinPage.getTextInputCtrlInForm();
    	for (WebElement input:inputs) {
    		Assert.assertTrue(input.getAttribute("style").isEmpty());
    		Assert.assertNull(input.getAttribute("disabled"));
    	}
        Log.info("验证控件可编辑 - PASS");
        
        Log.info("Step13 - 提交阶段1，验证没有非空校验");
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        Assert.assertFalse(driver.getPageSource().contains(UIStrings.FORM_CHECK_HINT_NOTNULL));
        Log.info("提交阶段1，验证没有非空校验 - PASS");
        
		Log.info("Step14 - 提交阶段2表单");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(1000);
		casePage.getStageBtnOfCase(case2.getStudyNumber(), stage2).click();
		Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, inputStr);
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        case2.setStatusOfStage(stage2, UIStrings.STAGE_STATUS_SUBMIT);
        
        Log.info("验证病例状态还是已终止");
        Assert.assertEquals(fillinPage.getCaseInfo().get(3).getText(), UIStrings.CASE_STATUS_ABORT);
        Log.info("验证病例状态还是已终止 - PASS");
        
        Log.info("Step15 - 到病例管理页面");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(2000);
		
        Log.info("验证病例2状态和阶段状态");
        checkCaseStageStatus(case2);
        Log.info("验证病例2状态和阶段状态 - PASS");
        
        Log.info("Step16 - 到表单任务页面");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(2000);
		
        Log.info("验证表单任务");
        FormTaskInfo formTask3 = new FormTaskInfo();
        formTask3.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        formTask3.setStage(stage2);
        formTask3.setName(case2.getName());
        formTask3.setCaseStatus(case2.getStatus());
        formTask3.setStudyNumber(case2.getStudyNumber());
        formTask3.setGroup(case2.getGroupName());
        formTask3.setCenter(case2.getCenterName());
        formTask3.setInputter(case2.getInputter());
        formTask3.setAuditor("-");
        checkFormTaskInfo(formTask2);
        checkFormTaskInfo(formTask3);
        Log.info("验证表单任务 - PASS");
        
        Log.info("Step17 - 监察员登录并进入表单任务页面");
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginAuditorName, JsonConf.LoginAuditorPassWord, UIStrings.MENU_FORM_TASK);
        taskPage.AllFormRadio().click();
        Thread.sleep(1000);
        Log.info("验证表单任务");
        checkFormTaskInfo(formTask2);
        checkFormTaskInfo(formTask3);
        Log.info("验证表单任务 - PASS");
        
        Log.info("Step18 - 进入阶段1表单");
        taskPage.getStageLink(case2.getStudyNumber(), stage1).click();
        Thread.sleep(1000);
        
        Log.info("Step19 - 添加质疑");
        fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_NOAUDIT).get(0).click();
        Thread.sleep(1000);
        AuditManagePageAction.AddAuditRecordAction(driver, auditQuestion, "add", true);
        case2.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_AUDIT);
        
        Log.info("验证病例状态还是已终止");
        Assert.assertEquals(fillinPage.getCaseInfo().get(3).getText(), UIStrings.CASE_STATUS_ABORT);
        Log.info("验证病例状态还是已终止 - PASS");
        
        Log.info("Step20 - 到表单任务页面");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(2000);
		taskPage.AllFormRadio().click();
		Thread.sleep(1000);
		
        Log.info("验证表单任务");
        formTask2.setStatus(UIStrings.STAGE_STATUS_AUDIT);
        formTask2.setAuditor(menuBar.getUserName());
        formTask3.setAuditor(menuBar.getUserName());
        checkFormTaskInfo(formTask2);
        Log.info("验证表单任务 - PASS");
        
        Log.info("Step21 - 进入阶段1表单");
        taskPage.getStageLink(case2.getStudyNumber(), stage1).click();
        Thread.sleep(1000);
        
        Log.info("Step22 - 关闭质疑, 通过阶段");
        fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_WAITFORFIX).get(0).click();
        Thread.sleep(1000);
        AuditManagePageAction.AddAuditRecordAction(driver, auditClose, "close", true);
        fillinPage.getPassBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(2000);
		taskPage.AllFormRadio().click();
		Thread.sleep(1000);
		taskPage.getStatusGroupBtn(UIStrings.STAGE_STATUS_SUBMIT).click();
		Thread.sleep(1000);
        taskPage.getStageLink(case2.getStudyNumber(), stage2).click();
        Thread.sleep(1000);
        fillinPage.getPassBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        formTask2.setStatus(UIStrings.STAGE_STATUS_PASS);
        formTask3.setStatus(UIStrings.STAGE_STATUS_PASS);
        
        Log.info("验证病例状态还是已终止");
        Assert.assertEquals(fillinPage.getCaseInfo().get(3).getText(), UIStrings.CASE_STATUS_ABORT);
        Log.info("到表单任务页面");
		menuBar.getMenuItem(UIStrings.MENU_FORM_TASK).click();
		Thread.sleep(2000);
		taskPage.AllFormRadio().click();
		Thread.sleep(1000);
        Log.info("验证表单任务");
        checkFormTaskInfo(formTask2);
        checkFormTaskInfo(formTask3);
        Log.info("验证表单任务 - PASS");
        Log.info("验证病例状态还是已终止 - PASS");
        
        Log.info("Step23 - 录入员登录并进入病例管理页面");
        MenuBarAction.logout(driver);
		LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord, UIStrings.MENU_CASE_MANAGE);
		
        Log.info("验证病例2状态还是已终止");
        case2.setStatusOfStage(stage1, UIStrings.STAGE_STATUS_PASS);
        case2.setStatusOfStage(stage2, UIStrings.STAGE_STATUS_PASS);
        checkCaseStageStatus(case2);
        Log.info("验证病例2状态还是已终止 - PASS");
        
		Log.info("验证病例2无法删除");
		casePage.DeleteCaseBtn(case2.getStudyNumber()).click();
		Assert.assertTrue(driver.getPageSource().contains(UIStrings.CASE_CANNOT_DELETE));
		casePage.ConfirmBtn().click();
		Log.info("验证病例2无法删除 - PASS");
		
		Log.info("Step24 - 录入员添加病例3");
		initCaseInfo(case3);
		CaseManagePageAction.AddCase(driver, case3, "id18");
		
        Log.info("验证病例3添加结果");
        checkAddCaseResults(case3);
        Log.info("验证病例3添加结果 - PASS");
        
        Log.info("Step25 - 点击进入阶段1表单");
        casePage.getStageBtnOfCase(case3.getStudyNumber(), stage1).click();
        
        Log.info("Step26 - 点击终止病例填写, 填写对话框");
        CaseFillinPageAction.abortCaseFillin(driver, stage1);
        
        Log.info("Step27 - 验证病例状态变成已终止");
        Assert.assertEquals(fillinPage.getCaseInfo().get(3).getText(), UIStrings.CASE_STATUS_ABORT);
        case3.setStatus(UIStrings.CASE_STATUS_ABORT);
        Log.info("验证病例状态变成已终止 - PASS");
        
        Log.info("Step28 - 到病例管理页面");
		menuBar.getMenuItem(UIStrings.MENU_CASE_MANAGE).click();
		Thread.sleep(2000);
        Log.info("验证病例3状态是已终止");
        checkCaseStageStatus(case3);
        Log.info("验证病例3状态是已终止 - PASS");
        
		Log.info("验证病例3可以删除");
		CaseManagePageAction.DeleteCase(driver, case3.getStudyNumber(), "inputerror");
		Assert.assertNull(casePage.getLineOfCase(case3.getStudyNumber()));
		Log.info("验证病例3可以删除 - PASS");
		
		MenuBarAction.logout(driver);
		
        Log.info("****************** 终止病例填写流程和状态转换的测试 -- END ******************");
    }
    
    /**
     * 病例填写和监查流程特殊问题的验证
     * 
     * @throws InterruptedException
     */
    @Test
    public void CaseAndAuditSpecFlowTest() throws InterruptedException {
        Log.info("****************** 病例填写和监查流程特殊问题的验证 -- START ******************");
        
        Log.info("Step1 - 录入员登录并进入病例管理页面");
		LoginAndGotoPage(JsonConf.LoginInputterName, JsonConf.LoginInputterPassWord, UIStrings.MENU_CASE_MANAGE);
		
		Log.info("Step2 - 录入员添加病例4");
		case4.setStatus(UIStrings.CASE_STATUS_INPROGRESS);
		case4.setInputter(menuBar.getUserName());
		case4.addStageStatus(stage3, UIStrings.STAGE_STATUS_NEW);
		CaseManagePageAction.AddCase(driver, case4, "id18");
		
        Log.info("验证病例4添加结果");
        checkAddCaseResults(case4);
        Log.info("验证病例4添加结果 - PASS");
        
        Log.info("Step3 - 点击进入阶段3表单");
        casePage.getStageBtnOfCase(case4.getStudyNumber(), stage3).click();
        Thread.sleep(1000);
        
        Log.info("Step4 - 点击提交按钮");
        fillinPage.getSubmitBtn().click();
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step5 - 点击test2分页的text_1的修改链接");
        fillinPage.getLinkInLineOfSubmitCheckDialog("test2", "text_1").click();
        Thread.sleep(1000);
        Log.info("验证跳转到正确表单");
        Assert.assertEquals(fillinPage.getActiveSectionName(), "test2");
        Log.info("验证跳转到正确表单 - PASS");
        
        Log.info("Step6 - 填写表单并提交");
        CaseFillinPageAction.fillinTextInputCtrl(driver, inputStr);
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSectionLink("test1").click();
        Thread.sleep(1000);
        CaseFillinPageAction.fillinTextInputCtrl(driver, inputStr);
        fillinPage.getSaveBtn().click();
        Thread.sleep(1000);
        fillinPage.getSubmitBtn().click();
        Thread.sleep(1000);
        fillinPage.getConfirmBtn().click();
        Thread.sleep(1000);
        
        Log.info("Step7 - 监察员登录并进入表单任务页面");
        MenuBarAction.logout(driver);
        LoginAndGotoPage(JsonConf.LoginAuditorName, JsonConf.LoginAuditorPassWord, UIStrings.MENU_FORM_TASK);
        taskPage.AllFormRadio().click();
        Thread.sleep(1000);
        Log.info("验证表单任务");
        FormTaskInfo formTask4 = new FormTaskInfo();
        formTask4.setStatus(UIStrings.STAGE_STATUS_SUBMIT);
        formTask4.setStage(stage3);
        formTask4.setName(case4.getName());
        formTask4.setCaseStatus(case4.getStatus());
        formTask4.setStudyNumber(case4.getStudyNumber());
        formTask4.setGroup(case4.getGroupName());
        formTask4.setCenter(case4.getCenterName());
        formTask4.setInputter(case4.getInputter());
        formTask4.setAuditor("-");
        checkFormTaskInfo(formTask4);
        Log.info("验证表单任务 - PASS");
        
        Log.info("Step8 - 进入阶段3表单");
        taskPage.getStageLink(case4.getStudyNumber(), stage3).click();
        Thread.sleep(1000);
        
        Log.info("Step9 - 添加质疑");
        fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_NOAUDIT).get(0).click();
        Thread.sleep(1000);
        AuditManagePageAction.AddAuditRecordAction(driver, auditQuestion, "add", true);
        fillinPage.getSectionLink("test2").click();
        Thread.sleep(1000);
        fillinPage.getAuditBtnInForm(UIStrings.AUDIT_STATUS_NOAUDIT).get(0).click();
        Thread.sleep(1000);
        AuditManagePageAction.AddAuditRecordAction(driver, auditQuestion, "add", true);
        case4.setStatusOfStage(stage3, UIStrings.STAGE_STATUS_AUDIT);
        formTask4.setAuditor(menuBar.getUserName());

        Log.info("Step10 - 到质疑管理页面");
        menuBar.getMenuItem(UIStrings.MENU_AUDIT_MANAGE).click();
        Thread.sleep(2000);
        auditPage.getStatusGroupBtn(UIStrings.AUDIT_STATUS_WAITFORFIX).click();
        Thread.sleep(1000);
        Log.info("验证不会出现2条相同的质疑");
        AuditInfo audit3 = new AuditInfo();
		audit3.setOperation(UIStrings.AUDIT_STATUS_WAITFORFIX);
		audit3.setAuditor(formTask4.getAuditor());
		audit3.setInputter(formTask4.getInputter());
		audit3.setCenter(case4.getCenterName());
		audit3.setQuestion("text_1");
		audit3.setStudyNumber(case4.getStudyNumber());
		audit3.setGroup(formTask4.getGroup());
		audit3.setStage(formTask4.getStage());
		audit3.setForm("flowtest3");
		audit3.setSection("test1");
        AuditInfo audit4 = new AuditInfo();
		audit4.setOperation(UIStrings.AUDIT_STATUS_WAITFORFIX);
		audit4.setAuditor(formTask4.getAuditor());
		audit4.setInputter(formTask4.getInputter());
		audit4.setCenter(case4.getCenterName());
		audit4.setQuestion("text_1");
		audit4.setStudyNumber(case4.getStudyNumber());
		audit4.setGroup(formTask4.getGroup());
		audit4.setStage(formTask4.getStage());
		audit4.setForm("flowtest3");
		audit4.setSection("test2");
        Assert.assertEquals(auditPage.getCountOfAudit(audit3), 1);
        Assert.assertEquals(auditPage.getCountOfAudit(audit4), 1);
        Log.info("验证不会出现2条相同的质疑 - PASS");
        
        Log.info("Step11 - 点击test2分页的问题的链接");
        auditPage.getQuestionLink(audit4).click();
        Thread.sleep(1000);
        Log.info("验证跳转到正确表单");
        Assert.assertEquals(fillinPage.getActiveSectionName(), "test2");
        Log.info("验证跳转到正确表单 - PASS");
        
        Log.info("****************** 病例填写和监查流程特殊问题的验证 -- END ******************");
    }
}