package cn.natureself.componentObjects;

import java.util.HashMap;
import java.util.Map;


/**
 * 病例信息类
 * 
 * @author Andy
 */

public class CaseInfo {

    public String studynumber;
    public String name;
    public String idtype;
    public String idnumber;
    public String centername;
    public String groupname;
    public String status;
    public String inputter;
    public String entertime;
    public Map<String, String> stagestatus;
    public String randomnumber;

    public CaseInfo() {
        this.studynumber = "";
        this.name = "";
        this.idtype = "";
        this.idnumber = "";
        this.centername = "";
        this.groupname = "";
        this.status = "";
        this.inputter = "";
        this.entertime = "";
        this.stagestatus = new HashMap<>();
        this.randomnumber = "";
    }

    public CaseInfo(String centername, String groupname) {
        this.studynumber = "";
        this.name = "";
        this.idtype = "";
        this.idnumber = "";
        this.centername = centername;
        this.groupname = groupname;
        this.status = "";
        this.inputter = "";
        this.entertime = "";
        this.stagestatus = new HashMap<>();
        this.randomnumber = "";
    }
    
    public CaseInfo(String centername) {
        this.studynumber = "";
        this.name = "";
        this.idtype = "";
        this.idnumber = "";
        this.centername = centername;
        this.groupname = "";
        this.status = "";
        this.inputter = "";
        this.entertime = "";
        this.stagestatus = new HashMap<>();
        this.randomnumber = "";
    }
    
    public CaseInfo(String studynumber, String name, String idtype, 
            String idnumber, String centername, String groupname) {
        this.studynumber = studynumber;
        this.name = name;
        this.idtype = idtype;
        this.idnumber = idnumber;
        this.centername = centername;
        this.groupname = groupname;
        this.status = "";
        this.inputter = "";
        this.entertime = "";
        this.stagestatus = new HashMap<>();
        this.randomnumber = "";
    }
    
    public CaseInfo(String studynumber, String name, String idtype, 
            String idnumber, String centername) {
        this.studynumber = studynumber;
        this.name = name;
        this.idtype = idtype;
        this.idnumber = idnumber;
        this.centername = centername;
        this.groupname = "";
        this.status = "";
        this.inputter = "";
        this.entertime = "";
        this.stagestatus = new HashMap<>();
        this.randomnumber = "";
    }
    
    public String getStudyNumber() {
        return this.studynumber;
    }
    
    public void setStudyNumber(String studynumber) {
        this.studynumber = studynumber;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getIDType() {
        return this.idtype;
    }
    
    public void setIDType(String idtype) {
        this.idtype = idtype;
    }
    
    public String getIDNumber() {
        return this.idnumber;
    }
    
    public void setIDNumber(String idnumber) {
        this.idnumber = idnumber;
    }
    
    public String getCenterName() {
        return this.centername;
    }
    
    public void setCenterName(String centername) {
        this.centername = centername;
    }
    
    public String getGroupName() {
        return this.groupname;
    }
    
    public void setGroupName(String groupname) {
        this.groupname = groupname;
    }
    
    public String getInputter() {
        return this.inputter;
    }
    
    public void setInputter(String inputter) {
        this.inputter = inputter;
    }
    
    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getEnterTime() {
        return this.entertime;
    }
    
    public void setEnterTime(String entertime) {
        this.entertime = entertime;
    }
    
    public Map<String, String> getStageStatus() {
        return this.stagestatus;
    }
    
    public void addStageStatus(String stage, String status) {
        if (this.stagestatus == null) {
            this.stagestatus = new HashMap<>();
        }
        this.stagestatus.put(stage, status);
    }
    
    public String getStatusOfStage(String stage) {
        return this.stagestatus.get(stage);
    }
    
    public void setStatusOfStage(String stage, String status) {
        this.stagestatus.put(stage, status);
    }
    
    public String getRandomNumber() {
        return this.randomnumber;
    }
    
    public void setRandomNumber(String randomnumber) {
        this.randomnumber = randomnumber;
    }
}