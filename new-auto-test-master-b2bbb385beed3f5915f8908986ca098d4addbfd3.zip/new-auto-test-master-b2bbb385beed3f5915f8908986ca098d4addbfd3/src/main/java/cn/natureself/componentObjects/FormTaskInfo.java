package cn.natureself.componentObjects;

/**
 * 表单任务信息类
 * 
 * @author Andy
 */

public class FormTaskInfo {

	public String status;
    public String stage;
    public String name;
    public String caseStatus;
    public String studynumber;
    public String group;
    public String center;
    public String inputter;
    public String auditor;

    public FormTaskInfo() {
    	this.status = "";
        this.stage = "";
        this.name = "";
        this.caseStatus = "";
        this.studynumber = "";
        this.group = "";
        this.center = "";
        this.inputter = "";
        this.auditor = "";
    }
    
    public FormTaskInfo(String status, String stage, String name, String casestatus, 
            String studynumber, String group, String center, 
            String inputter, String auditor) {
        this.stage = stage;
        this.name = name;
        this.status = status;
        this.caseStatus = casestatus;
        this.studynumber = studynumber;
        this.group = group;
        this.center = center;
        this.inputter = inputter;
        this.auditor = auditor;
    }
    
    public FormTaskInfo(String status, String stage, String name, String casestatus, 
            String studynumber, String group, String center, String inputter) {
        this.stage = stage;
        this.name = name;
        this.status = status;
        this.caseStatus = casestatus;
        this.studynumber = studynumber;
        this.group = group;
        this.center = center;
        this.inputter = inputter;
        this.auditor = "";
    }
    
    public String getStudyNumber() {
        return this.studynumber;
    }
    
    public void setStudyNumber(String studynumber) {
        this.studynumber = studynumber;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getStage() {
        return this.stage;
    }
    
    public void setStage(String stage) {
        this.stage = stage;
    }
    
    public String getCenter() {
        return this.center;
    }
    
    public void setCenter(String center) {
        this.center = center;
    }
    
    public String getGroup() {
        return this.group;
    }
    
    public void setGroup(String group) {
        this.group = group;
    }
    
    public String getInputter() {
        return this.inputter;
    }
    
    public void setInputter(String inputter) {
        this.inputter = inputter;
    }
    
    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getCaseStatus() {
        return this.caseStatus;
    }
    
    public void setCaseStatus(String status) {
        this.caseStatus = status;
    }
    
    public String getAuditor() {
        return this.auditor;
    }
    
    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }
    
}