package cn.natureself.componentObjects;

import java.util.ArrayList;
import java.util.List;

/**
 * 阶段信息类
 * 
 * @author Andy
 */

public class StageInfo {
    
    public String name;
    public List<FormInfo> formList;
    
    public StageInfo() {
        this.name = "";
        this.formList = new ArrayList<>();
    }
    
    public StageInfo(String name, List<FormInfo> formList) {
        this.name = "";
        this.formList = formList;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public List<FormInfo> getAchievement() {
        return this.formList;
    }
    
    public void addForm(FormInfo form) {
        if(this.formList == null) {
            this.formList = new ArrayList<>();
        }
        this.formList.add(form);
    }
}