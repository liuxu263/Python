package cn.natureself.componentObjects;

import java.util.ArrayList;
import java.util.List;

/**
 * 项目信息类
 * 
 * @author Andy
 */

public class ProjectInfo {
    
    public String name;
    public String startTime;
    public String status;
    public String caseNumber;
    public String type;
    public List<FormInfo> formList;
    public List<SiteInfo> siteList;
    public List<RoleInfo> roleList;
    public List<CaseInfo> caseList;
    public List<GroupInfo> groupList;
    
    public ProjectInfo() {
        this.name = "";
        this.startTime = "";
        this.status = "";
        this.caseNumber = "";
        this.type = "";
        this.formList = new ArrayList<>();
        this.siteList = new ArrayList<>();
        this.roleList = new ArrayList<>();
        this.caseList = new ArrayList<>();
        this.groupList = new ArrayList<>();
    }
    
    public ProjectInfo(String name, String startTime, String status, String caseNumber, String type,
            List<FormInfo> formList, List<SiteInfo> siteList, List<RoleInfo> roleList, List<CaseInfo> caseList,
            List<GroupInfo> groupList) {
        this.name = name;
        this.startTime = startTime;
        this.status = status;
        this.caseNumber = caseNumber;
        this.type = type;
        this.formList = formList;
        this.siteList = siteList;
        this.roleList = roleList;
        this.caseList = caseList;
        this.groupList = groupList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<FormInfo> getFormList() {
        return formList;
    }

    public void addForm(FormInfo form) {
        if(this.formList == null) {
            this.formList = new ArrayList<>();
        }
        this.formList.add(form);
    }

    public List<SiteInfo> getSiteList() {
        return siteList;
    }
    
    public void addSite(SiteInfo site) {
        if(this.siteList == null) {
            this.siteList = new ArrayList<>();
        }
        this.siteList.add(site);
    }

    public List<RoleInfo> getRoleList() {
        return roleList;
    }

    public void addRole(RoleInfo role) {
        if(this.roleList == null) {
            this.roleList = new ArrayList<>();
        }
        this.roleList.add(role);
    }

    public List<CaseInfo> getCaseList() {
        return caseList;
    }

    public void addCase(CaseInfo caseInfo) {
        if(this.caseList == null) {
            this.caseList = new ArrayList<>();
        }
        this.caseList.add(caseInfo);
    }

    public List<GroupInfo> getGroupList() {
        return groupList;
    }

    public void addGroup(GroupInfo group) {
        if(this.groupList == null) {
            this.groupList = new ArrayList<>();
        }
        this.groupList.add(group);
    }
    
}