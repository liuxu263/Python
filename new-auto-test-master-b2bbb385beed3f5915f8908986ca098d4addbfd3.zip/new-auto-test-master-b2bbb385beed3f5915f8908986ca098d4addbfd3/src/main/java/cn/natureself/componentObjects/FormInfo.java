package cn.natureself.componentObjects;

/**
 * 表单信息类
 * 
 * @author Andy
 */

public class FormInfo {
    
    public String name;
    public String uid;
    public String updateTime;
    
    public FormInfo() {
        this.name = "";
        this.uid = "";
        this.updateTime = "";
    }
    
    public FormInfo(String name, String uid, String time) {
        this.name = name;
        this.uid = uid;
        this.updateTime = time;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getUid() {
        return this.uid;
    }
    
    public void setUid(String uid) {
        this.uid = uid;
    }
    
    public String getUpdateTime() {
        return this.updateTime;
    }
    
    public void setUpdateTime(String time) {
        this.updateTime = time;
    }
}