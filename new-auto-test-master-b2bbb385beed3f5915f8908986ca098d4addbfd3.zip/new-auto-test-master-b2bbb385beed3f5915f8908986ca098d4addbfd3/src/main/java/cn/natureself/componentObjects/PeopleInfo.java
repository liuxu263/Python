package cn.natureself.componentObjects;

import java.util.ArrayList;
import java.util.List;


/**
 * 用户个人信息类
 * @author Andy
 */

public class PeopleInfo {
    
    public String email;
    public String password;
    public String name;
    public String phone;
    public String department;
    public String title;
    public String site;
    public String address;
    public List<String> area;
    public List<Achievement> achievements;
    
    public PeopleInfo() {
        this.email = "";
        this.password = "";
        this.name = "";
        this.phone = "";
        this.department = "";
        this.title = "";
        this.site = "";
        this.address = "";
        this.area = new ArrayList<>();
        this.achievements = new ArrayList<>();
    }
    
    public PeopleInfo(String email, String password, String name, String phone, String department, String title, String site, String address) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.department = department;
        this.title = title;
        this.site = site;
        this.address = address;
        this.area = new ArrayList<>();
        this.achievements = new ArrayList<>();
    }
    
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getPhone() {
        return this.phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getDepartment() {
        return this.department;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getSite() {
        return this.site;
    }
    
    public void setSite(String site) {
        this.site = site;
    }
    
    public String getAddress() {
        return this.address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public List<String> getArea() {
        return this.area;
    }
    
    public void addArea(String area) {
        if (this.area == null) {
            this.area = new ArrayList<>();
        }
        this.area.add(area);
    }
    
    public List<Achievement> getAchievement() {
        return this.achievements;
    }
    
    public void addAchievement(Achievement achievement) {
        if(this.achievements == null) {
            this.achievements = new ArrayList<>();
        }
        this.achievements.add(achievement);
    }
    
}