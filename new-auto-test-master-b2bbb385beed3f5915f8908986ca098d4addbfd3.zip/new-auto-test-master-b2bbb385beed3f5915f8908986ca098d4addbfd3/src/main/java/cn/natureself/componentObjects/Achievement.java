package cn.natureself.componentObjects;

/**
 * 个人研究成果信息类
 * 
 * @author Andy
 */

public class Achievement {

    public String type;
    public String title;
    public String desc;
    public String link;

    public Achievement() {
        this.type = "";
        this.title = "";
        this.desc = "";
        this.link = "";
    }

    public Achievement(String type, String title, String desc, String link) {
        this.type = type;
        this.title = title;
        this.desc = desc;
        this.link = link;
    }
    
    public String getType() {
        return this.type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDesc() {
        return this.desc;
    }
    
    public void setDesc(String desc) {
        this.desc = desc;
    }
    
    public String getLink() {
        return this.link;
    }
    
    public void setLink(String link) {
        this.link = link;
    }
}