package cn.natureself.componentObjects;

import java.util.List;
import java.util.ArrayList;

/**
 * 人员信息类
 * 
 * @author Andy
 */

public class RoleInfo {

    public String name;
    public String email;
    public String site;
    public String right;
    public String phone;
    public List<String> centers;

    public RoleInfo() {
        this.name = "";
        this.email = "";
        this.site = "";
        this.right = "";
        this.phone = "";
        this.centers = new ArrayList<>();
    }
    
    public RoleInfo(String name, String email, String site, String right, String phone, List<String> centers) {
        this.name = name;
        this.email = email;
        this.site = site;
        this.right = right;
        this.phone = phone;
        this.centers = centers;
    }
    
    public RoleInfo(String email, String right, List<String> centers) {
        this.name = "";
        this.email = email;
        this.site = "";
        this.right = right;
        this.phone = "";
        this.centers = centers;
    }
    
    public RoleInfo(String email, String right) {
        this.name = "";
        this.email = email;
        this.site = "";
        this.right = right;
        this.phone = "";
        this.centers = new ArrayList<>();
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getSite() {
        return this.site;
    }
    
    public void setSite(String site) {
        this.site = site;
    }
    
    public String getRight() {
        return this.right;
    }
    
    public void setRight(String right) {
        this.right = right;
    }
    
    public String getPhone() {
        return this.phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public List<String> getCenter() {
        return this.centers;
    }
    
    public void addCenter(String name) {
        if (this.centers == null) {
            this.centers = new ArrayList<>();
        }
        this.centers.add(name);
    }
    
}