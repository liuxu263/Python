package cn.natureself.componentObjects;

import java.util.ArrayList;
import java.util.List;

/**
 * 分组信息类
 * 
 * @author Andy
 */

public class GroupInfo {
    
    public String name;
    public List<StageInfo> stageList;
    
    public GroupInfo() {
        this.name = "";
        this.stageList = new ArrayList<>();
    }
    
    public GroupInfo(String name, List<StageInfo> stageList) {
        this.name = "";
        this.stageList = stageList;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public List<StageInfo> getAchievement() {
        return this.stageList;
    }
    
    public void addStage(StageInfo stage) {
        if(this.stageList == null) {
            this.stageList = new ArrayList<>();
        }
        this.stageList.add(stage);
    }
}