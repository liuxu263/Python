package cn.natureself.componentObjects;

/**
 * 机构信息类
 * 
 * @author Andy
 */

public class SiteInfo {

    public String name;
    public String province;
    public String type;
    public String id;
    public String casenumber;

    public SiteInfo() {
        this.name = "";
        this.province = "";
        this.type = "";
        this.id = "";
        this.casenumber = "";
    }
    
    public SiteInfo(String name, String id, String casenumber) {
        this.name = name;
        this.province = "";
        this.type = "";
        this.id = id;
        this.casenumber = casenumber;
    }
    
    public SiteInfo(String name, String province, String type, String id, String casenumber) {
        this.name = name;
        this.province = province;
        this.type = type;
        this.id = id;
        this.casenumber = casenumber;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getProvince() {
        return this.province;
    }
    
    public void setProvince(String province) {
        this.province = province;
    }
    
    public String getType() {
        return this.type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getID() {
        return this.id;
    }
    
    public void setID(String id) {
        this.id = id;
    }
    
    public String getCaseNumber() {
        return this.casenumber;
    }
    
    public void setCaseNumber(String casenumber) {
        this.casenumber = casenumber;
    }
}