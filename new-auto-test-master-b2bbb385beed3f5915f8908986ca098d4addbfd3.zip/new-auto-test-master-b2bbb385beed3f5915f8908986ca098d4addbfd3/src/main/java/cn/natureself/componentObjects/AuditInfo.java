package cn.natureself.componentObjects;

/**
 * 质疑信息类
 * 
 * @author Andy
 */

public class AuditInfo {

    public String operation;
    public String question;
    public String updatetime;
    public String form;
    public String section;
    public String stage;
    public String studynumber;
    public String group;
    public String center;
    public String inputter;
    public String auditor;

    public AuditInfo() {
        this.stage = "";
        this.operation = "";
        this.question = "";
        this.studynumber = "";
        this.group = "";
        this.center = "";
        this.inputter = "";
        this.auditor = "";
        this.form = "";
        this.section = "";
        this.updatetime = "";
    }
    
    public AuditInfo(String stage, String operation, String question, 
            String studynumber, String group, String center, String inputter, 
            String auditor, String form, String section, String updatetime) {
        this.stage = stage;
        this.operation = operation;
        this.question = question;
        this.studynumber = studynumber;
        this.group = group;
        this.center = center;
        this.inputter = inputter;
        this.auditor = auditor;
        this.form = form;
        this.section = section;
        this.updatetime = updatetime;
    }
    
    public String getStudyNumber() {
        return this.studynumber;
    }
    
    public void setStudyNumber(String studynumber) {
        this.studynumber = studynumber;
    }
    
    public String getOperation() {
        return this.operation;
    }
    
    public void setOperation(String operation) {
        this.operation = operation;
    }
    
    public String getStage() {
        return this.stage;
    }
    
    public void setStage(String stage) {
        this.stage = stage;
    }
    
    public String getCenter() {
        return this.center;
    }
    
    public void setCenter(String center) {
        this.center = center;
    }
    
    public String getGroup() {
        return this.group;
    }
    
    public void setGroup(String group) {
        this.group = group;
    }
    
    public String getInputter() {
        return this.inputter;
    }
    
    public void setInputter(String inputter) {
        this.inputter = inputter;
    }
    
    public String getQuestion() {
        return this.question;
    }
    
    public void setQuestion(String question) {
        this.question = question;
    }
    
    public String getAuditor() {
        return this.auditor;
    }
    
    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }
    
    public String getForm() {
        return this.form;
    }
    
    public void setForm(String form) {
        this.form = form;
    }
    
    public String getSection() {
        return this.section;
    }
    
    public void setSection(String section) {
        this.section = section;
    }
    
    public String getUpdateTime() {
        return this.updatetime;
    }
    
    public void setUpdateTime(String updatetime) {
        this.updatetime = updatetime;
    }
    
}