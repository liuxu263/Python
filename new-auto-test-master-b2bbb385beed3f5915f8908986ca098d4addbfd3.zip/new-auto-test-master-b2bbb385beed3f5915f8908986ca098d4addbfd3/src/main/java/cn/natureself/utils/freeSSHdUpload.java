package cn.natureself.utils;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class freeSSHdUpload {

	// 上传upload控件的文件
	public static void upload_widgets(String hostname) {

		try {
			// 建立连接
			Connection conn = new Connection(hostname);
			conn.connect();
			// 利用用户名和密码进行授权
			boolean isAuthenticated = conn.authenticateWithPassword(JsonConf.freeSSHUserName, JsonConf.freeSSHPassWord);
			if (isAuthenticated == false) {
				throw new IOException("Authorication failed");
			}
			// 打开会话
			Session sess = conn.openSession();
			// 执行命令
			sess.execCommand("C:\\autoit\\autoit_upload.exe");
			InputStream stdout = new StreamGobbler(sess.getStdout());
			BufferedReader br = new BufferedReader(new InputStreamReader(stdout));
			while (true) {
				String line = br.readLine();
				if (line == null)
					break;
			}
			sess.close();
			conn.close();
			br.close();
		} catch (IOException e) {
			throw new RuntimeException("can not access the remote machine");
		}
	}

	// 检查upload控件的下载及删除本地文件
	public static void checkAndDel(String hostname) {
		try {
			// 建立连接
			Connection conn = new Connection(hostname);
			conn.connect();
			// 利用用户名和密码进行授权
			boolean isAuthenticated = conn.authenticateWithPassword(JsonConf.freeSSHUserName, JsonConf.freeSSHPassWord);
			if (isAuthenticated == false) {
				throw new IOException("Authorication failed");
			}
			// 打开会话
			Session sess = conn.openSession();
			// 执行命令
			sess.execCommand("C:\\autoit\\delDownload.bat");
			InputStream stdout = new StreamGobbler(sess.getStdout());
			BufferedReader br = new BufferedReader(new InputStreamReader(stdout));
			int i = 0;
			while (true) {
				String line = br.readLine();
				if (line == null)
					break;
				i++;
				if (i == 3) {
					sess.close();
					conn.close();
					br.close();
					System.out.println("[error] : upload下载文件删除错误");
					throw new RuntimeException("some thing wrong in upLoad");
				}
			}
			sess.close();
			conn.close();
			br.close();
		} catch (IOException e) {
			throw new RuntimeException("can not access the remote machine");
		}
	}

	// 上传随机表
	public static void upload_random_form(String hostname) {
		try {
			// 建立连接
			Connection conn = new Connection(hostname);
			conn.connect();
			// System.out.println("connected : "+hostname);
			// 利用用户名和密码进行授权
			boolean isAuthenticated = conn.authenticateWithPassword(JsonConf.freeSSHUserName, JsonConf.freeSSHPassWord);
			if (isAuthenticated == false) {
				throw new IOException("Authorication failed");
			}
			// 打开会话
			Session sess = conn.openSession();
			// System.out.println("Session opened");
			// 执行命令
			sess.execCommand("C:\\autoit\\upload_random_form.exe");
			InputStream stdout = new StreamGobbler(sess.getStdout());
			BufferedReader br = new BufferedReader(new InputStreamReader(stdout));
			while (true) {
				String line = br.readLine();
				if (line == null)
					break;
			}
			sess.close();
			conn.close();
			br.close();
		} catch (IOException e) {
			throw new RuntimeException("can not access the remote machine");
		}
	}

	// 上传表单
	public static void upload_form(String hostname, String autoit) {
		try {
			// 建立连接
			Connection conn = new Connection(hostname);
			conn.connect();
			// 利用用户名和密码进行授权
			boolean isAuthenticated = conn.authenticateWithPassword(JsonConf.freeSSHUserName, JsonConf.freeSSHPassWord);
			if (isAuthenticated == false) {
				throw new IOException("Authorication failed");
			}
			// 打开会话
			Session sess = conn.openSession();
			// 执行命令
			sess.execCommand("C:\\autoit\\" + autoit);
			InputStream stdout = new StreamGobbler(sess.getStdout());
			BufferedReader br = new BufferedReader(new InputStreamReader(stdout));
			while (true) {
				String line = br.readLine();
				if (line == null)
					break;
			}
			sess.close();
			conn.close();
			br.close();
		} catch (IOException e) {
			throw new RuntimeException("can not access the remote machine");
		}
	}

	// (还有问题:需修改删除的脚本)
	// 检查表单form1的下载及删除本地文件
	public static void checkAndDel_form1(String hostname) {
		try {
			// 建立连接
			Connection conn = new Connection(hostname);
			conn.connect();
			boolean isAuthenticated = conn.authenticateWithPassword(JsonConf.freeSSHUserName, JsonConf.freeSSHPassWord);
			if (isAuthenticated == false) {
				throw new IOException("Authorication failed");
			}
			// 打开会话
			Session sess = conn.openSession();
			// 执行命令
			sess.execCommand("D:\\delDownload.bat");// 这步要修改
			InputStream stdout = new StreamGobbler(sess.getStdout());
			BufferedReader br = new BufferedReader(new InputStreamReader(stdout));
			int i = 0;
			while (true) {
				String line = br.readLine();
				if (line == null)
					break;
				System.out.println(line);
				i++;
				if (i == 3)// 报错情况下是3,正常情况下是2
				{
					sess.close();
					conn.close();
					br.close();
					System.out.println("[error] : upload下载文件删除错误");
					throw new RuntimeException("some thing wrong in upLoad");
				}
			}
			sess.close();
			conn.close();
			br.close();
		} catch (IOException e) {
			throw new RuntimeException("can not access the remote machine");
		}
	}

}