package cn.natureself.utils;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import cn.natureself.testScripts.BasicTest;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Test Case失败时截图，测试结束时输出summary信息
 */
public class TestNGListener extends TestListenerAdapter {

    public static Logger log = JsonConf.Log;
    
    @Override
    public void onTestFailure(ITestResult tr) {
        BasicTest test = (BasicTest) tr.getInstance();
        test.getLogger().error("FAIL - Test "+ tr.getName() + " Failed!");
        log.error("FAIL - Test "+ tr.getName() + " Failed!");
        super.onTestFailure(tr);
        log.info("Take screenShot");
        test.getLogger().info("Take screenShot");
        takeScreenShot(tr);
    }

    @Override
    public void onFinish(ITestContext testContext) {
        log.info("Test completed on: " + testContext.getEndDate().toString());
        log.info("");
        
        int total = testContext.getAllTestMethods().length;
        int pass = testContext.getPassedTests().size();
        int fail = testContext.getFailedTests().size();
        int skip = testContext.getSkippedTests().size();
        int passrate = (pass == 0)? 0 : pass * 100 / total;
        int failrate = (fail == 0)? 0 : fail * 100 / total;
        int skiprate = (skip == 0)? 0 : skip * 100 / total;
        
        log.info("======================================");
        log.info("TEST RUN SUMMARY RESULTS:");
        log.info("TESTS TOTAL: " + Integer.toString(total));
        log.info("TESTS PASSED: " + Integer.toString(pass) + "  " + Integer.toString(passrate) + "%");
        log.info("TESTS FAILED: " + Integer.toString(fail) + "  " + Integer.toString(failrate) + "%");
        log.info("TESTS NOT RUN: " + Integer.toString(skip) + "  " + Integer.toString(skiprate) + "%");
        log.info("======================================");
        log.info("");
        log.info("======================================");
        log.info("");
        log.info("PASSED TEST CASES:");
        testContext.getPassedTests().getAllResults().forEach(result -> {
            log.info(result.getName());
        });
        log.info("");

        log.info("FAILED TEST CASES:");
        testContext.getFailedTests().getAllResults().forEach(result -> {
            log.info(result.getName());
        });
        log.info("");
        
        log.info("SKIPPED TEST CASES:");
        testContext.getSkippedTests().getAllResults().forEach(result -> {
            log.info(result.getName());
        });
        log.info("");
        log.info("======================================");
    }

    @Override
    public void onStart(ITestContext arg0) {
        log.info("");
        log.info("Started testing on: " + arg0.getStartDate().toString());
        log.info("");
    }

    @Override
    public void onTestSkipped(ITestResult arg0) {
        log.info("");
        log.info("Skipped Test: " + arg0.getName());
        log.info("");

    }

    @Override
    public void onTestStart(ITestResult arg0) {
        log.info("");
        log.info("Testing: " + arg0.getName());
        log.info("");

    }

    @Override
    public void onTestSuccess(ITestResult arg0) {
        long timeTaken = ((arg0.getEndMillis() - arg0.getStartMillis()));
        log.info("");
        log.info("Tested: " + arg0.getName() + " Time taken:" + timeTaken + " ms");
        log.info("");

    }

    private void takeScreenShot(ITestResult tr) {
        BasicTest tmp = (BasicTest) tr.getInstance();
        WebDriver driver = tmp.getDriver();
        // log.error("Title:" + driver.getTitle());

        SimpleDateFormat sf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
        Calendar cal = Calendar.getInstance();
        Date date = cal.getTime();
        String dateStr = sf.format(date);
        String path = tr.getName() + "_" + dateStr + ".png";

        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        // Now you can do whatever you need to do with it, for example copy
        try {
            // log.info("save snapshot path is:" + currentPath + path);
            File pic = new File(JsonConf.resultsDir + "/" + path);
            FileUtils.copyFile(scrFile, pic);
            log.info("Screenshot has been taken: " + pic);
            tmp.getLogger().info("Screenshot has been taken: " + pic);
        } catch (Exception e) {
            log.error("Can't save screenshot");
            e.printStackTrace();
        }
    }
}
