package cn.natureself.utils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.FileNotFoundException;
import java.io.FileReader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * Created by lion on 2017/6/26.
 */

// 此类管理代码中各项值
// 在没有文件的时候使用默认值

// 默认加载 test.json
public class JsonConf {
    public static String LoginSystemURL = "http://v-test-1.bjo.natureself.site:3000/#!/signin";

    public static String LoginInputterName = "inputter@newauto.com";
    public static String LoginInputterPassWord = "password";
    
    public static String LoginInputterName2 = "inputter2@newauto.com";
    public static String LoginInputterPassWord2 = "password";
    
    public static String LoginInputterName3 = "inputter3@newauto.com";
    public static String LoginInputterPassWord3 = "password";

    public static String LoginCenterAdminName = "centeradmin@newauto.com";
    public static String LoginCenterAdminPassWord = "password";
    
    public static String LoginCenterAdminName2 = "centeradmin2@newauto.com";
    public static String LoginCenterAdminPassWord2 = "password";

    public static String LoginAuditorName = "auditor@newauto.com";
    public static String LoginAuditorPassWord = "password";
    
    public static String LoginAuditorName2 = "auditor2@newauto.com";
    public static String LoginAuditorPassWord2 = "password";
    
    public static String LoginAuditorName3 = "auditor3@newauto.com";
    public static String LoginAuditorPassWord3 = "password";

    public static String LoginAdminName = "admin@newauto.com";
    public static String LoginAdminPassWord = "password";
    
    public static String LoginAdminName2 = "admin2@newauto.com";
    public static String LoginAdminPassWord2 = "password";
    
    public static String LoginWatcherName = "watcher@newauto.com";
    public static String LoginWatcherPassWord = "password";

    public static String hubIp = "v-hub-1.bjo.natureself.site"; // 目前没使用
    public static String hubURL = "http://v-runner-1.bjo.natureself.site:4444/wd/hub";

    public static String freeSSHUserName = "upload";
    public static String freeSSHPassWord = "upload";
    public static String resultsDir = System.getProperty("user.home") + "/TestResults";
    
    // Create a logger for main log file
    public static Logger Log = LogManager.getLogger(JsonConf.class);

    public static void init() {
        JsonParser parse = new JsonParser();// 创建json解析器
        String jsonfile = "";

        jsonfile = JsonConf.class.getClassLoader().getResource("test.json").getFile();
        Log.info("============================================");
        Log.info("默认查找的配置文件位置为: " + jsonfile);
        JsonObject json = null;

        try {
            json = (JsonObject) parse.parse(new FileReader(jsonfile));// 创建jsonObject对象

            LoginSystemURL = json.get("LoginSystemURL").getAsString();
            // LoginSystemURL = "http://" + System.getProperty("serverAddress") +
            // "/#!/signin";//服务器地址
            // hubIp=json.get("hubIp").getAsString();//将json数据转为为String型的数据
            hubURL = json.get("hubURL").getAsString();
            freeSSHUserName = json.get("freeSSHUserName").getAsString();
            freeSSHPassWord = json.get("freeSSHPassWord").getAsString();
            LoginInputterName = json.get("LoginInputterName").getAsString();
            LoginInputterPassWord = json.get("LoginInputterPassWord").getAsString();
            LoginInputterName2 = json.get("LoginInputterName2").getAsString();
            LoginInputterPassWord2 = json.get("LoginInputterPassWord2").getAsString();
            LoginInputterName3 = json.get("LoginInputterName3").getAsString();
            LoginInputterPassWord3 = json.get("LoginInputterPassWord3").getAsString();
            LoginAdminName = json.get("LoginAdminName").getAsString();
            LoginAdminPassWord = json.get("LoginAdminPassWord").getAsString();
            LoginAdminName2 = json.get("LoginAdminName2").getAsString();
            LoginAdminPassWord2 = json.get("LoginAdminPassWord2").getAsString();
            LoginCenterAdminName = json.get("LoginCenterAdminName").getAsString();
            LoginCenterAdminPassWord = json.get("LoginCenterAdminPassWord").getAsString();
            LoginCenterAdminName2 = json.get("LoginCenterAdminName2").getAsString();
            LoginCenterAdminPassWord2 = json.get("LoginCenterAdminPassWord2").getAsString();
            LoginAuditorName = json.get("LoginAuditorName").getAsString();
            LoginAuditorPassWord = json.get("LoginAuditorPassWord").getAsString();
            LoginAuditorName2 = json.get("LoginAuditorName2").getAsString();
            LoginAuditorPassWord2 = json.get("LoginAuditorPassWord2").getAsString();
            LoginAuditorName3 = json.get("LoginAuditorName3").getAsString();
            LoginAuditorPassWord3 = json.get("LoginAuditorPassWord3").getAsString();
            LoginWatcherName = json.get("LoginWatcherName").getAsString();
            LoginWatcherPassWord = json.get("LoginWatcherPassWord").getAsString();
            if (!json.get("resultsDir").getAsString().isEmpty()) {
                resultsDir = json.get("resultsDir").getAsString();
            }
            Log.info("目前使用配置文件进行参数初始化");

        } catch (FileNotFoundException e) {
            Log.info("");
            Log.info("由于配置文件没有找到,因此使用默认配置");
            Log.info("");
        } finally {
            // 使用配置如下:
            Log.info("使用配置如下:");
            Log.info("LoginSystemURL: " + LoginSystemURL);
            Log.info("hubURL:  " + hubURL);
            Log.info("freeSSHUserName: " + freeSSHUserName);
            Log.info("LoginAdminName: " + LoginAdminName);
            Log.info("LoginAdminPassWord: " + LoginAdminPassWord);
            Log.info("LoginAdminName2: " + LoginAdminName2);
            Log.info("LoginAdminPassWord2: " + LoginAdminPassWord2);
            Log.info("LoginInputterName: " + LoginInputterName);
            Log.info("LoginInputterPassWord: " + LoginInputterPassWord);
            Log.info("LoginInputterName2: " + LoginInputterName2);
            Log.info("LoginInputterPassWord2: " + LoginInputterPassWord2);
            Log.info("LoginInputterName3: " + LoginInputterName3);
            Log.info("LoginInputterPassWord3: " + LoginInputterPassWord3);
            Log.info("LoginCenterAdminName: " + LoginCenterAdminName);
            Log.info("LoginCenterAdminPassWord: " + LoginCenterAdminPassWord);
            Log.info("LoginCenterAdminName2: " + LoginCenterAdminName2);
            Log.info("LoginCenterAdminPassWord2: " + LoginCenterAdminPassWord2);
            Log.info("LoginAuditorName: " + LoginAuditorName);
            Log.info("LoginAuditorPassWord: " + LoginAuditorPassWord);
            Log.info("LoginAuditorName2: " + LoginAuditorName2);
            Log.info("LoginAuditorPassWord2: " + LoginAuditorPassWord2);
            Log.info("LoginAuditorName3: " + LoginAuditorName3);
            Log.info("LoginAuditorPassWord3: " + LoginAuditorPassWord3);
            Log.info("LoginWatcherName: " + LoginWatcherName);
            Log.info("LoginWatcherPassWord: " + LoginWatcherPassWord);
            Log.info("resultsDir: " + resultsDir);
            Log.info("============================================");

        }
    }
}
